package com.example.navigationcomponentwithnavgraph

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.example.navigationcomponentwithnavgraph.databinding.FragmentImageDetailsBinding


class ImageDetailsFragment : Fragment() {

    lateinit var binding: FragmentImageDetailsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater,R.layout.fragment_image_details,container,false)

        val transactionList = arguments?.getSerializable("key") as ImageDetails

        Glide.with(requireActivity())
            .load(transactionList.image)
            .skipMemoryCache(true)//for caching the image url in case phone is offline
            .into(binding.imgtext)

      //  Log.e("TTTTT","$transactionList")
      //  binding.imgtext = transactionList.image
        binding.titletext.text = transactionList.title
        binding.discriptiontext.text = transactionList.discription

        return binding.root
    }
}