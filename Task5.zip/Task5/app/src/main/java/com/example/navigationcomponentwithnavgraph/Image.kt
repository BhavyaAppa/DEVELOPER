package com.example.navigationcomponentwithnavgraph

import android.widget.ImageView

data class Image(var imageView: ImageView)
