package com.example.navigationcomponentwithnavgraph

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter

class PageAdapter(fragmentManager: FragmentManager, lifecycle: Lifecycle) :
    FragmentStateAdapter(fragmentManager, lifecycle) {
    override fun getItemCount(): Int {
        return 10
    }

    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> TabLayoutFragment1()
            1 -> TabLayoutFragment2()
            2 -> TabLayoutFragment3()
            3 -> TabLayoutFragment4()
            4 -> TabLayoutFragment5()
            5 -> TabLayoutFragment6()
            6 -> TabLayoutFragment7()
            7 -> TabLayoutFragment8()
            8 -> TabLayoutFragment9()
            9 -> TabLayoutFragment10()

            else -> TabLayoutFragment1()
        }

    }

}