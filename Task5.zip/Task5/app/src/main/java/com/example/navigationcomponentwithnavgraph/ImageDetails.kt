package com.example.navigationcomponentwithnavgraph

import java.io.Serializable


data class ImageDetails(var image: String,var title : String,var  discription : String) : Serializable
