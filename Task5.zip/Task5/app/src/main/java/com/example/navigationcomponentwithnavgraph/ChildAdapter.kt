package com.example.navigationcomponentwithnavgraph

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.imageview.ShapeableImageView

class ChildAdapter(private var addAll: ArrayList<ImageDetails>,
                   var imageDetailsInterface: ImageDetailsInterface
): RecyclerView.Adapter<ChildAdapter.MyViewHolder>() {

    interface ImageDetailsInterface{
        fun onItemClick(position: Int)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView =
            LayoutInflater.from(parent.context).inflate(R.layout.list_item2, parent, false)
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
//        holder.titleImage.setImageResource(R.drawable.a)


            Glide.with(holder.itemView.context)
                .load(addAll[position].image)
                .skipMemoryCache(true)//for caching the image url in case phone is offline
                .into(holder.titleImage)

        holder.cardView.setOnClickListener {
            imageDetailsInterface.onItemClick(position)
        }
    }

    override fun getItemCount(): Int {
        return addAll.size
    }


    class MyViewHolder(itemView : View) : RecyclerView.ViewHolder(itemView) {
        val titleImage : ShapeableImageView = itemView.findViewById(R.id.title_img)
        val cardView : CardView = itemView.findViewById(R.id.cardviewid)
    }
}