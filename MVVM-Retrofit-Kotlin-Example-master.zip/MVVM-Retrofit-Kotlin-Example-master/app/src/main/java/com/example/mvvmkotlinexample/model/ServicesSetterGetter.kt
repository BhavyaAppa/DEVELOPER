package com.example.mvvmkotlinexample.model

data class ServicesSetterGetter (
    val message: String? = null
)