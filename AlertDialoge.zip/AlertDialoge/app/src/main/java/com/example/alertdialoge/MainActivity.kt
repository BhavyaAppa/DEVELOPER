package com.example.alertdialoge

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val click = findViewById<Button>(R.id.click)
        click.setOnClickListener(){
            val builder  = AlertDialog.Builder(this)
            builder.setTitle(R.string.dialog)
            builder.setMessage(R.string.msg)
            builder.setIcon(android.R.drawable.ic_dialog_alert)

            builder.setPositiveButton("yes"){dialogInteface
            }

        }
    }
}