package com.rk.todo.Util

class Constant {

    companion object{

        const val onBackPressReceiver = "onBackPressReceiver"

    }
}