package com.example.bottomnavigationwithnavigationdrawer

import android.graphics.Color
import android.graphics.Color.BLUE
import android.graphics.Color.blue
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import android.widget.Toolbar
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity() {
    lateinit var toggle: ActionBarDrawerToggle
    lateinit var drawerLayout: DrawerLayout
    lateinit var navigationView: NavigationView
    lateinit var bottomNavigation : BottomNavigationView
    private val dashboardFragment = DashboardFragment()
    private val  settingFragment = SettingFragment()
    private val infoFragment = InfoFragment()
    private val  blankFragment = BlankFragment()

    private lateinit var actionBarDrawerToggle: ActionBarDrawerToggle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bottomNavigation = findViewById(R.id.bottom_navigation)
        drawerLayout = findViewById(R.id.drawerlayout)
        navigationView = findViewById(R.id.navigation)
        val toolbar: androidx.appcompat.widget.Toolbar = findViewById(R.id.toolbar)

        setSupportActionBar(toolbar)

        actionBarDrawerToggle =
            ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open, R.string.close)
        drawerLayout.addDrawerListener(actionBarDrawerToggle)
        actionBarDrawerToggle.syncState()
        navigationView.setNavigationItemSelectedListener {
            Log.e("Nav Dashboard", "${R.id.dashboard}")
            Log.e("Nav setting", "${R.id.setting}")
            Log.e("Nav info", "${R.id.info}")

            when (it.itemId) {
                R.id.ic_dashboard -> {
                    replaceFragment(dashboardFragment)
                    drawerLayout.closeDrawers()
                    bottomNavigation.visibility = View.VISIBLE

                    bottomNavigation.selectedItemId = R.id.ic_dashboard
                }

                R.id.ic_setting -> {
                    replaceFragment(settingFragment)
                    drawerLayout.closeDrawers()
                    bottomNavigation.visibility = View.VISIBLE
                    bottomNavigation.selectedItemId = R.id.ic_setting
                }

                R.id.ic_info -> {
                    replaceFragment(infoFragment)
                    drawerLayout.closeDrawers()
                    bottomNavigation.visibility = View.VISIBLE
                    bottomNavigation.selectedItemId = R.id.ic_info

                }

                R.id.ic_blank -> {
                    replaceFragment(blankFragment)
                    drawerLayout.closeDrawers()
                    bottomNavigation.visibility = View.VISIBLE
                }
            }
            true
        }

            bottomNavigation.setOnItemSelectedListener {
                Log.e("Bottom Dashboard", "${R.id.dashboard}")
                Log.e("Bottom setting", "${R.id.setting}")
                Log.e("Bottom info", "${R.id.info}")
                when (it.itemId) {
                    R.id.ic_dashboard -> {
                        replaceFragment(dashboardFragment)
                        navigationView.setCheckedItem(R.id.ic_dashboard)
                    }
                    R.id.ic_setting -> {
                        replaceFragment(settingFragment)
                        navigationView.setCheckedItem(R.id.ic_setting)
                    }
                    R.id.ic_info -> {
                        replaceFragment(infoFragment)
                        navigationView.setCheckedItem(R.id.ic_info)
                    }
                }
                true
            }
            replaceFragment(dashboardFragment) // default fragment
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu , menu)
        return true
    }

    private fun replaceFragment(fragment: Fragment){
        if(fragment != null){
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fragment_container,fragment)
            transaction.commit()
        }
    }

    // navigation drawer mehtod for option selected
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if(toggle.onOptionsItemSelected(item))
        {
            return true
        }
       return super.onOptionsItemSelected(item)
    }
}