package com.example.kotlinbasics

class demo {
}