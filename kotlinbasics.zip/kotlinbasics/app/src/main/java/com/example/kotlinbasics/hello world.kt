package com.example.kotlinbasics

fun main(){
    println("Hello world")
}