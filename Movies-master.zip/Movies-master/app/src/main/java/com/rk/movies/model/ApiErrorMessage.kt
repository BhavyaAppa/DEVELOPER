package com.rk.movies.model

class ApiErrorMessage(
    val status: String,
    val code: String,
    val message: String,
) {
}