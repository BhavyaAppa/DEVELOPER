<?php

$name1 = $_POST['name'];
$mobile1 = $_POST['mobile'];
$email1 = $_POST['email'];
$gender1 = $_POST["gender"];
$contry1 = $_POST["contry"];
$adress1 = $_POST["adress"];
$hobby1 = $_POST["hobby"];
$password1 = $_POST["password"];
$confirmPassword1 = $_POST["confirmPassword"];

echo "Name :- $name1  mobile no :- $mobile1  email :- $email1 gender :-  $gender1  contry :-  $contry1 adress :- $adress1 hobby :- $hobby1 password :-  $password1 confirmPassword:- $confirmPassword1" ;

?>
