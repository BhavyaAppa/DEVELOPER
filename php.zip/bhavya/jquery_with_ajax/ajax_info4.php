<?php

$name1 = $_POST['name'];
$mobile1 = $_POST['mobile'];
$email1 = $_POST['email'];

echo "My Name is  $name1  mobile no is  $mobile1  email is  $email1 ";

?>
