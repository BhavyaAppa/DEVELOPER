<?php 

	$firstname = $_POST["firstname1"];
	$lastname = $_POST["lastname1"];
	$mobile = $_POST["mobile1"];
	$address = $_POST["address1"];
	$hobby = $_POST["hobby1"];

	echo "Form Submit Successfully <br><br>";
	echo "FirstName is :- $firstname " ;
	echo "<br><br>";
	echo "LastName is :- $lastname " ;
	echo "<br><br>";
	echo "MobileNo is :- $mobile ";
	echo "<br><br>";
	echo "Address is :- $address ";
	echo "<br><br>";
	echo "Hobby is :- $hobby ";
	echo "<br><br>";
	
?>
