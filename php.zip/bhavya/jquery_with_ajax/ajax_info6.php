<?php

if( isset( $_POST["date"] ) || isset( $_POST["time"] ))
{
	$time = "" ;
	$date = "" ;

	if( isset( $_POST['time'] ) && isset( $_POST['date'] ))
	{
		$time = $_POST['time']
		$date = $_POST['date']
		echo $time "<br>";
		echo $date ;
	}
	else
	{
		echo "error";
	}
		
}
?>
