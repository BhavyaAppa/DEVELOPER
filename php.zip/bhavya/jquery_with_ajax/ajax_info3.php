<?php

$name = $_POST['name'];
$city = $_POST['city'];

echo "My Name is $name and City is $city";

?>
