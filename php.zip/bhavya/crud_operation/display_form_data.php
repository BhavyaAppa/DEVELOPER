<?php 
require_once('inc/dal/baseclasses/class.database.php');
require_once('inc/dal/user.child.php');  ?>
<html>
	<head>
		<title> Submit all Data </title>
		
	<style> 
	h4,.message 
	{
		color: #FF0001;
	}  

	table 
	{
		text-align: center;
	}  
	</style>
		
		    <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
   
	</head>

	<body>		
		<table border="1">
			<tr>
				<td> <h4> Id </h4> </td>
				<td>  <h4> First Name</h4> </td>
				<td>  <h4> Last Name </h4> </td>
				<td>  <h4> Email </h4> </td>
				<td>  <h4> Country </h4> </td>
				<td> <h4> State   </h4> </td>
				<td>  <h4>City    </h4>  </td>
				<td>  <h4> Mobile  </h4> </td>
				<td>  <h4> Address </h4>  </td>
				<td>  <h4>  Gender </h4>   </td>
				<td> <h4> Department </h4> </td>
				<td> <h4> Technology </h4> </td>
				<td> <h4> Username   </h4> </td>
				<td> <h4> Password  </h4> </td>
				<td> <h4> Profile Photo  </h4> </td>
			</tr>			
				
		<?php 	
			// select and display record start from here
			$paramArray = array($id);
			$objUser = new userChild();
			$objUser->selectColumn = "id,first_name, last_name, email, country, state, city, mobile, address, gender, department, technology, username, password, profile_photo"; 
			$objUser->param = $paramArray;
			$objUser->condition = "id > 0";    
			$rsUser = $objUser->selectByColumn();
			$numRowsUser = $objUser->numRows;
			// select and display record end here

			// check error or not by if condition start from here
			if($numRowsUser > 0 && empty($objUser->error))
			{
				for($i = 0; $i < $numRowsUser; $i++)
				{
		?>			<tr>
						<td> <?php echo $i+1; ?> </td>
						<td> <?php echo $rsUser[$i]['first_name']; ?> </td> 
						<td> <?php echo $rsUser[$i]['last_name']; ?> </td>
						<td> <?php echo $rsUser[$i]['email']; ?> </td> 
						<td> <?php echo $rsUser[$i]['country']; ?> </td>
						<td> <?php echo $rsUser[$i]['state']; ?> </td> 
						<td> <?php echo $rsUser[$i]['city']; ?> </td>
						<td> <?php echo $rsUser[$i]['mobile']; ?> </td>
						<td> <?php echo $rsUser[$i]['address']; ?> </td>
						<td> <?php echo $rsUser[$i]['gender']; ?> </td> 
						<td> <?php echo $rsUser[$i]['department']; ?> </td>
						<td> <?php echo $rsUser[$i]['technology']; ?> </td> 
						<td> <?php echo $rsUser[$i]['username']; ?> </td>
						<td> <?php echo $rsUser[$i]['password']; ?> </td>
					<td> <img src="upload/<?php echo $rsUser[$i]['profile_photo'] ?>" height="40px" weight="40px"> </td> 
					
					<td><a href="user_registration.php?action=edit&id=<?php echo $rsUser[$i]['id']; ?>">update</a></td>
					
					<td>  <button id="delete" name="delete" value="delete" onclick="deleteFunction(<?php echo $rsUser[$i]['id']; ?>)" > delete </button> </td>
				
					</tr>
					
		<?php		
				}
			}

			else
			{
				print_r($objUser->error);
			}
			// check error or not by if condition end here
			unset($objUser);  // unset method for object 
		?>	
		</table> <p id="display1">
	
		<script>
		function deleteFunction(id) 
		{
			var userId = id;
			var datastring = "id=" + userId; 
			let text = 'Are You Sure Want to Delete';
			if (confirm(text) == true)
			{		
						// aync ajax method for request start from here
						$.ajax({ url : "http://192.168.1.200/team/bhavya/project_folder/delete_form_data.php" , 
						type: "POST" ,			// type of method from GET and POST 
						cache: false ,			// temparary data stored in cache
						timeout: 30000 ,     		// timeout milliseconds of response
						data: datastring ,		// collection of data to be pass 
						contentType: "application/x-www-form-urlencoded",
						dataType: "html" , 		// response specific type of data
						
							// beforeSend method start from here
							beforeSend : function( xhr )
							{
								
							},
							// dataFilter method end here
							
							// complete method start from here
							complete : function( xhr , status )
							{
							},
							// complete method end here

							// success method start from here
							success : function( result , status , xhr )
							{
								$("#display1").html( result );	
								 if (result == 'Record Delete Successfully')
								{
							      		$(this).closest('tr').remove();
									$(this).closest('tr').hide();
							   	}
							  	else{("#display1").append("noo");} 													 		
							},
							// success method end here

							//error method start from here
							error : function( xhr , status , error )
							{ 
								alert("error method callled");
							}
							// error method end here
						});
						// ajax method end here
	
			} 
			else 
			{	
				$("#display1").html("Record Not Delete");	
				
			}
		  
		}
		</script>
		
	</body>
</html>







