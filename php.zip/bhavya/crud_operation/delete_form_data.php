<?php	
require_once('inc/dal/baseclasses/class.database.php');
require_once('inc/dal/user.child.php'); 
// id set or not start form here
if (isset($_REQUEST["id"]) && !empty($_REQUEST["id"]))
{
	$id =  $_REQUEST["id"]; // id set or not end here
	// user class object create and delete method call start from here
	$objUser = new userChild();
	$objUser->condition = "id = $id";
	$objUser->delete();
	// user class object create and delete method call end here
	// check error or not by if condition start from here
	if(empty($objUser->error))
	{
		echo "Record Delete Successfully";
	}
	else 
	{
		print_r($objUser->error);
	}
	// check error or not by if condition end here
	unset($objUser); // unset object by method
}
else
{
	echo "Mandatory parameteres missing!";
}
?>
