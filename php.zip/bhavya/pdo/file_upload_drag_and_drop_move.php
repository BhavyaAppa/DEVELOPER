<?php

$fileData = '';
if(isset($_FILES['file']['name'][0]))
{
  foreach($_FILES['file']['name'] as $keys => $values)
  {
    $fileName = $_FILES['file']['name'][$keys];
    if(move_uploaded_file($_FILES['file']['tmp_name'][$keys], 'upload/' . $values))
    {
      $fileData .= '<img src="upload/'.$values.'" class="thumbnail" />';
       
    }
    else
    {
    	echo "not move";
    }
  }
}
echo $fileData;

?>
