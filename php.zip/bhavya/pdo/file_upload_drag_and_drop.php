<!DOCTYPE html>
<html>

<head>
  <title>Drag and drop file upload using Ajax JQuery PHP - Clue Mediator</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  
  <style>
	  h3 
	  {
	    text-align: center;
	  }

	  #drop_file_area 
	  {
	    height: 200px;
	    border: 2px dashed #ccc;
	    line-height: 200px;
	    text-align: center;
	    font-size: 20px;
	    background: #f9f9f9;
	    margin-bottom: 15px;
	  }

	  .drag_over 
	  {
	    color: #000;
	    border-color: #000;
	  }

	  .thumbnail 
	  {
	    width: 100px;
	    height: 100px;
	    padding: 2px;
	    margin: 2px;
	    border: 2px solid red;
	    border-radius: 3px;
	    float: left;
	  }

	  #upload_file 
	  {
	    display: none;
	  }
</style>
  
</head>

<body>
  <div class="container">
    <h3>Drag and drop file upload using jQuery, Ajax and PHP </h3><br />
    <div id="drop_file_area">
      Drag and Drop Files Here
    </div>
    <div id="uploaded_file"> </div>
  </div>
  
  <script>
  $(document).ready(function () 
  {
    // when an element or file selection is being dragged over 
    $("html").on("dragover", function (e) 
    {
      e.preventDefault(); // prevent default action of selected element
      e.stopPropagation(); // parent element not called only child element called
    });

    // release the drop an element after all dragged over and dragged leave 
    $("html").on("drop", function (e) 
    {
      e.preventDefault();
      e.stopPropagation();
    });

    // when an element or file selection is being dragged over 
    $('#drop_file_area').on('dragover', function () 
    {
      $(this).addClass('drag_over');
      return false;
    });

    // when an element or file selection is being dragged leave 
    $('#drop_file_area').on('dragleave', function () 
    {
      $(this).removeClass('drag_over');
      return false;
    });

    // release the drop an element after all dragged over and dragged leave 
    $('#drop_file_area').on('drop', function (e) 
    {
      e.preventDefault();
      $(this).removeClass('drag_over');
      var formData = new FormData();
      var files = e.originalEvent.dataTransfer.files;
      
      // loop for multiple fileupload 
      for (var i = 0; i < files.length; i++) 
      {
        formData.append('file[]', files[i]);
      }
      uploadFormData(formData); // function call
    });

   // function with parameter of form_data object 
    function uploadFormData(form_data) 
    {	
      $.ajax({
        url: "file_upload_drag_and_drop_move.php",
        method: "POST",
        data: form_data,
        contentType: false,
        dataType: false,
        cache: false,
        processData: false,
        brforeSend: function(xhr)
        {
        
        },
        success: function (data) 
        {
          $('#uploaded_file').append(data);
        },
         error: function (error) 
        {
          $('#uploaded_file').append(error);
        },
         complete: function (xhr) 
        {
         
        }
        
      });
    }
  });
</script>
 
</body>

</html>
