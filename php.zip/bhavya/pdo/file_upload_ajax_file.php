<?php 
// Reference: https://www.cloudways.com/blog/the-basics-of-file-upload-in-php/
	// if when update button click start from here
	// file set or not start from here
		// file set or not start from here
	// print($_REQUEST);

		if(isset($_FILES['photo_file']['name']) && !empty($_FILES['photo_file']['name']))
		{
			 	$profilePhoto = $_FILES['photo_file']['name'];
				$fileSize = $_FILES['photo_file']['size'];
				$fileTmp = $_FILES['photo_file']['tmp_name'];
				$fileType= $_FILES['photo_file']['type'];
				$targetDir = "upload/";
				$targetFile = $targetDir . basename($profilePhoto);
  				$extensionsArray = array("jpg","jpeg","png");
				$imageFileType = pathinfo($_FILES["photo_file"]["name"], PATHINFO_EXTENSION);

				// empty or not condition start form here
				if ($fileSize === 0) 
				{
				    die("The file is empty.");
				}
				// empty or not condition end here

				// file size condition start form here
				if ($fileSize > 3145728) // 3 MB (1 byte * 1024 * 1024 * 3 (for 3 MB))
				{ 
				    die("The file is too large");
				}
				// file size condition end here

				// file type condition start form here
				if(in_array($imageFileType, $extensionsArray) === true)
				{ 
					if(move_uploaded_file($fileTmp, $targetFile)) 
					{
						echo "move successfully";
					}
					else 
					{
						echo "not move";
					}		
				}
				// file type condition end here
		}
		// file set or not end here
		
	
		
?>

