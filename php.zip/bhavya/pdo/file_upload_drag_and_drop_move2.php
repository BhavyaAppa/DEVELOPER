<?php
// Include the database connection file

$fileData = '';
if(isset($_FILES['file']['name'][0]) && !empty($_FILES['file']['name'][0]))
{
  foreach($_FILES['file']['name'] as $keys => $values)
  {
    $fileName = $_FILES['file']['name'][$keys];
    if(move_uploaded_file($_FILES['file']['tmp_name'][$keys], 'upload/' . $values))
    {
      $fileData .= '<img src="upload/'.$values.'" class="thumbnail" />';
     echo "move successfully";
     echo $fileData;
    }
    
    else
    {
    	echo "Not Move";
    }
  }
}

?>
