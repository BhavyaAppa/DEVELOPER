<!DOCTYPE html>
<html>

<head>
    <title>File Validation-1</title>
</head>

<body>

    <p>
        <input type="file" id="profile" name="profile" onclick="fileUpload()" />
    </p>


    <p id="size"></p>

</body>

<script>
    	function fileUpload 
	{
		var profile = document.getElementById('profile');
		// Check if any file is selected.
		if (profile.files.length > 0) 
		{
		    for (var i = 0; i <= profile.files.length - 1; i++) {

		        var size = profile.files.item(i).size;
		        var file = Math.round((size / 1024));
		        // The size of the file.
		       
			if (file > 2048) 
			{
		            alert("please select a file less than 2mb");
		        } 
			else 
			{
		            document.getElementById('size').innerHTML = '<b>' + file + '</b> KB';
		        }
            	}
        }
    }
</script>

</html>
