<?php 
	require_once('inc/dal/baseclasses/class.database.php');
	require_once('inc/dal/user.child.php');

	// declaration start from here
		$targetDir = "upload/";
	// declaration ends here

	// if for action is edit or not start from here
	if(isset($_REQUEST['action']) && $_REQUEST['action'] === 'edit')
	{	
		// id set or not start form here
		if (isset($_REQUEST["id"]) && !empty($_REQUEST["id"]))
		{
			$id =  $_REQUEST["id"];
		}
		// id set or not end here
		
		// object create and method call start from here
		$paramArray = array($id);
		$objUser = new userChild();
		$objUser->selectColumn = "first_name, profile_photo"; 
		$objUser->param = $paramArray;
		$objUser->condition = "id = $id";    
		$rsUser = $objUser->selectByColumn();
		$numRowsUser = $objUser->numRows;
		// object create and method call end here

		// check error or not by if condition start from here
		if($numRowsUser > 0 && empty($objUser->error))
		{
			$firstName = $rsUser[0]['first_name']; 
			$profilePhoto = $rsUser[0]['profile_photo']; 
		}
		else
		{
			print_r($objUser->error);
		}
		// check error or not by if condition end here
		unset($objUser); // unset method call for object 
	}
	// if when update button click start from here
	if(isset($_REQUEST['submit']))
	{ 
		// firstname set or not start form here
		if (isset($_REQUEST["firstname"]) && !empty($_REQUEST["firstname"]))
		{
			$firstName =  addslashes($_REQUEST["firstname"]);
		}
		// firstname set or not end here
		
		// file set or not start from here
		if(isset($_FILES['file']['name']) && !empty($_FILES['file']['name']))
		{
			 	$profilePhoto = $_FILES['file']['name']; 
				$fileSize = $_FILES['file']['size'];
			     	$fileTmp = $_FILES['file']['tmp_name'];
			      	$fileType= $_FILES['file']['type'];
				$targetDir = "upload/";
				$targetFile = $targetDir . basename($profilePhoto);
				$imageFileType=strtolower(end(explode('.',$profilePhoto)));
  				$extensionsArray = array("jpg","jpeg","png");
				
				if(in_array($imageFileType,$extensionsArray) === true)
				{ 
					if(move_uploaded_file($fileTmp, $targetFile)) 
					{
						echo "move successfully";
					}
					else 
					{
						echo "not move";
					}		
				}
				
		}
		// file set or not end here
		
		$currentDateTime = date("Y-m-d H:i:s"); // set record modified time 

		// id set or not start form here
		if (isset($_REQUEST["id"]) && !empty($_REQUEST["id"]))
		{
			$id =  $_REQUEST["id"]; // id set or not end here
			$objUser = new user();
			$objUser->first_name = $firstName;
			$objUser->profile_photo = $profilePhoto;
			$objUser->modified = $currentDateTime; 
			$objUser->condition = "id = $id";
			$objUser->update();
			if(empty($objUser->error))
			{
				echo "Record Update Successfully";
				header("Location: display_file_upload.php");
   				exit;
			}
			else 
			{
				print_r($objUser->error);
			}
			unset($objUser); 
		}
		else
		{
			$objUser = new user();
			$objUser->first_name = $firstName;
			$objUser->profile_photo = $profilePhoto;
			$objUser->created = $currentDateTime;
			$objUser->modified = $currentDateTime;
			$objUser->insert();
			$lastInsertedId = $objUser->id;
			if (($lastInsertedId > 0) && (empty($objUser->error))) 
			{
				echo "<br> Records Insert Successfully";
				header("Location: display_file_upload.php");
			}
			else 
			{
				print_r($objUser->error);
			}
			unset($objUser);
		}
	}
	// update button click end here
?>
<!DOCTYPE html>
<html>
	<head>
		<title> 
			This Is Title of Registration form
		</title>
		
		<h1> Registration Form </h1> 

	</head>  

	<body bgcolor="#f2f2f2">


		<form name="file_upload" method="post" action="" enctype="multipart/form-data"> 
		
		<table>	

			<tr>
				<td>	FirstName :-	 </td>
				<td>	<input type="text" name="firstname" id="firstname" placeholder="Enter FirstName" autofocus="autofocus" value="<?php echo isset($_REQUEST['action']) && $_REQUEST['action']=="edit" ? $firstName : ""; ?>">
				</td>		
		 	</tr>

			<tr>
				<td>	Profile (PNG, JPG, JPEG) :-	</td>
				<td>
					<input type="file" id="file" name="file" accept="image/png, image/jpeg, image/jpg">

					<?php if(isset($_REQUEST['action']) && ($_REQUEST['action']=="edit")) { 
					?>
					<p> <img src="upload/<?php echo $profilePhoto ?>" height="60px" weight="60px"> </p> <?php } ?>

				</td>
			
			</tr>

			<tr>
				<td> 	<input type="submit" name="submit" value="<?php echo isset($_REQUEST['action']) && $_REQUEST['action']=="edit" ? "update" : "insert"; ?>" >	</td>
				
				<td> 	<input type="button" value="List" name="fetch" onclick="window.location='display_file_upload.php'"> </td>
			</tr> 


		</table>

		</form>	
	</body>
</html>



