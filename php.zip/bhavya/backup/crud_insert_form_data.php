<?php include 'connection.php';?>
<html>
	<head>
		<title> Submit all Data </title>

		<h3> This Is Heading </h3>
		
	<style> 
	h4,.message 
	{
		color: #FF0001;
	}  

	table 
	{
		text-align: center;
	}  
	</style>
		
	</head>

	<body>
		
	<?php 
			
					// firstname set or not start form here
					if (isset($_REQUEST["firstname"]) && !empty($_REQUEST["firstname"]))
					{
						$firstName =  addslashes($_REQUEST["firstname"]);
					}
					// firstname set or not end here
					echo "<br> Firstname :-$firstName<br>";
					
					// lastname set or not start form here
					if (isset($_REQUEST["lastname"]) && !empty($_REQUEST["lastname"]))
					{
					    	$lastName =  addslashes($_REQUEST["lastname"]);	    	
					}
					// lastname set or not end here
					echo "Lastname :-$lastName<br>";

					// email set or not start form here
					if (isset($_REQUEST["email"]) && !empty($_REQUEST["email"]))
					{	
						$email =  $_REQUEST["email"];
					}
					// email set or not end here
					echo "Email :-  $email <br>";

					// country set or not start form here
					if (isset($_REQUEST["country"]) && !empty($_REQUEST["country"]))
					{
						$country = $_REQUEST["country"] ;
					}
					// country set or not end here
					echo "Country :- $country <br>";
					
					// state set or not start form here
					if (isset($_REQUEST["state"]) && !empty($_REQUEST["state"]))
					{		
						$state =  $_REQUEST["state"] ;
					}
					// state set or not end here
					echo "State :-  $state <br>";

					// city set or not start form here
					if (isset($_REQUEST["city"]) && !empty($_REQUEST["city"]))
					{	
						$city =  $_REQUEST["city"] ;
					}
					// city set or not end here
					echo "City :-  $city <br>";
		
					// mobileno set or not start form here
					if (isset($_REQUEST["mobile"]) && !empty($_REQUEST["mobile"]))
					{
						$mobile =  $_REQUEST["mobile"] ;
					}
					// mobileno set or not end here
					echo  "Mobile :-  $mobile  <br>";
		
					// address set or not start form here
					if (isset($_REQUEST["address"]) && !empty($_REQUEST["address"]))
					{
						$address = $_REQUEST["address"] ;
					}
					// address set or not end here
					echo  "Address :-  $address  <br>";

					// gender set or not start form here
					if (isset($_REQUEST["gender_radio"]) && !empty($_REQUEST["gender_radio"]))
					{	
						$gender = $_REQUEST["gender_radio"] ;		
					}
					// gender set or not end here
					echo  "Gender :-  $gender	<br>";
					
					// department set or not start form here
					if (isset($_REQUEST["department_radio"]) && !empty($_REQUEST["department_radio"]))
					{
						$department = $_REQUEST["department_radio"] ;
					}
					// department set or not start form here
					echo "Department :-  $department <br>";
	
					// technology set or not start form here
					if (isset($_REQUEST["technology"]) && !empty($_REQUEST["technology"]))
					{	
						foreach( $_REQUEST["technology"] as $values )
						{
							$technology = $_REQUEST["technology"] ;
							echo " Technology :-   $values  <br>" ;
						}
					}
					// technology set or not end here

					// username set or not start form here
					if (isset($_REQUEST["username"]) && !empty($_REQUEST["username"]))
					{
						$username = $_REQUEST["username"] ;	
					}
					// username set or not end here
					echo " Username :- $username  <br>";

					// password set or not start form here
					if (isset($_REQUEST["password"]) && !empty($_REQUEST["password"]))
					{
						$password = $_REQUEST["password"] ;		
					}
					// password set or not end here
					echo  "Password :-  $password <br>";	
					
					// array convert into string start from here
					if( isset( $technology ) && !empty( $technology ) )
					{
						$technology = implode(",", $technology );
					}
					// array convert into string end here

					
					// insert query start from here
					$insert = $connection->query("INSERT INTO user(first_name,last_name,email,country,state,city,mobile,address,gender,department,technology,username,password)VALUES('$firstName','$lastName','$email','$country','$state','$city','$mobile','$address','$gender','$department','$technology','$username','$password')");
					// insert query end here
					// query execcute by if condition start from here
					$lastInsertedId = $connection->insert_id;echo $lastInsertedId;
		
					if ($lastInsertedId != 0 && empty($connection->error)) 
					{
					  echo "<h4 class='message'> Data Insert Successfully </h4> <br><br>";
					} 
					else 
					{
					  echo "<br> Error Description: - " . $connection->error . "<br><br>";
				          print_r($connection -> error_list);
					}
					// query execute by if condition end here

			?>

				
			
		
	</body>
</html>







