<?php include 'connection.php';?>
<html>
	<head>
		<title> Submit all Data </title>

		<h3> This Is Heading </h3>
		
	<style> 
	h4,.message 
	{
		color: #FF0001;
	}  

	table 
	{
		text-align: center;
	}  
	</style>
		
	</head>

	<body>
		
	<?php 
			
				if(isset($_REQUEST['insert'])) 
				{
					// firstname set or not start form here
					if (isset($_REQUEST["firstname"]) && !empty($_REQUEST["firstname"]))
					{
						$firstName =  addslashes($_REQUEST["firstname"]);
					}
					// firstname set or not end here
					echo "<br> Firstname :-$firstName<br>";
					
					// lastname set or not start form here
					if (isset($_REQUEST["lastname"]) && !empty($_REQUEST["lastname"]))
					{
					    	$lastName =  addslashes($_REQUEST["lastname"]);	    	
					}
					// lastname set or not end here
					echo "Lastname :-$lastName<br>";

					// email set or not start form here
					if (isset($_REQUEST["email"]) && !empty($_REQUEST["email"]))
					{	
						$email =  $_REQUEST["email"];
					}
					// email set or not end here
					echo "Email :-  $email <br>";

					// country set or not start form here
					if (isset($_REQUEST["country"]) && !empty($_REQUEST["country"]))
					{
						$country = $_REQUEST["country"] ;
					}
					// country set or not end here
					echo "Country :- $country <br>";
					
					// state set or not start form here
					if (isset($_REQUEST["state"]) && !empty($_REQUEST["state"]))
					{		
						$state =  $_REQUEST["state"] ;
					}
					// state set or not end here
					echo "State :-  $state <br>";

					// city set or not start form here
					if (isset($_REQUEST["city"]) && !empty($_REQUEST["city"]))
					{	
						$city =  $_REQUEST["city"] ;
					}
					// city set or not end here
					echo "City :-  $city <br>";
		
					// mobileno set or not start form here
					if (isset($_REQUEST["mobile"]) && !empty($_REQUEST["mobile"]))
					{
						$mobile =  $_REQUEST["mobile"] ;
					}
					// mobileno set or not end here
					echo  "Mobile :-  $mobile  <br>";
		
					// address set or not start form here
					if (isset($_REQUEST["address"]) && !empty($_REQUEST["address"]))
					{
						$address = $_REQUEST["address"] ;
					}
					// address set or not end here
					echo  "Address :-  $address  <br>";

					// gender set or not start form here
					if (isset($_REQUEST["gender_radio"]) && !empty($_REQUEST["gender_radio"]))
					{	
						$gender = $_REQUEST["gender_radio"] ;		
					}
					// gender set or not end here
					echo  "Gender :-  $gender	<br>";
					
					// department set or not start form here
					if (isset($_REQUEST["department_radio"]) && !empty($_REQUEST["department_radio"]))
					{
						$department = $_REQUEST["department_radio"] ;
					}
					// department set or not start form here
					echo "Department :-  $department <br>";
	
					// technology set or not start form here
					if (isset($_REQUEST["technology"]) && !empty($_REQUEST["technology"]))
					{	
						foreach( $_REQUEST["technology"] as $values )
						{
							$technology = $_REQUEST["technology"] ;
							echo " Technology :-   $values  <br>" ;
						}
					}
					// technology set or not end here

					// username set or not start form here
					if (isset($_REQUEST["username"]) && !empty($_REQUEST["username"]))
					{
						$username = $_REQUEST["username"] ;	
					}
					// username set or not end here
					echo " Username :- $username  <br>";

					// password set or not start form here
					if (isset($_REQUEST["password"]) && !empty($_REQUEST["password"]))
					{
						$password = $_REQUEST["password"] ;		
					}
					// password set or not end here
					echo  "Password :-  $password <br>";	
					
					// array convert into string start from here
					if( isset( $technology ) && !empty( $technology ) )
					{
						$technology = implode(",", $technology );
					}
					// array convert into string end here

					
					// insert query start from here
					$insert = $connection->query("INSERT INTO user(first_name,last_name,email,country,state,city,mobile,address,gender,department,technology,username,password)VALUES('$firstName','$lastName','$email','$country','$state','$city','$mobile','$address','$gender','$department','$technology','$username','$password')");
					// insert query end here
					// query execcute by if condition start from here
					$lastInsertedId = $connection->insert_id;
		
					if ($lastInsertedId != 0 && empty($connection->error)) 
					{
					  echo "<h4 class='message'> Data Insert Successfully </h4> <br><br>";
					} 
					else 
					{
					  echo "<br> Error Description: - " . $connection->error . "<br><br>";
				          print_r($connection -> error_list);
					}
					// query execute by if condition end here

				}

			?>

				
			<?php
			if(isset($_REQUEST["fetch"]))
			{
				$select = $connection->query("SELECT * FROM user");
					
				if ($select->num_rows > 0) 
				{
				?>
					<table border="1">
						  <tr>
						    	<td> <h4> Id </h4> </td>
							<td>  <h4> First Name</h4> </td>
							<td>  <h4> Last Name </h4> </td>
							<td>  <h4> Email </h4> </td>
							<td>  <h4> Country </h4> </td>
							<td> <h4> State   </h4> </td>
							<td>  <h4>City    </h4>  </td>
							<td>  <h4> Mobile  </h4> </td>
							<td>  <h4> Address </h4>  </td>
							<td>  <h4>  Gender </h4>   </td>
							<td> <h4> Department </h4> </td>
							<td> <h4> Technology </h4> </td>
							<td> <h4> Username   </h4> </td>
							<td> <h4> Password  </h4> </td>
						  </tr>
				<?php
					 $i=0;
					 while($row = $select->fetch_assoc()) 	 
					{
				?>
						  <tr>
						    	<td><?php echo $row["id"]; ?></td>
							<td><?php echo $row["first_name"]; ?></td>
							<td><?php echo $row["last_name"]; ?></td>
							<td><?php echo $row["email"]; ?> </td>
							<td><?php echo $row["country"];  ?> </td>
							<td><?php echo $row["state"];  ?> </td>
							<td><?php echo $row["city"];  ?> </td>
							<td><?php echo $row["mobile"];  ?> </td>
							<td><?php echo $row["address"];  ?> </td>
							<td><?php echo $row["gender"];  ?> </td>
							<td><?php echo $row["department"];  ?> </td>
							<td><?php echo $row["technology"];  ?> </td>
							<td><?php echo $row["username"];  ?> </td>
							<td><?php echo $row["password"];  ?> </td>
				
							<td><a href="update_form_data.php?id=<?php echo $row["id"]; ?>">Update</a></td>
							<td><a href="delete_form_data.php?id=<?php echo $row["id"]; ?>">Delete</a></td>
					      </tr>
					<?php
					$i++;
					}
					?>

					</table>
					 <?php
				}
				else
				{
					echo "No result found";
				}
		}
				?>
					
		
	</body>
</html>







