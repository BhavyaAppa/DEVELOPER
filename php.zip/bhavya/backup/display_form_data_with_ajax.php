<?php
	// Declaration start from here
	$firstName = $lastName = $email = $country = $state = $city = $mobile = $address = $gender = $department = $technology = $course = $username = $password = "";


	// Declaration end here

	// firstname validation by if condition start from here
	if (isset($_REQUEST["temp_firstName"]) && !empty($_REQUEST["temp_firstName"]))
	{
		$firstName = $_REQUEST["temp_firstName"];
	}
	// firstname validation by if confition end here
		
	// lastname validation by if condition start from here
	if (isset($_REQUEST["temp_lastName"]) && !empty($_REQUEST["temp_lastName"]))
	{
		$lastName = $_REQUEST["temp_lastName"];
	}
	// lastname validation by if condition end here

	// email validation by if condition start from  here
	if (isset($_REQUEST["temp_email"]) && !empty($_REQUEST["temp_email"]))
	{
		$email = $_REQUEST["temp_email"];
	}
	// email validation by if condition end here

	// country validation by if condition start from here
	if (isset($_REQUEST["temp_country"]) && !empty($_REQUEST["temp_country"]))
	{
		$country = $_REQUEST["temp_country"];
	}
	// country validation by if condition end here
	
	// state validation by if condition start from here
	if (isset($_REQUEST["temp_state"]) && !empty($_REQUEST["temp_state"]))
	{
		$state = $_REQUEST["temp_state"];
	}
	// state validation by if condition end here

	// city validation by if condition start from here
	if (isset($_REQUEST["temp_city"]) && !empty($_REQUEST["temp_city"]))
	{
		$city = $_REQUEST["temp_city"];
	}
	// city validation by if condition end here

	// mobile validation by if condition start from here
	if (isset($_REQUEST["temp_mobile"]) && !empty($_REQUEST["temp_mobile"]))
	{
		$mobile = $_REQUEST["temp_mobile"];
	}
	// mobile validation by if condition end here

	// address validation by if condition start from here
	if (isset($_REQUEST["temp_address"]) && !empty($_REQUEST["temp_address"]))
	{
		$address = $_REQUEST["temp_address"];
	}
	// address validation by if condition end here

	// gender validation by if condition start from here
	if( isset($_REQUEST["temp_gender"]) && !empty($_REQUEST["temp_gender"]))
	{
		$gender = $_REQUEST["temp_gender"];
	}
	// gender validation by if condition end here

	// department validation by if condition start from here
	if (isset($_REQUEST["temp_department"]) && !empty($_REQUEST["temp_department"]))
	{
		$department = $_REQUEST["temp_department"];	
	}
	// department validation by if condition end here

	// technology validation by if condition start from here
	if (isset($_REQUEST["temp_technology"]) && !empty($_REQUEST["temp_technology"]))
	{
		$technology = $_REQUEST["temp_technology"];
	}
	// technology validation by if condition end here

	// course validation by if condition start from here
	if (isset($_REQUEST["temp_course"]) && !empty($_REQUEST["temp_course"]))
	{
		$course = $_REQUEST["temp_course"];
	}
	// course validation by if condition end here

	

	// username validation by if condition start from here
	if (isset($_REQUEST["temp_username"]) && !empty($_REQUEST["temp_username"]))
	{
		$username = $_REQUEST["temp_username"];
	}
	// username validation by if condition end here

	// password condition by if condition start from here
	if (isset($_REQUEST["temp_password"]) && !empty($_REQUEST["temp_password"]))
	{
		$password = $_REQUEST["temp_password"];
	}
	// password condition by if condition end here

	// display all data using array start from here
	$array = array( $firstName , $lastName , $email , $country , $state , $city , $mobile , $address , $gender , $department , $technology ,$course , $username , $password );
	
	echo "<pre>";
	echo print_r( $array );
	echo "</pre>";
	// display all data by using array end here	

	// display all values start from here
	echo "Firstname :- $firstName <br>";
	echo "Lastname :- $lastName <br>";
	echo "Email :- $email <br>";
	echo "Country :- $country <br>";
	echo "State :- $state <br>";
	echo "City :- $city <br>";
	echo "Mobileno :- $mobile <br>";
	echo "Address :- $address <br>";
	echo "Gender :- $gender <br>";
	echo "Department :- $department <br>";
	echo "Technology :- $technology <br>";
	echo "Course :- $course <br>";
	echo "Username :- $username <br>";
	echo "Password :- $password <br>";
	// display all values end here

	
?>
