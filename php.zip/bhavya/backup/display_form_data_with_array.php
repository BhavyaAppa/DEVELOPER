<html>
	<head>
		<title> Submit all Data </title>

		<h3> This is Submit Data  </h3>
		
	<style> 
	error 
	{
		color: #FF0001;
	}  
	</style>  
		
	</head>

	<body>

	<?php 
	
	
			// declaration start from here
			$firstName = $lastName = $email = $contry = $state = $city = $mobile = $address = $gender = $department = $department = $technology1 = $technology2 = $technology3 = $username = $password = $array1 = $i =  "";

	/*		$email =$_REQUEST["email"]  ;  
			$regex = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/'; 
			$passwordExpression = "/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/";

			// declaration end here

			
				// firstname validation start from here
				if ( empty( $_REQUEST["firstname"] ) )
				{
					echo  "<br>  Please enter a firstname <br>";
				}
				// firstname validation end here

				// lastname validation start from here
				else if ( empty( $_REQUEST["lastname"] ) )
				{
					echo "<br> Please enter a lastname <br>";
				}
				// lastname validation end here
			
				// email validation start from here
				else if( empty( $_REQUEST["email"] ) )
				{
					echo "<br> Please Enter Email <br>";
				}
	
				else if( !preg_match($regex , $_REQUEST["email"] ) )
				{
					echo "<br> Please Enter valid Email <br>";

				}
				// email validation end here
				
				// contry select validation start from here
				else if( empty( $_REQUEST["country"] ) )
				{
					echo "<br> Please Select Contry <br>";
				}
				// contry select validation end here
	
				// state select validation start from here
				else if( empty( $_REQUEST["state"] ) )
				{
					echo "<br> Please Select State <br>";
				}
				// state select validation end here
	
				// city select validation start from here
				else if( empty( $_REQUEST["city"] ) )
				{
					echo "<br> Please Select City <br>";
				}
				// city select validation end here
	
				// mobile no validation start from here
				else if( empty( $_REQUEST["mobile"] ) )
				{
					echo "<br> Please Enter Mobile No <br>";
				}

				else if( !preg_match( "/^[0-9]*$/", $_POST["mobile"] ) )
				{
					echo "<br> Please enter valid Mobile No <br>";
							
				}
				// mobile no validation end here

				// address validation start from here
				else if( empty( $_REQUEST["address"] ) )
				{
					echo "<br> Please Enter Adress <br>" ;
				}
	
				else if( strlen( $_REQUEST["address"] ) > 1 && strlen( $_REQUEST["address"] ) < 10 )
				{
					echo "<br> Please Enter Address Length > 10 <br>";
				}
				// address validation start from here

				// gender validation start from here
				else if( empty($_REQUEST["gender"] ) )
				{
					echo "<br> Please Select Gender <br>";
				}
				// gender validation end here

				// Deprtment validation start from here
				else if( empty( $_REQUEST["department"] ) )
				{
					echo "<br> Please Select Department <br> ";
				}
				// Department validation end here
				
				// Technology select by checkbox start from here
				else if( empty( $_REQUEST["technology"] ) )
				{
					echo "<br> Please Select Atleast One Technology <br> ";
				}
				// Technology select by checkbox end here
		
				// username validation start from here
				else if ( empty( $_REQUEST["username"] ) )
				{
					echo  "<br> Please enter a Username <br>";
				}
				// username validation end here
				
				// password validation start form here
				else if ( empty( $_REQUEST["password"] ) )
				{
					echo  "<br> Please enter a Password <br>";
				}	
		
				else if( !preg_match( $passwordExpression, $_REQUEST["password"] ) )
				{
					echo "<br> Please enter valid password which include total length = 8 , uppercase = 1 , lowercase = 1 , special character = 1 , digit = 1 <br>";
							
				}  
	*/	
				// password validation end here
			
				// Display all data start from here
				
					if (isset($_REQUEST["firstname"]) && !empty($_REQUEST["firstname"]))
					{
						$firstName =  $_REQUEST["firstname"] ;
					}
					else 
					{
						$firstname = "";
					}
	
					if (isset($_REQUEST["lastname"]) && !empty($_REQUEST["lastname"]))
					{
					    	$lastName =  $_REQUEST["lastname"] ;
					}
					else 
					{
						$lastname = "";
					}
	
					if (isset($_REQUEST["email"]) && !empty($_REQUEST["email"]))
					{	
						$email =  $_REQUEST["email"];
					}
					else 
					{
						$email = "";
					}

					if (isset($_REQUEST["country"]) && !empty($_REQUEST["country"]))
					{
						$country = $_REQUEST["country"] ;
					}
					else 
					{
						$country = "";
					}
		
					if (isset($_REQUEST["state"]) && !empty($_REQUEST["state"]))
					{		
						$state =  $_REQUEST["state"] ;
					}
					else 
					{
						$state = "";
					}

					if (isset($_REQUEST["city"]) && !empty($_REQUEST["city"]))
					{	
						$city =  $_REQUEST["city"] ;
					}
					else 
					{
						$city = "";
					}
		
					if (isset($_REQUEST["mobile"]) && !empty($_REQUEST["mobile"]))
					{
						$mobile =  $_REQUEST["mobile"] ;
					}
					else 
					{
						$mobile = "";
					}
		
					if (isset($_REQUEST["address"]) && !empty($_REQUEST["address"]))
					{
						$address = $_REQUEST["address"] ;
					}
					else 
					{
						$address = "";
					}
	
					if (isset($_REQUEST["gender"]) && !empty($_REQUEST["gender"]))
					{	
						$gender = $_REQUEST["gender"] ;
					}
					else 
					{
						$gender = "";
					}

					if (isset($_REQUEST["department"]) && !empty($_REQUEST["department"]))
					{
						$department = $_REQUEST["department"] ;
					}
					else 
					{
						$department = "";
					}
						
					if (isset($_REQUEST["technology"]) && !empty($_REQUEST["technology"]))
					{	
						foreach( $_REQUEST["technology"] as $values )
						{
							$technology = $_REQUEST["technology"] ;
						}
					}
					else 
					{
						$technology = "";
					}

					if (isset($_REQUEST["username"]) && !empty($_REQUEST["username"]))
					{
						$username = $_REQUEST["username"] ;
					}
					else 
					{
						$username = "";
					}

					if (isset($_REQUEST["password"]) && !empty($_REQUEST["password"]))
					{
						$password = $_REQUEST["password"] ;	
					}
					else 
					{
						$password = "";
					}


			
			// display form data by index array start from here
			$displayArray = array( $firstName , $lastName , $email , $country , $state , $city , $mobile , $address , $gender , $department , $technology , $username , $password );

			echo "<br><br> ------------  Index Array  ------------- <br><br>";

			echo "<pre>" ;
			print_r( $displayArray );
			echo "</pre>" ;
			// display form data by index array end here

			if( isset( $technology ) && !empty( $technology ) )
			{
				$technology = implode( "  AND  " , $technology );
			}

			// display form data by associative array start from here
			$associativeArray = array(
				"Firstname" => $firstName ,
				"Lastname" => $lastName , 
				"Email" => $email ,
				"Country" => $country , 
				"State" => $state ,
				"City" => $city , 
				"Mobile" => $mobile ,
				"Address" => $address ,
				"Gender" => $gender ,
				"Department" => $department ,
				"Technology" => $technology ,
				"Username" => $username , 
				"password" => $password
				);
			echo "<br><br> ------------  Associative Array  ------------- <br><br>";
			
			echo "<pre>" ;
			print_r( $associativeArray );
			echo "</pre>" ;
			// display form data by associative array end from here


			echo "<br><br> ------------  Foreach Loop ------------- <br><br>";
			
			// display all values by foreach loop start from here
			foreach( $associativeArray as $keys => $values )
			{
				echo $keys . "    is    " . $values . "<br><br>" ;
			
			}
			// display all values by foreach loop end here
			
		?>	
	</body>
</html>
