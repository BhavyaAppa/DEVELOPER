<?php
					$select = $connection->query("SELECT * FROM user");
					?>
					<!DOCTYPE html>
					<html>
					 <head>
					 </head>
					<body>
				<?php
				if ($select->num_rows > 0) 
				{
				?>
					<table>
						  <tr>
						    	<td> <h4> Id </h4> </td>
							<td>  <h4> First Name  </h4> </td>
							<td>  <h4> Last Name   </h4> </td>
							<td>  <h4> Email	</h4> </td>
							<td>  <h4> Country </h4> </td>
							<td> <h4> State   </h4> </td>
							<td>  <h4>City    </h4>  </td>
							<td>  <h4> Mobile  </h4> </td>
							<td>  <h4> Address </h4>  </td>
							<td>  <h4>  Gender </h4>   </td>
							<td> <h4> Department </h4> </td>
							<td> <h4> Technology </h4> </td>
							<td> <h4> Username   </h4> </td>
							<td> <h4> Password  </h4> </td>
						  </tr>
								<?php
								$i=0;
					 while($row = $select->fetch_assoc()) 	 
					{
								?>
						  <tr>
						    <td><?php echo $row["id"]; ?></td>
							<td><?php echo $row["first_name"]; ?></td>
							<td><?php echo $row["last_name"]; ?></td>
							<td><?php echo $row["email"]; ?></td>
							<td><?php echo $row["country"];  ?> </td>
							<td><?php echo $row["state"];  ?> </td>
							<td><?php echo $row["city"];  ?> </td>
							<td><?php echo $row["mobile"];  ?> </td>
							<td><?php echo $row["address"];  ?> </td>
							<td><?php echo $row["gender"];  ?> </td>
							<td><?php echo $row["department"];  ?> </td>
							<td><?php echo $row["technology"];  ?> </td>
							<td><?php echo $row["username"];  ?> </td>
							<td><?php echo $row["password"];  ?> </td>
				
							<td><a href="update-process.php?id=<?php echo $row["lastInsertedId"]; ?>">Update</a></td>
					      </tr>
								<?php
								$i++;
					}
								?>
					</table>
					 <?php
					}
					else
					{
					    echo "No result found";
					}
					?>
					 </body>
				</html>
						
				

	

