<!DOCTYPE html>
<html>
	<head>
		<title> 
			This Is Title of Registration form
		</title>
		
	</head>  

	<body bgcolor="#f2f2f2">


		<form name="user_registration" method="post"> 
		
		<table>	

			<tr>
				<td> Country :- </td>
				<td> 
					<select name="country">
						<option selected="selected">Choose one</option>
						<?php
						// A sample product array
						$country = array("India", "China", "USA");
						
						// Iterating through the product array
						foreach($country as $c)
						{
							echo '<option value="' . strtolower($c) . '">' . $c . '</option>';
							
						}
					
						?>
				    	</select>
						
				</td> 
					
			</tr>
		
			<tr>
				<td> 
					<select name="state" id="state">
						<option selected="selected">Choose one</option>
						<?php
						$state = array (
						  array("Gujarat","Maharastra"),
						  array("California","Florida"),
						  array("British Columbia","Nova Scotia"),
						);
						  
						
						for ($row = 0; $row < 3; $row++) 
						{	  
							for ($col = 0; $col < 2; $col++) 
							{
							  echo '<option value="' . $state[$row][$col] . '">' . $state[$row][$col] . '</option>';
							}
						}
						?>
					</select> 


				</td>	    	
			</tr>
		
			<tr>
				<td> 
					<select name="city" id="city">
						<option selected="selected">Choose one</option>
						<?php
						$city = array (
						  array("Ahmedabad","Baroda"),
						  array("Bombay","Nagpur"),
						  array("Alameda","Belmont"),
						  array("Boca Raton","Cocoa Beach"),
						  array("Delta"," Esquimalt"),
						  array("Baddeck","Digby")
						  
						);
						  
							for ($row = 0; $row < 6; $row++) 
							{	  
							  for ($col = 0; $col < 2; $col++) {
							  echo '<option value="' . $city[$row][$col] . '">' . $city[$row][$col] . '</option>';
							  }
							}
						?>
					</select> 
				</td>	    	
			</tr>


		</table>

		</form>	
	</body>
</html>

			
