<!DOCTYPE html>
<html>
	<head>
		<title> 
			This Is Title of Registration form
		</title>
		
		<h1> Registration Form </h1> 

		<script  type="text/javascript">
			var countryObject = 
			{
				// Value Initialization Dynamically Start From Here
				"India": 
					 {
						"Gujarat": ["Ahmedabad","Surat","Baroda"],
						"Maharastra": ["Bombay","Nagpur","Pune"],
						"Goa": ["Ponda", "Margao", "Mapusa"]
					},
				"USA": 
					{
						"California": ["Alameda","Belmont","Calistoga"],
						"Florida": ["Boca Raton","Cocoa Beach","De Land"]
					},

				"Canada": 
					{
						"British Columbia": ["Dawson Creek","Delta"," Esquimalt"],
						"Nova Scotia": ["Baddeck","Digby","Glace Bay"]

					}

				// Value Initialization Dynamically Ends Here
			}

			// Onload Function Starts From Here		
			window.onload = function()
			{
				// Variable Declaration Start From Here
				var country = document.getElementById( "country" ); 
				var state = document.getElementById( "state" );
				var city = document.getElementById( "city" );
				// Variable Declaration Ends Here
			
				//  For Loop Start For Contry Object From Here
				for (var x in countryObject) 
				{
				    country.options[country.options.length] = new Option(x, x);
				}
				//  For Loop Ends For Contry Object Here

				// Onchange Function For State Starts From Here
				country.onchange = function() 
				{
					city.length = 1;
					state.length = 1;

				    	// display correct values Using For Loop Starts From Here
					for (var y in countryObject[this.value])
					{
						state.options[state.options.length] = new Option(y, y);
					}	
					// display correct values Using For Loop Ends Here
				}	
				// Onchange Function For State Ends Here

				// Onchange Function For City Starts From Here
				state.onchange = function() 
				{
					//empty City dropdown
					city.length = 1;

					// correct values Using For Loop Start From Here
					var z = countryObject[country.value][this.value];

					for (var i = 0; i < z.length; i++) 
					{
				      		city.options[city.options.length] = new Option(z[i], z[i]);
				    	}
					// correct values Using For Loop Ends Here
				  }
				// Onchange Function For City Ends Here		
			}
			// Onload Function Ends Here

		</script>	
       		 	
	</head>  

	<body bgcolor="#f2f2f2">


		<form name="user_registration" method="post" action="insert_form_data.php"> 
		
		<table>	

			<tr>
				<td>	FirstName :-	 </td>
				<td>	<input type="text" name="firstname" id="firstname" placeholder="Enter FirstName" autofocus="autofocus">
				</td>		
		 	</tr>

			<tr>
				<td>	LastName :-	 </td>
				<td>	<input type="text" name="lastname" id="lastname" placeholder="Enter LastName"> 
				</td>
		 	</tr>
		
			<tr>
				<td>	Email Id :- 	</td>
				<td>	
					<input type="text" name="email" id="email" placeholder="Enter Email">	
				</td>			
			</tr>
			
			<tr>
				<td> Country :- </td>
				<td> 
					<select id="country" name="country">
						<option value="" selected="selected"> Select contry </option>
					</select>
				</td>			
			</tr>
		
			<tr>
				<td> State :- </td>
				<td> 
					<select id="state" name="state">
						<option value="" selected="selected"> Select State </option>
					</select>
				</td>			
			</tr>

			<tr>
				<td> City :- </td>
				<td> 
					<select id="city" name="city">
						<option value="" selected="selected"> Select City </option>
					</select>
				</td>			
			</tr>

			<tr>
				<td>	Mobile No :-	</td>
				<td>	<input type="phone" id="mobile" placeholder="Enter Mobile No" maxlength="10" name="mobile"> 	
				</td> 

			</tr>
		
			<tr>
				<td>	Address :- 	</td>
				<td>	<textarea name="address" id="address" rows="5" cols="30" name="address">   </textarea>
				</td>
			</tr>
			
			<tr>
				<td>	Gender :- 	</td>
				<td>	<input type="radio" name="gender_radio" value="Male"> Male  
       			  	  	<input type="radio" name="gender_radio" value="Female"> Female 
				  	<input type="radio" name="gender_radio" value="Others"> Others  
				</td>

			</tr>


			<tr>
				<td>	Department :- 	</td>
				<td>	<input type="radio" name="department_radio" value="General"> General  
       			  	  	<input type="radio" name="department_radio" value="Marketing"> Markting 
				 	<input type="radio" name="department_radio" value="Finance"> Finance  
				</td>
			</tr>

			<tr>
				<td>	Technology :- 	</td>
				<td>	<input type="checkbox" name="technology[]" value="React"> React
					<input type="checkbox" name="technology[]" value="Node">Node 
					<input type="checkbox" name="technology[]" value="PHP"> PHP
				</td>

			</tr>

			<tr>
				<td>	Username :-	 </td>
				<td>	<input type="text" name="username" id="username" placeholder="Enter Username"> 
				</td>
			</tr>

			
			<tr>
				<td>	Password :-	</td>
				<td>	<input type="password" id="password" placeholder="Enter Password" name="password"> 	
				</td> 
			</tr>
			<!-- <tr>	<td>	</td>	<td>	</td>	</tr>	 -->

			<!-- <tr>	<td>	</td>	<td>	</td>	</tr> -->
			
			<tr>
				<td> 	<input type="submit" value="insert" name="insert">	</td>
				
				<td> 	<input type="button" value="List" name="fetch" onclick="window.location='display_form_data.php'"> </td>
			</tr> 


		</table>

		</form>	
	</body>
</html>

