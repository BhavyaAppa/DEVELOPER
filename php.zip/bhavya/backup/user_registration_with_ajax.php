<html>
  <head>

	<script  type="text/javascript">
			var countryObject = 
			{
				// Value Initialization Dynamically Start From Here
				"India": 
					 {
						"Gujarat": ["Ahmedabad","Surat","Baroda"],
						"Maharastra": ["Bombay","Nagpur","Pune"],
						"Goa": ["Ponda", "Margao", "Mapusa"]
					},
				"USA": 
					{
						"California": ["Alameda","Belmont","Calistoga"],
						"Florida": ["Boca Raton","Cocoa Beach","De Land"]
					},

				"Canada": 
					{
						"British Columbia": ["Dawson Creek","Delta"," Esquimalt"],
						"Nova Scotia": ["Baddeck","Digby","Glace Bay"]

					}

				// Value Initialization Dynamically Ends Here
			}

			// Onload Function Starts From Here		
			window.onload = function()
			{
				// Variable Declaration Start From Here
				var country = document.getElementById( "country" ); 
				var state = document.getElementById( "state" );
				var city = document.getElementById( "city" );
				// Variable Declaration Ends Here
			
				//  For Loop Start For Contry Object From Here
				for (var x in countryObject) 
				{
				    country.options[country.options.length] = new Option(x, x);
				}
				//  For Loop Ends For Contry Object Here

				// Onchange Function For State Starts From Here
				country.onchange = function() 
				{
					city.length = 1;
					state.length = 1;

				    	// display correct values Using For Loop Starts From Here
					for (var y in countryObject[this.value])
					{
						state.options[state.options.length] = new Option(y, y);
					}	
					// display correct values Using For Loop Ends Here
				}	
				// Onchange Function For State Ends Here

				// Onchange Function For City Starts From Here
				state.onchange = function() 
				{
					//empty City dropdown
					city.length = 1;

					// correct values Using For Loop Start From Here
					var z = countryObject[country.value][this.value];

					for (var i = 0; i < z.length; i++) 
					{
				      		city.options[city.options.length] = new Option(z[i], z[i]);
				    	}
					// correct values Using For Loop Ends Here
				  }
				// Onchange Function For City Ends Here		
			}
			// Onload Function Ends Here

		</script>

    <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
    <script>

	// document ready or not check start from here
	$(document).ready(function()
	{
		// click method call when button submit start from here
		$("#submit").click(function()
		{
			// variable declaration start from here
			var firstName = $("#firstname").val();
			var lastName = $("#lastname").val();
			var email = $("#email").val();
			var mobile = $("#mobile").val();
			var address = $("#address").val();
			var country = $("#country").val();
			var state = $("#state").val();
			var city = $("#city").val();
			var gender = $("input[name='gender_radio']:checked").val();
			var department = $("input[name='department_radio']:checked").val();
			var username = $("#username").val();	
			var password = $("#password").val();
			var technology = [];
			var course = [];

			// get technology which you have set start from here
			$.each($("input[name='technology[]']:checked"), function ()
			{
				technology.push( $(this).val() );
			});
			// get technology which you have set end here
			
			// get course which you have set start from here
			$.each($("input[name='course[]']:checked"), function ()
			{
				course.push( $(this).val() );
			});
			// get course which you have set end here
			

			// Data pass by string 
			var datastring = "temp_firstName=" + firstName + "&temp_lastName=" + lastName + "&temp_email=" + email + "&temp_mobile=" + mobile + "&temp_country=" + country + "&temp_state=" + state + "&temp_city=" + city +"&temp_address=" + address + "&temp_gender=" + gender + "&temp_department=" + department + "&temp_technology=" + technology + "&temp_course=" + course + "&temp_username=" + username + "&temp_password=" + password;
			// variable declaration end here

			// ajax method call start from here
			$.ajax({ url : "http://192.168.1.200/team/bhavya/php/display_form_data_with_ajax.php" , 
						type: "POST" ,			// type of method from GET and POST 
						cache: false ,			// temparary data stored in cache
						timeout: 30000 ,     		// timeout milliseconds of response
						data: datastring ,		// collection of data to be pass 
						contentType: "application/x-www-form-urlencoded", // request specific type of data
						dataType: "html" , 		// response specific type of data
						
						// beforeSend method start from here
						beforeSend : function( xhr )
						{
							$("#txt1").append(" Before Send Method Called <br>");
						},
						// dataFilter method end here
							
						// complete method start from here
						complete : function( xhr , status )
						{
							$("#txt1").append("Complete Method called <br>");
						},
						// complete method end here						

						// success method start from here
						success : function( result , status , xhr )
						{	
							$("#txt1").append(" Success Method called <br>");
							$("#display2").html( result );			
						},

						//error method start from here
						error : function( xhr , status , error )
						{ 
							$("#display2").html(error);	
							document.write(" <h1> Error Ocurred !!! <br> </h1>");
						}
						// error method end here
					});
					// ajax method call end here			
		});
		// click method call when button submit end here
	});
      	// document ready or not check end here
    </script>
  </head>
 <body>
	<form name="user_registration_with_ajax" method="post" align="center">	
		<table>
			<tr>
				<td>	First Name :-	 </td>
				<td>	<input type="text" name="firstname" id="firstname" placeholder="Enter Firstname" autofocus="autofocus"> 
				</td>

			<tr>
				<td>	Last Name :- 	</td>
				<td>	
					<input type="text" name="lastname" id="lastname" placeholder="Enter Lastname">			
				</td> 

			</tr>

			<tr>
				<td>	Email Id :- 	</td>
				<td>	
					<input type="text" name="email" id="email" placeholder="Enter Email">	
				</td>			
			</tr>
			
			<tr>
				<td> Country :- </td>
				<td> 
					<select id="country" name="country">
						<option value="" selected="selected"> Select contry </option>
					</select>
				</td>			
			</tr>
		
			<tr>
				<td> State :- </td>
				<td> 
					<select id="state" name="state">
						<option value="" selected="selected"> Select State </option>
					</select>
				</td>			
			</tr>

			<tr>
				<td> City :- </td>
				<td> 
					<select id="city" name="city">
						<option value="" selected="selected"> Select City </option>
					</select>
				</td>			
			</tr>


			<tr>
				<td>	Mobile No :-	</td>
				<td>	<input type="phone" id="mobile" name="mobile" placeholder="Enter Mobile No" maxlength="10"> 	
				</td> 
			</tr>
			
			<tr>
				<td>	Address :- 	</td>
				<td>	<textarea name="address" id="address" name="address" rows="5" cols="30">   </textarea>
				</td>
			</tr>
		
		
			<tr>
				<td>	Gender :- 	</td>
				<td>	<input type="radio" name="gender_radio" id="gender_radio"  value="Male"> Male  
       			  	  	<input type="radio" name="gender_radio" id="gender_radio" value="Female"> Female 
				  	<input type="radio" name="gender_radio" id="gender_radio" value="Others"> Others  
				</td>

			</tr>


			<tr>
				<td>	Department :- 	</td>
				<td>	<input type="radio" name="department_radio" id="department_radio" value="General"> General  
       			  	  	<input type="radio" name="department_radio"  id="department_radio" value="marketing"> Markting 
				 	<input type="radio" name="department_radio"  id="department_radio" value="Finance"> Finance  
				</td>
			</tr>

			<tr>
				<td>	Technology :- 	</td>
				<td>	<input type="checkbox" name="technology[]" value="React JS"> React JS
					<input type="checkbox" name="technology[]" value="Node JS">Node JS
					<input type="checkbox" name="technology[]" value="PHP"> PHP
				</td>

			</tr>

			<tr>
				<td>	Course :- 	</td>
				<td>	<input type="checkbox" name="course[]" value="c"> C
					<input type="checkbox" name="course[]" value=javascript"> javascript
					<input type="checkbox" name="course[]" value="java">Java
				</td>

			</tr>


			<tr>
				<td>	Username :-	 </td>
				<td>	<input type="text" name="username" id="username" placeholder="Enter Username"> 
				</td>
			</tr>

			
			<tr>
				<td>	Password :-	</td>
				<td>	<input type="password" id="password" placeholder="Enter Password" name="password"> 	
				</td> 
			</tr>


			<tr>  <td>   </td> 
				<td>
					 <input type="button" id="submit" value="Submit" />
				</td>
			</tr>
		</table>	
	</form>
		
		
	<div id="txt1">  	</div>
	<div id="display1">     </div>
	<div id="display2">     </div>


  </body>
</html>
