<?php include 'connection.php';?>
<html>
	<head>
		<title> Submit all Data </title>

		<h3> This Is Heading </h3>
		
	<style> 
	h4,.message 
	{
		color: #FF0001;
	}  

	table 
	{
		text-align: center;
	}  
	</style>
		
	</head>

	<body>		
			<?php
		
				$select = $connection->query("SELECT * FROM user");
					
				if ($select->num_rows > 0) 
				{
				?>
					<table border="1">
						  <tr>
						    	<td> <h4> Id </h4> </td>
							<td>  <h4> First Name</h4> </td>
							<td>  <h4> Last Name </h4> </td>
							<td>  <h4> Email </h4> </td>
							<td>  <h4> Country </h4> </td>
							<td> <h4> State   </h4> </td>
							<td>  <h4>City    </h4>  </td>
							<td>  <h4> Mobile  </h4> </td>
							<td>  <h4> Address </h4>  </td>
							<td>  <h4>  Gender </h4>   </td>
							<td> <h4> Department </h4> </td>
							<td> <h4> Technology </h4> </td>
							<td> <h4> Username   </h4> </td>
							<td> <h4> Password  </h4> </td>
						  </tr>
				<?php
					 $i=0;
					 while($row = $select->fetch_assoc()) 	 
					{
				?>
						  <tr>
						    	<td><?php echo $row["id"]; ?></td>
							<td><?php echo $row["first_name"]; ?></td>
							<td><?php echo $row["last_name"]; ?></td>
							<td><?php echo $row["email"]; ?> </td>
							<td><?php echo $row["country"];  ?> </td>
							<td><?php echo $row["state"];  ?> </td>
							<td><?php echo $row["city"];  ?> </td>
							<td><?php echo $row["mobile"];  ?> </td>
							<td><?php echo $row["address"];  ?> </td>
							<td><?php echo $row["gender"];  ?> </td>
							<td><?php echo $row["department"];  ?> </td>
							<td><?php echo $row["technology"];  ?> </td>
							<td><?php echo $row["username"];  ?> </td>
							<td><?php echo $row["password"];  ?> </td>
				
							<td><a href="update_form_data.php?id=<?php echo $row["id"]; ?>">Update</a></td>
							<td><a href="delete_form_data.php?id=<?php echo $row["id"]; ?>">Delete</a></td>
					      </tr>
					<?php
					$i++;
					}
					?>

					</table>
					 <?php
				}
				else
				{
					echo "No result found";
				}
		
				?>
					
		
	</body>
</html>







