<!-- 
    Created by Bhavya 9 march 2022
 -->
 <?php
    require_once 'inc/php/config.php';
    require_once 'inc/dal/baseclasses/class.database.php';
    require_once 'inc/dal/settings.child.php';
    require_once 'inc/php/functions.php';
    require_once 'inc/dal/baseclasses/class.database.php';
    require_once 'inc/dal/funding_master.child.php';
    
    $codeUrl = getCodeUrl(); // call function and get code url
?>
<!doctype html>
<html class="no-js">
<head>
    <title><?php echo ucfirst($formAction); ?> Add Funding </title>
    <?php require_once ('inc/php/head.php'); ?>
	<script src="inc/js/jquery-ui.js"></script>
    <script type="text/javascript">
        var codeUrl = '<?php echo $codeUrl; ?>'; // code url
		$(document).ready(function()
		{	  
			$('#fundingStartDate').datepicker({
				dateFormat: 'mm-dd-yy'
			});			
			$('#fundingEndDate').datepicker({
				dateFormat: 'mm-dd-yy'
			});
			
			 // hide error message
			 $("#fundingname").keypress(function(){
			   $("#errorFundingName").hide();
			   });
			  
			$(document).on('click','#addFunding',function(e) 
			{
				// Declaration
				var name= ($("#fundingname").val()).trim();
				var regex = new RegExp("^[a-zA-Z]*$");
				
				// validation
				if(name == '' || name == null || name == undefined) 
				{
					$("#errorFundingName").text("Please Enter Name");
					return false;	
				}
				else if((regex.test(name) === false)) 
				{
					$("#errorFundingName").text("Please Enter Only Alphabets");
					return false;
				}
				else
				{   
					// alert("allRequestData >> "+JSON.stringify(allRequestData));
					
					var formData = new FormData(); // create object
					var allRequestData = $('#addFundingForm').serializeArray();
								
					$.each(allRequestData,function(key,input)
					{
						// alert("name >> "+input.name+" value >> "+input.value);
						formData.append(input.name,input.value);
					});
					
					//alert("formData >> "+JSON.stringify(formData));

					var finalUrl = codeUrl+"api/add_funding.php"; // finalUrl
					
					$.ajax({
						type: "POST",
						url: finalUrl,
						data: formData,
						dataType: "json",
						contentType:false,
						cache: false,
						processData: false,
						timeout : 30000, 
						beforeSend : function()
						{ 
							$("#addFundingLoader").show(); // show loader
						},
						success: function(response)
						{ 
							var status = response.header.status; // get status code
							var message = response.header.message; // get message

							console.log("status ::"+status);
							console.log("message ::"+message);
							
							if(status == 200)
							{ 
								// window.location.href=""; // redirect on page
							} 
							else
							{
								// $("#errorMessageDiv").show();
								// $("#errorMessageLableId").text('');
								// $("#errorMessageLableId").text(message);
							}
							return false;
						},
						error: function(XMLHttpRequest, errorStatus, errorThrown) 
						{
							console.log("XHR :: "+JSON.stringify(XMLHttpRequest));
							console.log("Status :: "+errorStatus);
							console.log("error :: "+errorThrown);
							var errorStatus = XMLHttpRequest['status'];
							if(errorThrown == 'timeout')
							{
								alert('Request has been timeout. Please check your internet connection! (Error: '+errorStatus+')');
								return false;
							}
							else
							{
								alert('There is something wrong! Please try again! (Error: '+errorStatus+')');
								return false;
							}
						},
						complete: function()
						{
							$("#addFundingLoader").hide(); // hide loader
						}
					});
						e.preventDefault();
					return false;		
				
				}
			});
		});
    </script>
</head>
<body class="noMenu">
<!--
	================
	Header Start
	================
-->
<?php require_once ('inc/php/header.php'); ?>
<!-- 
	=============== 
	Page Title Start
	=============== 
-->
<section class="pageTitle">
    <h1>Add Funding</h1>
    <a href="category.php" class="back">Back</a>
    <div class="clr"></div>
</section>
<!-- 
	=============== 
	Page Title End
	=============== 
-->
<!-- 
	===============
	Page Content Start 
	===============
-->
<section class="pageContent widget">

    <!--
		===================
		Alert :: Success
		===================
	-->
    <div class="alert alert-success" style="display: none;" id="successMessageDiv">
        <img src="images/success-tik.svg" />
        <strong>Success!</strong>
        <lable id="successMessageLableId"></lable>
    </div>

	<!--
		===================
		Alert :: Error
		===================
	-->
    <div class="alert alert-error" style="display: none;" id="errorMessageDiv">
        <img src="images/error_x.svg" />
        <strong>Error!</strong>
        <lable id="errorMessageLableId"></lable>
    </div>	
	<!-- form stat -->	
    <form id="addFundingForm" name="addFundingForm" method="post">
        <div class="card">
            <ul class="form">
                <li>
                    <div class="lbl">Name<span>*</span></div>
                    <div class="val">
                        <input autocomplete="off" type="text" class="input" placeholder="Please Enter Name" id="fundingname" name="fundingname" />
                        <div class="validation">
                            <span id="errorFundingName"></span>
                        </div>
                    </div>
		</li>
		
		<li>
		 <div class="lbl">Description</div>
                    <div class="val">
                        <textarea name="fundingdiscription" id="fundingdiscription" rows="4" cols="30" placeholder="Enter Discription Here..."></textarea>
                    </div>
                </li>
		
		<li>
                  <div class="lbl">Amount</div>
                    <div class="val">
                        <input autocomplete="off" type="number" class="input" placeholder="Please Enter Amount" id="fundingamount" name="fundingamount" step="any" />
                    </div>
                </li>
                
                <li> 
                    <div class="lbl">Remarks</div>
                    <div class="val">
                        <textarea name="fundingremarks" id="fundingremarks" rows="4" cols="30" placeholder="Enter Remarks Here..."></textarea>
                    </div>
                </li>
                    
             <li>
		<div class="lbl">Start Date</div>
                <div class="val">
                    <input autocomplete="off" type="text" class="input" placeholder="Enter Start Date" id="fundingStartDate" name="fundingStartDate" value='' />
                </div>
            </li>
            
            <li>
		<div class="lbl">End Date</div>
		<div class="val">
			<input autocomplete="off" type="text" class="input" placeholder="Enter End Date" id="fundingEndDate" name="fundingEndDate" value='' />
		<div class="validation">
		<span style="display:none;" ></span>
		</div>
                </li>
            
             <li>
		<div class="lbl"> </div>
		<div class="val">
			 <input autocomplete="off" input type="hidden" id="action" name="action" value="add">
		<div class="validation">
		<span style="display:none;" ></span>
		</div>
              </li>
          </ul>
          
        </div>
        <div class="submitBtn submit" style="display:inline-block; margin-left:calc(250px + 20px);">
            <div class="btnLoader" id="addFundingLoader" style="display:none;">
                <span class="spinLoader"></span>
            </div>
            <input value="Add Funding" class="btn" type="submit" id="addFunding" name="addFunding">
        </div>

    </form>
    <!-- form end -->	

</section>
<!-- 
	=============== 
	Page Content Ends
	===============
-->

<!-- 
	=============== 
	Footer Start
	===============
-->
<?php require_once ('inc/php/footer.php'); ?>
</body>
</html>
