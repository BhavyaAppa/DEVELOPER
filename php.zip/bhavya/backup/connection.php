
	<?php // declaration start from here
			$firstName = $lastName = $email = $country = $state = $city = $mobile = $address = $gender = $department = $technology = $username = $password =  "";
			$serverName = "localhost";
			$username = "root";
			$password = "admin";
			$database = "bhavya";
			// declaration end here

			
			$connection = mysqli_connect($serverName,$username,$password,$database);

			// connection established or not start from here
			if ($connection->connect_error)
 			{
 			 	die("Connection failed: " . $connection->connect_error);
			}
			// connection established or not end here
	?>
					






