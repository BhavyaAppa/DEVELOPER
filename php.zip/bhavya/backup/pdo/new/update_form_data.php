﻿<?php include 'connection.php'; ?>
<html>
	<head>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script  type="text/javascript">
			var countryObject = 
			{
				// Value Initialization Dynamically Start From Here
				"India": 
					 {
						"Gujarat": ["Ahmedabad","Surat","Baroda"],
						"Maharastra": ["Bombay","Nagpur","Pune"],
						"Goa": ["Ponda", "Margao", "Mapusa"]
					},
				"USA": 
					{
						"California": ["Alameda","Belmont","Calistoga"],
						"Florida": ["Boca Raton","Cocoa Beach","De Land"]
					},

				"Canada": 
					{
						"British Columbia": ["Dawson Creek","Delta"," Esquimalt"],
						"Nova Scotia": ["Baddeck","Digby","Glace Bay"]

					}
				

				// Value Initialization Dynamically Ends Here
			}

			// Onload Function Starts From Here		
			window.onload = function()
			{
				// Variable Declaration Start From Here
				var country = document.getElementById( "country" ); 
				var state = document.getElementById( "state" );
				var city = document.getElementById( "city" );
				// Variable Declaration Ends Here
			
				//  For Loop Start For Contry Object From Here
				for (var x in countryObject) 
				{
				    country.options[country.options.length] = new Option(x, x);
				}
				//  For Loop Ends For Contry Object Here

				// Onchange Function For State Starts From Here
				country.onchange = function() 
				{
					city.length = 1;
					state.length = 1;

				    	// display correct values Using For Loop Starts From Here
					for (var y in countryObject[this.value])
					{
						state.options[state.options.length] = new Option(y, y);
					}	
					// display correct values Using For Loop Ends Here
				}	
				// Onchange Function For State Ends Here

				// Onchange Function For City Starts From Here
				state.onchange = function() 
				{
					//empty City dropdown
					city.length = 1;

					// correct values Using For Loop Start From Here
					var z = countryObject[country.value][this.value];

					for (var i = 0; i < z.length; i++) 
					{
				      		city.options[city.options.length] = new Option(z[i], z[i]);
				    	}
					// correct values Using For Loop Ends Here
				  }
				// Onchange Function For City Ends Here		
			}
			// Onload Function Ends Here

		</script>	
       		 	
	</head>

	<body> 

	<?php 
			// declaration start from here
			$id = $firstName = $lastName = $email = $country = $state = $city = $mobile = $address = $gender = $department = $technology = $username = $password =  "";
			$row['technology'] = " ";
			// declaration ends here

		// count total no of request for update data start from here 
		if(count($_REQUEST)>0) 
		{

				// update button click start from here
				if(isset($_REQUEST['update'])) 
				{
					// id set or not start form here
					if (isset($_REQUEST["id"]) && !empty($_REQUEST["id"]))
					{
						$id =  $_REQUEST["id"];
					}
					// id set or not end here
					
			
					// firstname set or not start form here
					if (isset($_REQUEST["firstname"]) && !empty($_REQUEST["firstname"]))
					{
						$firstName =  addslashes($_REQUEST["firstname"]);
					}
					// firstname set or not end here
					
					
					// lastname set or not start form here
					if (isset($_REQUEST["lastname"]) && !empty($_REQUEST["lastname"]))
					{
					    	$lastName =  addslashes($_REQUEST["lastname"]);	    	
					}
					// lastname set or not end here
					

					// email set or not start form here
					if (isset($_REQUEST["email"]) && !empty($_REQUEST["email"]))
					{	
						$email =  $_REQUEST["email"];
					}
					// email set or not end here
					

					// country set or not start form here
					if (isset($_REQUEST["country"]) && !empty($_REQUEST["country"]))
					{
						$country = $_REQUEST["country"] ;
					}
					// country set or not end here
					
					
					// state set or not start form here
					if (isset($_REQUEST["state"]) && !empty($_REQUEST["state"]))
					{		
						$state =  $_REQUEST["state"] ;
					}
					// state set or not end here
					

					// city set or not start form here
					if (isset($_REQUEST["city"]) && !empty($_REQUEST["city"]))
					{	
						$city =  $_REQUEST["city"] ;
					}
					// city set or not end here
					
		
					// mobileno set or not start form here
					if (isset($_REQUEST["mobile"]) && !empty($_REQUEST["mobile"]))
					{
						$mobile =  $_REQUEST["mobile"] ;
					}
					// mobileno set or not end here
					
		
					// address set or not start form here
					if (isset($_REQUEST["address"]) && !empty($_REQUEST["address"]))
					{
						$address = $_REQUEST["address"] ;
					}
					// address set or not end here
					

					// gender set or not start form here
					if (isset($_REQUEST["gender_radio"]) && !empty($_REQUEST["gender_radio"]))
					{	
						$gender = $_REQUEST["gender_radio"] ;		
					}
					// gender set or not end here
					
					
					// department set or not start form here
					if (isset($_REQUEST["department_radio"]) && !empty($_REQUEST["department_radio"]))
					{
						$department = $_REQUEST["department_radio"] ;
					}
					// department set or not start form here
					
	
					// technology set or not start form here
					if (isset($_REQUEST["technology"]) && !empty($_REQUEST["technology"]))
					{	
						foreach( $_REQUEST["technology"] as $values )
						{
							$technology = $_REQUEST["technology"] ;
						}
					}
					

					// technology set or not end here
					
					// username set or not start form here
					if (isset($_REQUEST["username"]) && !empty($_REQUEST["username"]))
					{
						$username = $_REQUEST["username"] ;	
					}
					// username set or not end here
					
					// password set or not start form here
					if (isset($_REQUEST["password"]) && !empty($_REQUEST["password"]))
					{
						$password = $_REQUEST["password"] ;		
					}
					// password set or not end here
					
					
					// array convert into string start from here
					if( isset( $technology ) && !empty( $technology ) )
					{
						$technology = implode( "," , $technology );
					}
					// array convert into string end here
			
			// try block start from here
			try
			{
		// update query start from here
		$sql = "UPDATE user SET id = :id, first_name = :firstName, last_name = :lastName, email = :email, country = :country, state = :state,city = :city, mobile = :mobile,address = :address, gender = :gender, department = :department, technology = :technology,username = :username,password = :password WHERE id = :id";
 		// update query end here

				// prepare statment start from here
				if($statment = $connection->prepare($sql))
				{
					// Bind variables to the prepared statement as parameters start from here
					$statment->bindParam(":id", $id);
					$statment->bindParam(":firstName", $firstName);
					$statment->bindParam(":lastName", $lastName);
					$statment->bindParam(":email", $email);
					$statment->bindParam(":country", $country);
					$statment->bindParam(":state", $state);
					$statment->bindParam(":city", $city);
					$statment->bindParam(":mobile", $mobile);
					$statment->bindParam(":address", $address);
					$statment->bindParam(":gender", $gender);
					$statment->bindParam(":department", $department);
					$statment->bindParam(":technology", $technology);
					$statment->bindParam(":username", $username);
					$statment->bindParam(":password", $password);
			    		// Bind variables to the prepared statement as parameters end here

					
				    	// execute the prepared statement start from here
					if($statment->execute())
					{
						// Records updated successfully
						echo "Records update successfully";
						exit();
				    	}
					else if(!$statment) 
					{
						echo "\nPDO::errorInfo():\n";
						print_r($connection->errorInfo());
					} 
					// execute the prepared statement end here
				}
				// prepare statment end here
			}
			// try block end here

			// catch block start form here
			catch(PDOException $e)
			{
				die("ERROR: Could not connect. " . $e->getMessage());
			}
			// catch block end here
				 
			// Close statement
			unset($statment);
			    
			// Close connection
			unset($connection);

		}
		// update button click end here
	}
	// count total no of request for update data end here

        
		// id set or not start form here
		if (isset($_REQUEST["id"]) && !empty($_REQUEST["id"]))
		{
			$id =  $_REQUEST["id"];
		}
		// id set or not end here

	// try block start from here
	try
	{
		// Prepare a select statement
		$sql = "SELECT * FROM user WHERE id = :id";
	    	
		// prepare statment by if condition start form here
		if($statment = $connection->prepare($sql))
		{
			// Bind variables to the prepared statement as parameters
			$statment->bindParam(":id", $tempId);
			
			// Set parameters	
			$tempId = $id;
        
			// Attempt to execute the prepared statement start from here
			if($statment->execute())
			{
				// count no of records start from here
				if($statment->rowCount() == 1)
				{
					/* Fetch result row as an associative array. Since the result set
					contains only one row, we don't need to use while loop */
					$row = $statment->fetch(PDO::FETCH_ASSOC);	
					$firstName = $row['first_name'];
					$lastName = $row['last_name'];
					$email = $row['email'];	
					$country = $row['country'];
					$state = $row['state'];
					$city = $row['city'];
					$mobile = $row['mobile'];
					$address = $row['address'];
					$gender  = $row['gender'];
					$department = $row['department'];
					$technology = $row['technology'];
					$username = $row['username'];
					$password = $row['password'];					
				} 
				// count no of records end here	
			} 
			// Attempt to execute the prepared statement end here
        	}
		// prepare statment by if condition end here
	}
	// try block end here

	// catch block start from here	
	catch(PDOException $e)
	{
		die("ERROR: Could not connect. " . $e->getMessage());
	}
	// catch block end here

	// Close statement
	unset($statment);
		    
	// Close connection
	unset($connection);

	?>


		<form name="update_form_data" method="post" action="">
				
		<table>	

			<tr>
				<td>	FirstName :-	 </td>
				<td>	<input type="text" name="firstname" id="firstname" placeholder="Enter FirstName" autofocus="autofocus"  value="<?php echo $firstName; ?>">
				</td>		
		 	</tr>

			<tr>
				<td>	LastName :-	 </td>
				<td>	<input type="text" name="lastname" id="lastname" placeholder="Enter LastName" value="<?php echo $lastName; ?>"> 
				</td>
		 	</tr>
		
			<tr>
				<td>	Email Id :- 	</td>
				<td>	
					<input type="text" name="email" id="email" placeholder="Enter Email" value="<?php echo $email ?>">	
				</td>			
			</tr>
			
			
			<tr>
				<td> Country :- </td>
				<td> 
					<select id="country" name="country">
						<option value="<?php echo $country; ?>">  country </option>
					</select>
				</td>			
			</tr>
		
			<tr>
				<td> State :- </td>
				<td> 
					<select id="state" name="state">
						<option value="<?php echo $state; ?>">  state </option>
					</select>
				</td>			
			</tr>

			<tr>
				<td> City :- </td>
				<td> 
					<select id="city" name="city">
						<option value="<?php echo $city; ?>">  city </option>
					</select>
				</td>			
			</tr>

			<tr>
				<td>	Mobile No :-	</td>
				<td>	<input type="phone" id="mobile" placeholder="Enter Mobile No" maxlength="10" name="mobile" value="<?php echo $mobile; ?>"> 	
				</td> 

			</tr>
		
			<tr>
				<td>	Address :- 	</td>
				<td>	<textarea name="address" id="address" rows="5" cols="30" name="address"> <?php echo $address; ?>  </textarea>
				</td>
			</tr>
			
			

			<tr>
				<td>	Gender :- 	</td>
				<td>	<input type="radio" name="gender_radio" id="gender1" value="Male" <?php if($gender == 'male') { echo 'checked' ;} ?> > Male  
       			  	  	<input type="radio" name="gender_radio" id="gender2" value="Female"  <?php if($gender == 'female') { echo 'checked' ;} ?> > Female 
				  	<input type="radio" name="gender_radio" id="gender3" value="Others"  <?php if($gender == 'others') { echo 'checked' ;} ?> > Others  
				</td>

			</tr>


			<tr>
				<td>	Department :- 	</td>
				<td>	<input type="radio" name="department_radio" value="General"  <?php if($department == 'general') { echo 'checked' ;} ?> > General  
       			  	  	<input type="radio" name="department_radio" value="Marketing"  <?php if($department == 'marketing') { echo 'checked' ;} ?>> Marketing 
				 	<input type="radio" name="department_radio" value="Finance"  <?php if($department == 'finance') { echo 'checked' ;} ?> > Finance  
				</td>
			</tr>
				
			<tr>
				<td>	Technology :- 	</td>
				<td>	
					<?php $row['technology'] = explode(",",$row['technology']); ?>

					<input type="checkbox" name="technology[]" value="React"  <?php if(in_array("React", $row['technology'])) { echo 'checked' ;} ?> > React
					<input type="checkbox" name="technology[]" value="Node"  <?php if(in_array("Node", $row['technology'])) { echo 'checked' ;} ?> >Node
					<input type="checkbox" name="technology[]" value="PHP"   <?php if(in_array("PHP", $row['technology'])) { echo 'checked' ;} ?> > PHP  
				</td>

			</tr>

			<tr>
				<td>	Username :-	 </td>
				<td>	<input type="text" name="username" id="username" placeholder="Enter Username" value="<?php echo $row['username']; ?>"> 
				</td>
			</tr>

			
			<tr>
				<td>	Password :-	</td>
				<td>	<input type="password" id="password" placeholder="Enter Password" name="password" value="<?php echo $row['password']; ?>"> 	
				</td> 
			</tr>

			<tr>
				<td>	</td>
				<td> <input type="submit" name="update" value="Update"> </td>
			</tr>


		</table>
					
	</body>
</html> 

	
