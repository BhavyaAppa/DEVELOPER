<?php include 'connection.php'; ?>
<html>
	<head>
		<title> Submit all Data </title>
		
	<style> 
	h4,.message 
	{
		color: #FF0001;
	}  

	table 
	{
		text-align: center;
	}  
	</style>
		
	</head>

	<body>			
		<?php
			// select query 
			$sql = 'SELECT * FROM user';

			// execute a query
			$select = $connection->query($sql);

			// fetch all rows
			$rows = $select->fetchAll(PDO::FETCH_ASSOC);
		?>
		
		<table border="1">
			<tr>
				<td> <h4> Id </h4> </td>
				<td>  <h4> First Name</h4> </td>
				<td>  <h4> Last Name </h4> </td>
				<td>  <h4> Email </h4> </td>
				<td>  <h4> Country </h4> </td>
				<td> <h4> State   </h4> </td>
				<td>  <h4>City    </h4>  </td>
				<td>  <h4> Mobile  </h4> </td>
				<td>  <h4> Address </h4>  </td>
				<td>  <h4>  Gender </h4>   </td>
				<td> <h4> Department </h4> </td>
				<td> <h4> Technology </h4> </td>
				<td> <h4> Username   </h4> </td>
				<td> <h4> Password  </h4> </td>
			</tr>			
		
 		<?php
			// display all records start from here
			foreach($rows as $row)
			{ 
		?> 		
			<tr>
				<td><?php echo $row['id']; ?></td>
			        <td> <?php echo $row['first_name'] ?> </td>
				<td> <?php echo $row['last_name'] ?> </td>
				<td> <?php echo $row['email'] ?> </td>
				<td> <?php echo $row['country'] ?> </td>
				<td> <?php echo $row['state'] ?> </td>
				<td> <?php echo $row['city'] ?> </td>
				<td> <?php echo $row['mobile'] ?> </td>
				<td> <?php echo $row['address'] ?> </td>
				<td> <?php echo $row['gender'] ?> </td>
				<td> <?php echo $row['department'] ?> </td>
				<td> <?php echo $row['technology'] ?> </td>
				<td> <?php echo $row['username'] ?> </td>
				<td> <?php echo $row['password'] ?> </td>

				<td><a href="user_registration.php?action=edit&id=<?php echo $row['id']; ?>">update</a></td>
				<td><a href="delete_form_data.php?id=<?php echo $row['id']; ?>">Delete</a></td>
		
			</tr>			
		<?php 	
			}
			// display all records end here
		?>		
			
		</table>	
	</body>
</html>







