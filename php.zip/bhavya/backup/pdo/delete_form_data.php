<?php	include"connection.php"; ?>
	
<html>
	<head>	
		<style> 
			table 
			{
				text-align: center;
			}  
		</style>
	</head>

	<body> 

	<?php 
			// declaration start from here
			$id = $row['first_name'] = $row['last_name'] = $row['email'] = $row['country'] = $row['state'] = $row['city'] = $row['mobile'] = $row['address'] = $row['gender'] = $row['department'] = $row['technology'] = $row['username'] = $row['password'] = " ";
			// declaration ends here

		// count total no of request for delete data start from here 
		if(count($_REQUEST)>0) 
		{
				// delete button click start from here
				if(isset($_REQUEST['delete'])) 
				{
					// id set or not start form here
					if (isset($_REQUEST["id"]) && !empty($_REQUEST["id"]))
					{
						$id =  $_REQUEST["id"];
					}
					// id set or not end here

			// try block start from here
			try
			{
					// Prepare a delete statement
				    	$sql = "DELETE FROM user WHERE id = :id";
				    
					// prepare statment start from here
					if($statment = $connection->prepare($sql))
					{
						// Bind variables to the prepared statement as parameters
						$statment->bindParam(":id", $tempId);
						
						// Set parameters
						$tempId = $id;
						
						// execute the prepared statement start from here
						if($statment->execute())
						{
						    // Records deleted successfully. Redirect to landing page
						    echo "Record Delete Successfully";
						} 
						else if(!$statment) 
						{
							echo "\nPDO::errorInfo():\n";
							print_r($connection->errorInfo());
						} 
						// execute the prepared statement end here
					}
					// prepare statment end here
			}
			// try block end here

			// catch block start from here
			catch(PDOException $e)
			{
		    		die("ERROR: Could not connect. " . $e->getMessage());
			}
			// catch block end here
	}
	// count total no of request for delete data end here

		// id set or not start form here
		if (isset($_REQUEST["id"]) && !empty($_REQUEST["id"]))
		{
			$id =  $_REQUEST["id"];
		}
		// id set or not end here

	// try block start from here
	try
	{
		// Prepare a select statement
		$sql = "SELECT * FROM user WHERE id = :id";
	    	
		// prepare statment by if condition start form here
		if($statment = $connection->prepare($sql))
		{
			// Bind variables to the prepared statement as parameters
			$statment->bindParam(":id", $tempId);
			
			// Set parameters	
			$tempId = $id;
        
			// Attempt to execute the prepared statement start from here
			if($statment->execute())
			{
				// count no of records start from here
				if($statment->rowCount() == 1)
				{
					/* Fetch result row as an associative array. Since the result set
					contains only one row, we don't need to use while loop */
					$row = $statment->fetch(PDO::FETCH_ASSOC);	
					$firstName = $row['first_name'];
					$lastName = $row['last_name'];
					$email = $row['email'];	
					$country = $row['country'];
					$state = $row['state'];
					$city = $row['city'];
					$mobile = $row['mobile'];
					$address = $row['address'];
					$gender  = $row['gender'];
					$department = $row['department'];
					$technology = $row['technology'];
					$username = $row['username'];
					$password = $row['password'];					
				} 
				// count no of records end here	
			} 
			// Attempt to execute the prepared statement end here
        	}
		// prepare statment by if condition end here
	}
	// try block end here

	// catch block start from here	
	catch(PDOException $e)
	{
		die("ERROR: Could not connect. " . $e->getMessage());
	}
	// catch block end here

	// Close statement
	unset($statment);
		    
	// Close connection
	unset($connection);

	}
	// delete button click end here

	


		
		?>

		<form name="delete_form_data" method="post" action="">
				
		<table border="1">	

			<tr>
				<td>	FirstName :-	 </td>
				<td>	<?php echo $row['first_name']; ?> </td>		
		 	</tr>

			<tr>
				<td>	LastName :-	 </td>
				<td>	<?php echo $row['last_name']; ?> </td>
		 	</tr>
		
			<tr>
				<td>	Email Id :- 	</td>
				<td>	<?php echo $row['email']; ?>	</td>			
			</tr>
			
			<tr>
				<td> Country :- </td>
				<td> <?php echo $row['country']; ?>	</td>					
			</tr>
		
			<tr>
				<td> State :- </td>
				<td> <?php echo $row['state']; ?>  </td>					
			</tr>

			<tr>
				<td> City :- </td>
				<td> <?php echo $row['city']; ?> </td>			
			</tr>

			<tr>
				<td> Mobile No :- </td>
				<td>	<?php echo $row['mobile']; ?>	</td>		
			</tr>
		
			<tr>
				<td>	Address :- 	</td>
				<td>	<?php echo $row['address']; ?> </td>		
			</tr>

			<tr>
				<td>	Gender :- 	</td>
				<td>	<?php echo $row['gender']; ?>	</td>		
			</tr>

			<tr>
				<td>	Department :- 	</td>
				<td>	<?php echo $row['department']; ?>	</td>		
			</tr>
				
			<tr>
				<td>	Technology :- 	</td>
				<td>	<?php echo $row['technology']; ?>	</td>		
			</tr>

			<tr>
				<td>	Username :-	 </td>
				<td>	<?php echo $row['username']; ?>	</td>		
			</tr>

			<tr>
				<td>	Password :-	</td>
				<td>	<?php echo $row['password']; ?>	</td>		
			</tr>

			<tr>
				<td colspan="2"> <input type="submit" name="delete" value="Delete"> </td>
			</tr>


		</table>
					
	</body>
</html> 

	
