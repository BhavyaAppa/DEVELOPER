<!DOCTYPE html>
<html>
	<head>
		<title> 
			This Is Title of Registration form
		</title>
		
		<h1> Registration Form </h1> 		
       		 	
	</head>  

	<body bgcolor="#f2f2f2">

		<form name="cascadind_dropdownlist" method="post" action=""> 
		
		<table>	

			<tr>
				<td> Country :- </td>
				<td> 
					<select id="country" name="country">
						<option value="" selected="selected"> Select contry </option>
						<?php
							// A sample product array
							$country = array("India", "China", "USA");
							
							// Iterating through the product array
							for($i=0 ; $i<count($country) ; $i++)
							{
							    echo "<option value='$country[$i]'>$country[$i]</option>";
							}
        					?>
					</select>
				</td>			
			</tr>
		
			<tr>
				<td> State :- </td>
				<td> 
					<select id="state" name="state">
						<option value="" selected="selected"> Select State </option>
						<?php
							// A sample product array
							$state = array(
									array("Gujarat", "Maharastra"),
									array("california","florida"),
									array("columbia","Nova Scotia")
									);
							
							// Iterating through the product array
							for($i=0 ; $i < 3 ; $i++)
							{
								for($j=0 ; $j < 3 ; $j++)
								{
							    		echo "<option value='$state[$i][$j]'>$state[$i][$j]</option>";
								}
							}
        					?>

					</select>
				</td>			
			</tr>

			<tr>
				<td> City :- </td>
				<td> 
					<select id="city" name="city">
						<option value="" selected="selected"> Select City </option>
					</select>
				</td>			
			</tr>

		</table>

		</form>	
	</body>
</html>

