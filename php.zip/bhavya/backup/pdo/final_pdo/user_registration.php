<?php 
	require_once('inc/dal/baseclasses/class.database.php');
	require_once('inc/dal/user.child.php');

	// declaration start from here
	$id = $firstName = $lastName = $email = $country = $state = $city = $mobile = $address = $gender = $department = $technology = $username = $password =  "";
	$rsUser['gender'] = $rsUser['department'] = $rsUser[0]['technology'] = " ";
	// declaration ends here

	// if for action is edit or not start from here
	if(isset($_REQUEST['action']) && $_REQUEST['action'] === 'edit')
	{	
		// id set or not start form here
		if (isset($_REQUEST["id"]) && !empty($_REQUEST["id"]))
		{
			$id =  $_REQUEST["id"];
		}
		// id set or not end here
		
		// object create and method call start from here
		$paramArray = array($id);
		$objUser = new userChild();
		$objUser->selectColumn = "first_name, last_name, email, country, state, city, mobile, address, gender, department, technology, username, password"; 
		$objUser->param = $paramArray;
		$objUser->condition = "id = $id";    
		$rsUser = $objUser->selectByColumn();
		$numRowsUser = $objUser->numRows;
		// object create and method call end here

		// check error or not by if condition start from here
		if($numRowsUser > 0 && empty($objUser->error))
		{
			$firstName = $rsUser[0]['first_name']; 
			$lastName = $rsUser[0]['last_name'];
			$email = $rsUser[0]['email'];
			$country = $rsUser[0]['country'];
			$state = $rsUser[0]['state'];
			$city = $rsUser[0]['city'];
			$mobile = $rsUser[0]['mobile'];
			$address = $rsUser[0]['address'];
			$gender = $rsUser[0]['gender'];
			$department = $rsUser[0]['department'];
			$technology = $rsUser[0]['technology'];
			$username = $rsUser[0]['username'];
			$password = $rsUser[0]['password'];
		}

		else
		{
			print_r($objUser->error);
		}
		// check error or not by if condition end here
		unset($objUser); // unset method call for object 
	}
	// if when update button click start from here
	if(isset($_REQUEST['submit']))
	{ 
		// firstname set or not start form here
		if (isset($_REQUEST["firstname"]) && !empty($_REQUEST["firstname"]))
		{
			$firstName =  addslashes($_REQUEST["firstname"]);
		}
		// firstname set or not end here
					
		// lastname set or not start form here
		if (isset($_REQUEST["lastname"]) && !empty($_REQUEST["lastname"]))
		{
			$lastName =  addslashes($_REQUEST["lastname"]);	    	
		}
		// lastname set or not end here
		

		// email set or not start form here
		if (isset($_REQUEST["email"]) && !empty($_REQUEST["email"]))
		{	
			$email =  $_REQUEST["email"];
		}
		// email set or not end here
		

		// country set or not start form here
		if (isset($_REQUEST["country"]) && !empty($_REQUEST["country"]))
		{
			$country = $_REQUEST["country"] ;
		}
		// country set or not end here
		
		
		// state set or not start form here
		if (isset($_REQUEST["state"]) && !empty($_REQUEST["state"]))
		{		
			$state =  $_REQUEST["state"] ;
		}
		// state set or not end here
		

		// city set or not start form here
		if (isset($_REQUEST["city"]) && !empty($_REQUEST["city"]))
		{	
			$city =  $_REQUEST["city"] ;
		}
		// city set or not end here
		

		// mobileno set or not start form here
		if (isset($_REQUEST["mobile"]) && !empty($_REQUEST["mobile"]))
		{
			$mobile =  $_REQUEST["mobile"] ;
		}
		// mobileno set or not end here
		

		// address set or not start form here
		if (isset($_REQUEST["address"]) && !empty($_REQUEST["address"]))
		{
			$address = $_REQUEST["address"] ;
		}
		// address set or not end here
		

		// gender set or not start form here
		if (isset($_REQUEST["gender_radio"]) && !empty($_REQUEST["gender_radio"]))
		{	
			$gender = $_REQUEST["gender_radio"] ;		
		}
		// gender set or not end here
		
		
		// department set or not start form here
		if (isset($_REQUEST["department_radio"]) && !empty($_REQUEST["department_radio"]))
		{
			$department = $_REQUEST["department_radio"] ;
		}
		// department set or not start form here
		

		// technology set or not start form here
		if (isset($_REQUEST["technology"]) && !empty($_REQUEST["technology"]))
		{	
			foreach( $_REQUEST["technology"] as $values )
			{
				$technology = $_REQUEST["technology"] ;
			}
		}
		

		// technology set or not end here
		
		// username set or not start form here
		if (isset($_REQUEST["username"]) && !empty($_REQUEST["username"]))
		{
			$username = $_REQUEST["username"] ;	
		}
		// username set or not end here
		
		// password set or not start form here
		if (isset($_REQUEST["password"]) && !empty($_REQUEST["password"]))
		{
			$password = $_REQUEST["password"] ;		
		}
		// password set or not end here
		
		
		// array convert into string start from here
		if( isset( $technology ) && !empty( $technology ) )
		{
			$technology = implode( "," , $technology );
		}
		// array convert into string end here
		
		$currentDateTime = date("Y-m-d H:i:s"); // set record modified time 

		// id set or not start form here
		if (isset($_REQUEST["id"]) && !empty($_REQUEST["id"]))
		{
			$id =  $_REQUEST["id"]; // id set or not end here
			$objUser = new user();
			$objUser->first_name = $firstName;
			$objUser->last_name = $lastName;
			$objUser->email = $email;
			$objUser->country = $country;
			$objUser->state = $state;
			$objUser->city = $city;
			$objUser->mobile = $mobile;
			$objUser->address = $address;
			$objUser->gender = $gender;
			$objUser->department = $department;
			$objUser->technology = $technology;
			$objUser->username = $username;
			$objUser->password = $password;
			$objUser->modified = $currentDateTime; 
			$objUser->condition = "id = $id";
			$objUser->update();
			if(empty($objUser->error))
			{
				echo "Record Update Successfully";
			}
			else 
			{
				print_r($objUser->error);
			}
			unset($objUser); 
		}
		else
		{
			$objUser = new user();
			$objUser->first_name = $firstName;
			$objUser->last_name = $lastName;
			$objUser->email = $email;
			$objUser->country = $country;
			$objUser->state = $state;
			$objUser->city = $city;
			$objUser->mobile = $mobile;
			$objUser->address = $address;
			$objUser->gender = $gender;
			$objUser->department = $department;
			$objUser->technology = $technology;
			$objUser->username = $username;
			$objUser->password = $password;
			$objUser->created = $currentDateTime;
			$objUser->modified = $currentDateTime;
			$objUser->insert();
			$lastInsertedId = $objUser->id;
			if (($lastInsertedId > 0) && (empty($objUser->error))) 
			{
				echo "Records Insert Successfully";
			}
			else 
			{
				print_r($objUser->error);
			}
			unset($objUser);
		}
	}
	// update button click end here
?>
<!DOCTYPE html>
<html>
	<head>
		<title> 
			This Is Title of Registration form
		</title>
		
		<h1> Registration Form </h1> 

		<script  type="text/javascript">
			var countryObject = 
			{
				// Value Initialization Dynamically Start From Here
				"India": 
					 {
						"Gujarat": ["Ahmedabad","Surat","Baroda"],
						"Maharastra": ["Bombay","Nagpur","Pune"],
						"Goa": ["Ponda", "Margao", "Mapusa"]
					},
				"USA": 
					{
						"California": ["Alameda","Belmont","Calistoga"],
						"Florida": ["Boca Raton","Cocoa Beach","De Land"]
					},

				"Canada": 
					{
						"British Columbia": ["Dawson Creek","Delta"," Esquimalt"],
						"Nova Scotia": ["Baddeck","Digby","Glace Bay"]

					}

				// Value Initialization Dynamically Ends Here
			}

			// Onload Function Starts From Here		
			window.onload = function()
			{
				// Variable Declaration Start From Here
				var country = document.getElementById( "country" ); 
				var state = document.getElementById( "state" );
				var city = document.getElementById( "city" );
				// Variable Declaration Ends Here
			
				//  For Loop Start For Contry Object From Here
				for (var x in countryObject) 
				{
				    country.options[country.options.length] = new Option(x, x);
				}
				//  For Loop Ends For Contry Object Here

				// Onchange Function For State Starts From Here
				country.onchange = function() 
				{
					city.length = 1;
					state.length = 1;

				    	// display correct values Using For Loop Starts From Here
					for (var y in countryObject[this.value])
					{
						state.options[state.options.length] = new Option(y, y);
					}	
					// display correct values Using For Loop Ends Here
				}	
				// Onchange Function For State Ends Here

				// Onchange Function For City Starts From Here
				state.onchange = function() 
				{
					//empty City dropdown
					city.length = 1;

					// correct values Using For Loop Start From Here
					var z = countryObject[country.value][this.value];

					for (var i = 0; i < z.length; i++) 
					{
				      		city.options[city.options.length] = new Option(z[i], z[i]);
				    	}
					// correct values Using For Loop Ends Here
				  }
				// Onchange Function For City Ends Here		
			}
			// Onload Function Ends Here

		</script>	
       		 	
	</head>  

	<body bgcolor="#f2f2f2">


		<form name="user_registration" method="post" action=""> 
		
		<table>	

			<tr>
				<td>	FirstName :-	 </td>
				<td>	<input type="text" name="firstname" id="firstname" placeholder="Enter FirstName" autofocus="autofocus" value="<?php echo isset($_REQUEST['action']) && $_REQUEST['action']=="edit" ? $firstName : ""; ?>">
				</td>		
		 	</tr>

			<tr>
				<td>	LastName :-	 </td>
				<td>	<input type="text" name="lastname" id="lastname" placeholder="Enter LastName" value="<?php echo isset($_REQUEST['action']) && $_REQUEST['action']=="edit" ? $lastName : ""; ?>"> 
				</td>
		 	</tr>
		
			<tr>
				<td>	Email Id :- 	</td>
				<td>	
					<input type="text" name="email" id="email" placeholder="Enter Email" value="<?php echo isset($_REQUEST['action']) && $_REQUEST['action']=="edit" ? $email : ""; ?>">	
				</td>			
			</tr>
			
			<tr>
				<td> Country :- </td>
				<td> 
					<select id="country" name="country">
						<option value="<?php echo isset($_REQUEST['action']) && $_REQUEST['action']=="edit" ? $country : ""; ?>">  country </option>
					</select>
				</td>			
			</tr>
		
			<tr>
				<td> State :- </td>
				<td> 
					<select id="state" name="state">
						<option value="<?php echo isset($_REQUEST['action']) && $_REQUEST['action']=="edit" ? $state : ""; ?>">  state </option>
					</select>
				</td>			
			</tr>

			<tr>
				<td> City :- </td>
				<td> 
					<select id="city" name="city">
						<option value="<?php echo isset($_REQUEST['action']) && $_REQUEST['action']=="edit" ? $city : ""; ?>">  city </option>
					</select>
				</td>			
			</tr>

			<tr>
				<td>	Mobile No :-	</td>
				<td>	<input type="phone" id="mobile" placeholder="Enter Mobile No" maxlength="10" name="mobile" value="<?php echo isset($_REQUEST['action']) && $_REQUEST['action']=="edit" ? $mobile : ""; ?>"> 	
				</td> 

			</tr>
		
			<tr>
				<td>	Address :- 	</td>
				<td>	<textarea name="address" id="address" rows="5" cols="30" name="address"> <?php echo isset($_REQUEST['action']) && $_REQUEST['action']=="edit" ? $address : ""; ?>  </textarea>
				</td>
			</tr>
			
			<tr>
				<td>	Gender :- 	</td>
				<td>	<input type="radio" name="gender_radio" id="gender1" value="Male" <?php if($gender == 'male') { echo 'checked' ;} ?> > Male  
       			  	  	<input type="radio" name="gender_radio" id="gender2" value="Female"  <?php if($gender == 'female') { echo 'checked' ;} ?> > Female 
				  	<input type="radio" name="gender_radio" id="gender3" value="Others"  <?php if($gender == 'others') { echo 'checked' ;} ?> > Others  
				</td>

			</tr>


			<tr>
				<td>	Department :- 	</td>
				<td>	<input type="radio" name="department_radio" value="General"  <?php if($department == 'general') { echo 'checked' ;} ?> > General  
       			  	  	<input type="radio" name="department_radio" value="Marketing"  <?php if($department == 'marketing') { echo 'checked' ;} ?>> Marketing 
				 	<input type="radio" name="department_radio" value="Finance"  <?php if($department == 'finance') { echo 'checked' ;} ?> > Finance  
				</td>
			</tr>

			<tr>
				<td>	Technology :- 	</td>
				<td>	
					<?php $rsUser['technology'] = explode(",",  $rsUser[0]['technology']); ?>

					<input type="checkbox" name="technology[]" value="React"  <?php if(in_array("React",$rsUser['technology'])) { echo 'checked' ;} ?> > React
					<input type="checkbox" name="technology[]" value="Node"  <?php if(in_array("Node", $rsUser['technology'])) { echo 'checked' ;} ?> >Node
					<input type="checkbox" name="technology[]" value="PHP"   <?php if(in_array("PHP", $rsUser['technology'])) { echo 'checked' ;} ?> > PHP  
				</td>

			</tr>

			<tr>
				<td>	Username :-	 </td>
				<td>	<input type="text" name="username" id="username" placeholder="Enter Username" value="<?php echo isset($_REQUEST['action']) && $_REQUEST['action']=="edit" ? $username : ""; ?>">
				</td>
			</tr>

			
			<tr>
				<td>	Password :-	</td>
				<td>	<input type="password" id="password" placeholder="Enter Password" name="password" value="<?php echo isset($_REQUEST['action']) && $_REQUEST['action']=="edit" ? $password : ""; ?>">  	
				</td> 
			</tr>
			<!-- <tr>	<td>	</td>	<td>	</td>	</tr>	 -->

			<!-- <tr>	<td>	</td>	<td>	</td>	</tr> -->
			
			<tr>
				<td> 	<input type="submit" name="submit" value="<?php echo isset($_REQUEST['action']) && $_REQUEST['action']=="edit" ? "update" : "insert"; ?>" >	</td>
				
				<td> 	<input type="button" value="List" name="fetch" onclick="window.location='display_form_data.php'"> </td>
			</tr> 


		</table>

		</form>	
	</body>
</html>

