<!-- 
    Created by Khyati panchal 28 Feb 2022
    file name : add_contract.php
 -->

<?php
    ini_set('max_execution_time', '0'); // for infinite time of execution
    ini_set('upload_max_size', '128MB');
    ini_set( 'post_max_size', '128MB');
    ini_set( 'memory_limit', '512MB');
    require_once 'inc/php/config.php';
    require_once 'inc/dal/baseclasses/class.database.php';
    require_once 'inc/dal/contract_master.child.php';
    require_once 'inc/dal/settings.child.php';
    require_once 'inc/php/functions.php';

    $codeUrl = getCodeUrl(); // call function and get code url
    $formAction = 'add'; // action = add
    
    if((isset($_REQUEST['action']) && !empty($_REQUEST['action'])) && isset($_REQUEST['id']) && !empty($_REQUEST['id']))
    {
        $formAction = $_REQUEST['action']; // action = edit
        $contractId = $_REQUEST['id'];
        $hdnContractId = $contractId; // update $hdnContractId
    }   
?>

<!doctype html>
<html class="no-js">

<head>
    <title><?php echo ucfirst($formAction); ?> Contract</title>
    <?php require_once ('inc/php/head.php'); ?>
    
    <style type="text/css">
	#drop-area
	{
            border: 2px dashed #ccc;  
            padding: 35px 0px;
	}
	#drop-area.highlight {
	  border-color: #4048af;
	}
	.my-form {
	  margin-bottom: 10px;
	}
	#gallery {
	  margin-top: 10px;
	}
	#gallery img {
	  width: 150px;
	  margin-bottom: 10px;
	  margin-right: 10px;
	  vertical-align: middle;
	}
	#imageGallery {
	  display: none;
	}
	.addImage .uploadBy input {

	   position:absolute;
		opacity: 0;
	}
    </style>
    
    <script src="inc/js/jquery-ui.js"></script>

    <link rel="stylesheet" href="inc/css/jquery.timepicker.css">
    <script src="inc/js/jquery.timepicker.js"></script>
    

    <script type="text/javascript">
        var codeUrl = '<?php echo $codeUrl; ?>'; // code url
        var formAction = '<?php echo $formAction;?>'; // action = add, edit
        var imageNameInEditMode = '';
        
        // onload start
        $(document).ready(function() 
        {
            $("#sortable").sortable({
                update: function (event, ui)
                {
                    var attr = $(this).sortable('toArray');
                    console.log('attr ::: '+attr);
                    $("#hdnDisplayOrder").val(attr);
                    resetNumber();
                },
            }); // end sortable here
            
            if(formAction == 'edit')
            {
                var contractId = '<?php echo $contractId; ?>'; 
                getContractDataThroughAjax(contractId); 
            }
            $('#txtStartDate').datepicker({
			dateFormat: 'mm-dd-yy',
			onSelect:function(selectedDate, datePicker) {            
			}
		});
            $('#txtEndDate').datepicker({
                   dateFormat: 'mm-dd-yy',
                   onSelect:function(selectedDate, datePicker) {            
                   }
           });
        });
        // onload end

        // function start here
        function getContractDataThroughAjax(contractId)
        {
            var finalUrl = codeUrl + "api/contract_master.php" ; // final url
           
            // ajax start
            $.ajax({
                    type: "POST",
                    url: finalUrl,
                    data : "action=get_contract_data&contract_id="+contractId,
                    cache: true,
                    async: true,
                    timeout: 30000,
                    dataType : "json",
                    beforeSend: function() 
                    {
                        $("#addContractLoader").show(); // start loader
                    },
                    success: function(response) 
                    {
                        var status = response.header.status; // get status code
                        var message = response.header.message; // get message

                        console.log("status ::"+status);
                        console.log("message ::"+message);

                        if (status === 200 && message == 'OK') 
                        {
                            var data = response.data; // get data
                            console.log("data :: " + JSON.stringify(data));

                            if(data)
                            {
                                var id = data[0].id; 
                                var title = data[0].title; 
                                var description = data[0].description; 
                                var hyperlink = data[0].hyperlink; 
                                var supplierId = data[0].supplier_id; 
                                var supplierName = data[0].supplier_name; 
                                $('#hiddenSelectedSupplier').val(supplierId);
                                $("#supplier").val(supplierName);
                                if(supplierName != undefined)
                                    $('#removeSelectedSupplier').show();
                                
                                var contactPersonName = data[0].contact_person_name; 
                                var contactPersonNumber = data[0].contact_number; 
                                var otherPhoneNumber = data[0].other_phone_number; 
                                var cost = data[0].cost; 
                                var noEndDate = data[0].no_end_date; 
                                var softwareContract = data[0].software_contract; 
                                var numberOfLicences = data[0].number_of_licences; 
                                var startDate = data[0].start_date; 
                                var endDate = data[0].end_date; 
                                if(noEndDate == 1)
                                {
                                    $("#txtNoEndDate").attr('checked', 'checked');
                                }
                                if(softwareContract == 1)
                                {
                                    $("#txtSoftwareContract").attr('checked', 'checked');
                                }
                                
                                //Attachement code
                                var imageNameInEditModeFetch = data[0].imageNameEditMode;
                                
                                if(imageNameInEditModeFetch == 'undefined' || imageNameInEditModeFetch == undefined)
                                {
                                    imageNameInEditMode = '';
                                }
                                else
                                {
                                    imageNameInEditMode = imageNameInEditModeFetch;
                                    //alert("here >> "+imageNameInEditMode);
                                }
                                $("#hdnValidImage").val(imageNameInEditMode);
                                
                                var displayOrder = data[0].display_order;
                                $("#hdnDisplayOrder").val(displayOrder);
                                var attachment = JSON.parse(data[0].attachment);
                                var lengthOfAttachment = Object.keys(attachment).length;
                                var count = 1;
                                var html = '';
                                if(lengthOfAttachment > 0)
                                {
                                    $('#filePreviewDiv').show();
                                    $.each(attachment, function(index,value)
                                    {
                                        var imageName = value;
                                        var extensionSplit = imageName.split('.');
                                        var extension = extensionSplit[extensionSplit.length-1];
                                        //alert("extension  "+extension+" name > "+imageName);
                                        var imagePath = codeUrl+'uploads/contract/'+id+'/'+imageName;
                                        
                                        html += '<li id="li_'+count+'">';
                                        html += '<a href="javascript:;" class="remove" onclick="deleteImageInEditMode('+count+',`'+imageName+'`)"><i class="fa fa-close"></i>X</a>';
                                        html += '<div class="thumb">';
                                        html += '<img src='+imagePath+' width="100px" height="100px" /><br/>';  
                                        html += '<span>'+imageName+'</span>';
                                        html += '</div>';
                                        html += '<div class="number"><label>'+count+'</label>';
                                        html += '</div>';
                                        html += '</li>';
                                        count++;
                                    });
                                    $('#sortable').html(html);
                                }
                                
                                $("#txtTitle").val(title);
                                $("#txtDescription").val(description);
                                $("#txtHyperlink").val(hyperlink);
                                $("#txtContactPersonName").val(contactPersonName);
                                $("#txtContactNumbers").val(contactPersonNumber);
                                $("#txtOtherNumbers").val(otherPhoneNumber);
                                $("#txtCost").val(cost);
                                $("#txtNoOfLicence").val(numberOfLicences);
                                $("#txtStartDate").val(startDate);
                                $("#txtEndDate").val(endDate);
                            }
                        }
                        else 
                        {
                            $("#errorMessageDiv").show();
                            $("#errorMessageLableId").text('');
                            $("#errorMessageLableId").text(message);	
                        }
                    },
                    error: function(XMLHttpRequest, errorStatus, errorThrown) 
                    {
                        console.log("XHR :: "+JSON.stringify(XMLHttpRequest));
                        console.log("Status :: "+errorStatus);
                        console.log("error :: "+errorThrown);
                        var errorStatus = XMLHttpRequest['status'];
                        if(errorThrown == 'timeout')
                        {
                            alert('Request has been timeout. Please check your internet connection! (Error: '+errorStatus+')');
                        }
                        else
                        {
                            alert('There is something wrong! Please try again! (Error: '+errorStatus+')');
                        }
                    },
                    complete: function() 
                    {
                        $("#addContractLoader").hide(); // hide loader
                    }
            });
    // ajax end here
        }
        // function end here : getContractDataThroughAjax
        
        // function start here
        function addContractValidation() 
        {
            var isFormValidate = true; // set flag
            var txtTitle = $("#txtTitle").val();
            var txtStartDate = $("#txtStartDate").val();
            
            if (txtTitle == '' || txtTitle == null || txtTitle == undefined) 
            {
                $("#errorTitle").text('Title is required');
                $("#errorTitle").show();
                isFormValidate = false;
            }
            if(txtStartDate == '')
            {
                $("#errorStartDate").text('Start date is required');
                $("#errorStartDate").show();
                isFormValidate =  false;
            }

            navigateToErrorMessage(); // call function for navigate user to specific error message location

            if (isFormValidate) 
            {
                $("#addContractLoader").show(); // show loader
                submitDataThroughAjax();
            } 
            else 
            {
                $("#addContractLoader").hide(); // hide loader
                return false;
            }

        } 
        // addDistrictValidation end

        // function start here
        function navigateToErrorMessage() 
        {
            if($(".validation span").is(":visible"))
            {
                var errorMessageOffset = $(".validation span:visible:first-child").offset().top;
                $('html, body').animate({scrollTop: (errorMessageOffset - 70)}, 700);
            }
        }
        // function end here : navigateToErrorMessage

        // function start here
        function submitDataThroughAjax() 
        {
            var formData1 = new FormData(); // create object
            var allRequestData = $('#addContractForm').serializeArray();
            
            //alert("allRequestData >> "+JSON.stringify(allRequestData));

            $.each(allRequestData,function(key,input)
            {
                // alert("name >> "+input.name+" value >> "+input.value);
                formData1.append(input.name,input.value);
            });
            
            for (var value of formData.entries()) 
            {
                //console.log(value[0]+" >> "+value[1]);
                formData1.append(value[0],value[1]);
            }
            
            //alert("formData >> "+JSON.stringify(formData));

            var finalUrl = codeUrl+"api/contract_master.php"; // finalUrl
            
            $.ajax({
                type: "POST",
                url: finalUrl,
                data: formData1,
                dataType: "json",
                contentType:false,
                cache: false,
                processData: false,
                timeout : 0, 
                beforeSend : function()
                {
                    $("#addContractLoader").show(); // show loader
                },
                success: function(response)
                {
                    var status = response.header.status; // get status code
                    var message = response.header.message; // get message

                    console.log("status ::"+status);
                    console.log("message ::"+message);
                    
                    if(status == 200)
                    {
                        window.location.href="contract.php"; // redirect on page
                    } 
                    else
                    {
                        $("#errorMessageDiv").show();
                    	$("#errorMessageLableId").text('');
                        $("#errorMessageLableId").text(message);
                    }
                    return false;
                },
                error: function(XMLHttpRequest, errorStatus, errorThrown) 
                {
                    console.log("XHR :: "+JSON.stringify(XMLHttpRequest));
                    console.log("Status :: "+errorStatus);
                    console.log("error :: "+errorThrown);
                    var errorStatus = XMLHttpRequest['status'];
                    if(errorThrown == 'timeout')
                    {
                        alert('Request has been timeout. Please check your internet connection! (Error: '+errorStatus+')');
                        return false;
                    }
                    else
                    {
                        alert('There is something wrong! Please try again! (Error: '+errorStatus+')');
                        return false;
                    }
                },
                complete:function()
                {
                    $("#addContractLoader").hide(); // hide loader
                }
            });
            return false;
        }
        // function ends here : submitDataThroughAjax

        // function start here
        function hideErrorMessage(id) 
        {
            $("#" + id).hide(); // hide error message
        } 
        // fuction end here : hideErrorMessage
        
        /*Supplier*/
        function getSuppliers()
        {
            var alreadyAddedSupplierId = $("#hiddenSelectedSupplier").val();

            $("#supplier").autocomplete({
                source : function(request,response)
                {
                    $.ajax({
                            type : "POST",
                            url : codeUrl+"api/get_all_supplier.php?startWith="+request.term+'&alreadyAddedSupplierId='+alreadyAddedSupplierId,
                            async : true,
                            cache : true,
                            timeout : 30000,
                            dataType : "json",
                            beforeSend : function()
                            {
                              $("#supplierLoader").show();  
                            },
                            success : function(result)
                            {
                                //alert("inside success !! "+result);
                               response(result);
                            },
                            error: function(XMLHttpRequest, errorStatus, errorThrown) 
                            {
                                console.log("XHR :: "+JSON.stringify(XMLHttpRequest));
                                console.log("Status :: "+errorStatus);
                                console.log("error :: "+errorThrown);
                                var errorStatus = XMLHttpRequest['status'];
                                if(errorThrown == 'timeout')
                                {
                                    alert('Request has been timeout. Please check your internet connection! (Error: '+errorStatus+')');
                                }
                                else
                                {
                                    alert('There is something wrong! Please try again! (Error: '+errorStatus+')');
                                }
                            },
                            complete : function()
                            {
                                $("#supplierLoader").hide();
                            }
                    });
                },
                autoFocus: true,	      	
                minLength: 0,
                appendTo: "#supplierDiv",
                select : function(event,ui)
                {
                    $('#hiddenSelectedSupplier').val(ui.item.id);
                    $("#supplier").val(ui.item.label);
                    $('#removeSelectedSupplier').show();
                    fillOtherInformation(ui.item.id);
                    return false;
                } })._renderItem = function (ul, item) 
                {
                if(item.label == 'No record found')
                {
                    t = "<div class='noSuggestionFound'>"+item.label+"</div>";
                    return $( "<li></li>" )
                            .data( "item.autocomplete", t )
                            .append( t )	//append <span> tag with display none to get location item id
                            .appendTo("#supplierDiv ul" );
                }
                else
                {
                    var originalValue = item.label;

                    var splitedVal = originalValue;
                    var textValue = $("#supplier").val();

                    if(textValue != '*')
                    {
                        var t = String(splitedVal).replace(new RegExp(this.term, "gi"),"<strong>$&</strong>");
                    }
                    else
                    {
                        var t = splitedVal;
                    }
                    var itemVal = t;
                    return $( "<li></li>" )
                            .data( "item.autocomplete", itemVal )
                            .append( "<a>" + itemVal + "</a>" )	//append <span> tag with display none to get location item id
                            .appendTo("#supplierDiv ul");
                }
            };
        }//function ends here.
        function removeSelectedSupplier()
        {
            $('#supplier').val('');
            $('#hiddenSelectedSupplier').val('');
            $("#removeSelectedSupplier").hide();
        } //Function ends here.
        
        function fillOtherInformation(selectedSupplierId)
        {
            var finalUrl = codeUrl + "api/contract_master.php" ; // final url
           
            // ajax start
            $.ajax({
                    type: "POST",
                    url: finalUrl,
                    data : "action=get_supplier_info&supplier_id="+selectedSupplierId,
                    cache: true,
                    async: true,
                    timeout: 30000,
                    dataType : "json",
                    beforeSend: function() 
                    {
                        $("#addContractLoader").show(); // start loader
                    },
                    success: function(response) 
                    {
                        var status = response.header.status; // get status code
                        var message = response.header.message; // get message

                        console.log("status ::"+status);
                        console.log("message ::"+message);

                        if (status === 200 && message == 'OK') 
                        {
                            var data = response.data; // get data
                            console.log("data :: " + JSON.stringify(data));

                            if(data)
                            {
                                var contactPersonName = data[0].contact_person_name; 
                                var mobileNumber = data[0].mobile_number; 
                                
                                $("#txtContactPersonName").val(contactPersonName);
                                $("#txtContactNumbers").val(mobileNumber);
                            }
                        }
                        else 
                        {
                            $("#errorMessageDiv").show();
                            $("#errorMessageLableId").text('');
                            $("#errorMessageLableId").text(message);	
                        }
                    },
                    error: function(XMLHttpRequest, errorStatus, errorThrown) 
                    {
                        console.log("XHR :: "+JSON.stringify(XMLHttpRequest));
                        console.log("Status :: "+errorStatus);
                        console.log("error :: "+errorThrown);
                        var errorStatus = XMLHttpRequest['status'];
                        if(errorThrown == 'timeout')
                        {
                            alert('Request has been timeout. Please check your internet connection! (Error: '+errorStatus+')');
                        }
                        else
                        {
                            alert('There is something wrong! Please try again! (Error: '+errorStatus+')');
                        }
                    },
                    complete: function() 
                    {
                        $("#addContractLoader").hide(); // hide loader
                    }
            });
    // ajax end here
        }

    </script>
</head>
<body class="noMenu">
<!--
	================
	Header Start
	================
-->

<?php require_once ('inc/php/header.php'); ?>

<!-- 
	=============== 
	Page Title Start
	=============== 
-->
<section class="pageTitle">
    <h1><?php echo ucfirst($formAction); ?> Contract</h1>
    <a href="contract.php" class="back">Back</a>
    <div class="clr"></div>
</section>
<!-- 
	=============== 
	Page Title End
	=============== 
-->
<!-- 
	===============
	Page Content Start 
	===============
-->
<section class="pageContent widget">

    <!--
		===================
		Alert :: Success
		===================
	-->
    <div class="alert alert-success" style="display: none;" id="successMessageDiv">
        <img src="images/success-tik.svg" />
        <strong>Success!</strong>
        <lable id="successMessageLableId"></lable>
    </div>

	<!--
		===================
		Alert :: Error
		===================
	-->
    <div class="alert alert-error" style="display: none;" id="errorMessageDiv">
        <img src="images/error_x.svg" />
        <strong>Error!</strong>
        <lable id="errorMessageLableId"></lable>
    </div>
	
	<!-- 
    Created by Khyati panchal 25 Feb 2022
    file name : supplier_form.php
 -->
    <!-- form stat -->
    <form id="addContractForm" name="addContractForm" method="post" enctype="multipart/form-data" >
        <div class="card">
            <ul class="form">
                <li>
                    <div class="lbl">Title<span>*</span></div>
                    <div class="val">
                        <input autocomplete="off" type="text" class="input " placeholder="Enter Title" id="txtTitle" name="txtTitle" onkeypress="hideErrorMessage('errorTitle');" value='' />
                        <div class="validation">
                            <span style="display:none;" id="errorTitle"></span>
                        </div>
                    </div>
                    <!-- value Ends -->
                </li>
                <li>
                    <div class="lbl">Description<span></span></div>
                    <div class="val">
                        <textarea id='txtDescription' name='txtDescription'></textarea>
                        <div class="validation">
                            <span style="display:none;" id="errorDescription"></span>
                        </div>
                    </div>
                    <!-- value Ends -->
                </li>
                <li>
                    <div class="lbl">Hyperlink<span></span></div>
                    <div class="val">
                        <input autocomplete="off" type="text" class="input " placeholder="Enter Hyperlink" id="txtHyperlink" name="txtHyperlink" value='' />
                        <div class="validation">
                            <span style="display:none;"></span>
                        </div>
                    </div>
                    <!-- value Ends -->
                </li>
                <li>
                    <div class="lbl">Select Supplier<span></span></div>
                    <div class="val">
                        <div class="multiSuggestion" style="width:60%;">
                            
                        <div class="inputLoader" style="display:none;" id="supplierLoader">
                            <span class="spinLoader small"></span>
                        </div>
                            <?php
                            if(count($tagListArray) > 0)
                            {
                                foreach($tagListArray[0] as $tagKey => $supplierValue)
                                {
                                    $supplierValue = $supplierValue;
                                }
                            }
                                ?>
                            <input type="text" id="supplier" name="supplier" class="input" placeholder="Enter * to view all Supplier" onkeypress="getSuppliers()" value="<?php echo $supplierValue; ?>"/>
							
                            <a href="javascript:;" onclick="removeSelectedSupplier();" id='removeSelectedSupplier' style='display:none;'>X</a>
                           

                            <div class="suggestion" id="supplierDiv"></div>

                        </div>
						
                        <div class="validation">
                            <span style="display: none;"></span>
                        </div>
                    </div> <!-- value Ends -->
                    <input type="hidden" name= "hiddenSelectedSupplier" id="hiddenSelectedSupplier" value="<?php if($fetchedTagMasterId != '') echo $fetchedTagMasterId; ?>">
                    <div class="clr"></div>
                </li>
                <li>
                    <div class="lbl">Contact Person Name<span></span></div>
                    <div class="val">
                        <input autocomplete="off" type="text" class="input " placeholder="Enter Contact Person Name" id="txtContactPersonName" name="txtContactPersonName" value='' />
                        <div class="validation">
                            <span style="display:none;"></span>
                        </div>
                    </div>
                <!-- value Ends -->
                </li>
                <li>
                    <div class="lbl">Contact Person Mobile Number<span></span></div>
                    <div class="val">
                        <input autocomplete="off" type="email" class="input " placeholder="Enter Contact Number" id="txtContactNumbers" name="txtContactNumbers"  value='' />
                        <div class="validation">
                            <span style="display:none;" ></span>
                        </div>
                    </div>
                    <!-- value Ends -->
                </li>
                <li>
                    <div class="lbl">Other Phone Number<span></span></div>
                    <div class="val">
                        <input autocomplete="off" type="email" class="input " placeholder="Enter Contact Number" id="txtOtherNumbers" name="txtOtherNumbers" value='' />
                        <div class="validation">
                            <span style="display:none;"></span>
                        </div>
                    </div>
                    <!-- value Ends -->
                </li>
                <li>
                    <div class="lbl">Cost<span></span></div>
                    <div class="val">
                        <input type="number" id="txtCost" name="txtCost">
                        <div class="validation">
                            <span style="display:none;"></span>
                        </div>
                    </div>
                    <!-- value Ends -->
                </li>
                <li>
                <div class="lbl">Start Date<span>*</span></div>
                <div class="val">
                    <input autocomplete="off" type="text" class="input " placeholder="Enter Start Date" id="txtStartDate" name="txtStartDate" onchange="hideErrorMessage('errorStartDate');" value='' />
                    <div class="validation">
                        <span style="display:none;" id='errorStartDate'></span>
                    </div>
                </div>
                <!-- value Ends -->
            </li>
            <li>
                <div class="lbl">End Date<span></span></div>
                <div class="val">
                    <input autocomplete="off" type="text" class="input " placeholder="Enter End Date" id="txtEndDate" name="txtEndDate" value='' />
                    <div class="validation">
                        <span style="display:none;" ></span>
                    </div>
                </div>
                <!-- value Ends -->
            </li>
            <li>
                <div class="lbl">No end date?<span></span></div>
                <div class="value" style="padding-top:10px;">
                    <label class="checkbox">   
                        <input type="checkbox" id="txtNoEndDate" name="txtNoEndDate" value="1" for="1" />
                            <span class="checkmark"></span>
                            Yes
                    </label>

                    <div class="validation"><span></span></div>
                </div> <!-- value Ends -->
            </li>
            <li>
                <div class="lbl">No. of licence<span></span></div>
                <div class="val">
                    <input type="number" id="txtNoOfLicence" name="txtNoOfLicence">
                    <div class="validation">
                        <span style="display:none;"></span>
                    </div>
                </div>
                <!-- value Ends -->
            </li>
            <li>
                <div class="lbl">Software contract?<span></span></div>
                <div class="value" style="padding-top:10px;">
                    <label class="checkbox">   
                        <input type="checkbox" id="txtSoftwareContract" name="txtSoftwareContract" value="1" for="1" />
                            <span class="checkmark"></span>
                            Yes
                    </label>

                    <div class="validation"><span></span></div>
                </div> <!-- value Ends -->
            </li>
            <!--File Attachement -->
            <div class="fileAttachments">
	
            <!--
                    =================
                    Drag & Drop Panel
                    =================
            -->
            <div class="addPhotoPanel">

                <!-- Drag & Drop -->
                <div class="dragPhoto" id="drop-area" for="uploadFile">			   <p>
                        <strong>
                            <i class="fa fa-camera"></i> 
                            <i class="fa fa-file-text-o"></i>
                        </strong>
                        Drag &amp; drop your<br> files here
                    </p>
                        <span>Or</span>
                        <label for="uploadFile">Browse</label>
                        <input type="file" id="uploadFile" name="uploadFile[]" onchange="previewImage(this);" multiple />
                </div>

                <!-- Photo Info -->
                <div class="photoInfo">
                    <h5>Image specification</h5>
                    <p>Image size must be less than 10 MB</p>
                    <p>Image dimensions must be more than 400 X 400 px</p>
                    <p>Image format must be JPG, JPEG, PNG</p>
                    <p>Make sure the image is not blurred</p>

                    <div class="validation" id="validationMsgDiv">
                    </div>
                </div>
            </div>
            <!--
                    =================
                    Display image
                    =================
            -->
            <?php
            $display = 'style="display:none;"';
            if($numROws > 0)
            {
                $display = 'style="display:block;"';
            }
            ?>
            <div class="uploadedImages" id="filePreviewDiv" <?php echo $display;?>>
            <!--<p>Drag & Drop  to reorder</p>-->
            <ul id="sortable" >
            
                <!--<li id="<?php //echo $count ; ?>">
                    <a href="javascript:;" class="remove" onclick="deleteImageInEditMode('<?php //echo $count; ?>','<?php //echo $imageName; ?>')"><i class="fa fa-close"></i></a>
                    <div class="thumb">
                        <img src="<?php//echo $imagePath; ?>" width="100px" height="100px" /><br/>  
                        <span><?php //echo $imageName; ?></span>
                    </div>
                    <div class="number"><label><?php //echo $count ; ?></label>	</div>
                </li>-->
            </ul>
            </div>

            <input type="hidden" id="hdnValidImage" name="hdnValidImage" value="<?php echo $imageNameInEditMode; ?>">
            <input type="hidden" id="hdnDisplayOrder" name="hdnDisplayOrder" value="<?php echo $displayOrder;?>">
            <input type="hidden" id="hdnDeletedImageName" name="hdnDeletedImageName" value="">
            <input type="hidden" id="hdnTotalImage" name="hdnTotalImage" value="0">
			
            </div>
        </ul>
    </div>

        <div class="submitBtn submit" style="display:inline-block; margin-left:calc(250px + 20px);">
            <div class="btnLoader" id="addContractLoader" style="display:none;">
                <span class="spinLoader"></span>
            </div>
            <!-- hiddens -->
            <input type="hidden" name="action" value="<?php echo $formAction ?>">
            <input type="hidden" id="hdnContractId" name="hdnContractId" value="<?php echo $hdnContractId; ?>">

            <input value="<?php echo ucfirst($formAction); ?> Contract" class="btn" type="button" id="addContract" name="addContract"  onclick="return addContractValidation();">
        </div>

    </form>
    <!-- form end -->
    
</section>
<!-- 
	=============== 
	Page Content Ends
	===============
-->
 <script src="inc/js/image_upload.js"></script>

<!-- 
	=============== 
	Footer Start
	===============
-->
<?php require_once ('inc/php/footer.php'); ?>
</body>
</html>