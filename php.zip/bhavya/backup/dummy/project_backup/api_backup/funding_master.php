<?php
/*
    This API is used to add , edit funding.
    Created by Bhavya
    Function included in this file :
    1) addFunding() - To add funds
    2) fundingListing() - To display funds
	3) getFundingData() - To get funding data for edit from district id
*/
error_reporting(0);
require_once '../inc/php/config.php';
require_once '../inc/dal/baseclasses/class.database.php';
require_once '../inc/dal/funding_master.child.php';
require_once '../inc/php/functions.php';

$requestedData = $_REQUEST; 
//print_r($requestedData);
$action = $requestedData['action']; 
// echo "Requested data :: <pre>";print_r($requestedData);exit;
// echo "Action :: $action";exit;
switch($action)
{   
    case "add":  
        $name = trim($requestedData['fundingname']);
       
        if(isset($name) && !empty($name))
        {
                $discription = $requestedData['fundingdiscription'];    
                $amount = $requestedData['fundingamount'];
                $startDate = $requestedData['startDate'];
                $endDate = $requestedData['endDate'];
                $remarks = $requestedData['fundingremarks'];
            	$isActive = 1;
        		$isdelete = 0;
        
            $response = addFunding($name, $discription, $amount, $startDate, $endDate, $isActive, $remarks, $isDelete);
            if($response[0] == 200)
            {
                $_SESSION['successMessage'] = "You have successfully added Funds";
                $code = $response[0]; // Success code
                $status = getStatusCodeMessage($code); // to get the status message
            }
            else
            {
                $code = $response[0]; // Error code
                $status = getStatusCodeMessage($code); // to get the status message
            }
        } // if ends here of checking for mandatory paramter
        else
        {
            $code = 701; // mandatory params missing status
            $status = getStatusCodeMessage($code); // to get the status message
        } // else ends here of checking for mandatory paramter
    break; 
     
	 case "funding_listing":  
        if(isset($_REQUEST['start']) && isset($_REQUEST['length']))
        {  
            $length = $_REQUEST['length']; 
			$start = $_REQUEST['start']; 
			/*
            $columnIndex = $_REQUEST['order'][0]['column']; // Column index
            $columnName = $_REQUEST['columns'][$columnIndex]['data']; // Column name
            $columnSortOrder = $_REQUEST['order'][0]['dir']; // asc or desc
            $orderOnBy = getOrderOnAndOrderBy($columnIndex, $columnName, $columnSortOrder);
            $splitOrderOnBy = explode('AND', $orderOnBy);
			//print_r($splitOrderOnBy);
			//exit;
            $orderOn = $splitOrderOnBy[0];
            $orderBy = $splitOrderOnBy[1];
			*/
			$orderOn = "id";
            $orderBy = "DESC";
            $conditionArray = array();
            $defaultCondition = "is_deleted = ?";
            $paramArray = array(0);
            array_push($conditionArray, $defaultCondition); 
            // $conditionAndParamArray = getSearchCondition($conditionArray, $requestedData);
            // $conditionArray = $conditionAndParamArray['condition'];
            // $paramArray = $conditionAndParamArray['paramArray'];
            $condition = implode(" AND ",$conditionArray);
            $response = fundingListing($condition, $orderOn, $orderBy, $start, $length, $requestedData, $paramArray);
            echo json_encode($response); 
            exit;
			
        }
        else
        {
            $code = 701; // mandatory params missing status
            $status = getStatusCodeMessage($code); // to get the status message
        } // else ends here of checking for mandatory paramter
    break; 	
	
	 case "get_funding_data":
        $fundingId = $_REQUEST['funding_id'];
        if(isset($fundingId) && !empty($fundingId))
        {
            $response = getFundingData($fundingId);
            if($response[0] == 200)
            {
                $data_flag = true;
                $data  = array($response[1]);
                $code = 200; // OK status code
                $status = getStatusCodeMessage($code); // to get the status message 
            }
            else 
            {
                $code = $response[0]; // Error code
                $status = getStatusCodeMessage($code); // to get the status message
            }
        } // if ends here of checking for mandatory paramter
        else
        {
            $code = 701; // mandatory params missing status
            $status = getStatusCodeMessage($code); // to get the status message
        } // else ends here of checking for mandatory paramter
    break; 	
		
 case "edit": 
        $fundingId = $requestedData['hdnFundingId'];
 
        $name = trim($requestedData['fundingname']);
        if(isset($fundingId) && !empty($fundingId) && isset($name) && !empty($name))
        {
            $discription = $requestedData['fundingdescription'];
            $amount = $requestedData['fundingamount'];
            $startDate = $requestedData['startDate'];
            $endDate = $requestedData['endDate'];
            $remarks = $requestedData['fundingremarks'];
           
            $response = editFunding($fundingId ,$name ,$discription ,$amount, $startDate ,$endDate ,$remarks);
            if($response[0] == 200)
            {
                $_SESSION['successMessage'] = "You have successfully updated funding details";
                $code = $response[0]; // Success code
                $status = getStatusCodeMessage($code); // to get the status message
            }
            else
            {
                $code = $response[0]; // Error code
                $status = getStatusCodeMessage($code); // to get the status message
            }
        } // if ends here of checking for mandatory paramter
        else
        {
            $code = 701; // mandatory params missing status
            $status = getStatusCodeMessage($code); // to get the status message
        } // else ends here of checking for mandatory paramter
    break; 
		
    default:
        $code = 708; // unknown request
        $status = getStatusCodeMessage($code); // to get the status message
    break;       
      
} // switch case ends here 

$response_arr['header']['status'] = $code;
$response_arr['header']['message'] = $status; // Show status message
if($data_flag == 'true') // if this flag is set to true that means it contains the data
    $response_arr['data'] = str_replace("\r\n","",$data); // set Data, If exist
// print response in json format
$json_data = generateJSON($response_arr); // json encode
echo $json_data; // to throw response

// Function to add funding
function addFunding($name,$discription,$amount,$startDate,$endDate,$isActive,$remarks,$isDelete)
{ 
	// set default value 
    if(empty($discription))
        $discription = NULL;
    if(empty($remarks))
        $remarks = NULL;
    if(empty($amount))
	{
        $amount = 0;
	}       
    if(empty($startDate))
    {
        $startDate = NULL;
    }
    if(empty($endDate))
    {
        $endDate = NULL;
    }
    $isActive = 1;
    $isDelete = 0;    
    $currentDateTime = date('Y-m-d H:i:s');
	$objFundingMaster = new fundingMasterChild();
	$objFundingMaster->name = $name;
	$objFundingMaster->discription = $discription;
	$objFundingMaster->amount = $amount;
	$objFundingMaster->start_date = $startDate;
	$objFundingMaster->end_date = $endDate;
	$objFundingMaster->is_active = $isActive;
	$objFundingMaster->remarks = $remarks;
	$objFundingMaster->is_delete = $isDelete;
	$objFundingMaster->created = $currentDateTime;
	$objFundingMaster->modified = $currentDateTime;
	$objFundingMaster->insert();
	$lastInsertedId = $objFundingMaster->id;
	// echo "Error : ".$objFundingMaster->error;
	// echo "lastInsertedId : $lastInsertedId";exit;
	if ($lastInsertedId > 0 && empty($objFundingMaster->error))
	{
		$response = array(200); // Success		
	}
	else 
	{
		$response = array(720); // There is something wrong to add data.
	}
	unset($objFundingMaster);
    return $response;
    // add funding end here
}
    
   // Function to get district listing
function fundingListing($condition, $orderOn, $orderBy, $start, $length, $requestedData, $paramArray)
{ 
    // echo "condition :: $condition";
    // echo '<pre>';print_r($paramArray);//exit;
    $recordsFiltered = 0;
    $recordsTotal = 0;
    $dataArray = array();
    $objFundingMaster = new fundingMasterChild();
    $objFundingMaster->selectColumn = "id";
    $objFundingMaster->param = $paramArray;
    $objFundingMaster->condition = $condition;
    $rsFundingData = $objFundingMaster->selectByColumn();
    $recordsTotal = $objFundingMaster->numRows;
    //echo "records total $recordsTotal";exit;
    if($recordsTotal > 0 && empty($objFundingMaster->error))
    {
        unset($objFundingMaster);
        $recordsFiltered = $recordsTotal;
        // To get all record from filter
        if ($length == -1)
        {
            $length = $recordsTotal;
        }
        // To get limitwise records
        $objFundingMasterChild = new fundingMasterChild();
        $objFundingMasterChild->selectColumn = "id, name, discription, amount, start_date, end_date, is_active, remarks, is_deleted";
        $objFundingMasterChild->param = $paramArray;
        $objFundingMasterChild->condition = "".$condition." ORDER BY $orderOn $orderBy LIMIT ".$start.",".$length;
        $rsFundingMasterData = $objFundingMasterChild->selectByColumn(); 
        $numRows = $objFundingMasterChild->numRows; 
		// echo "188 >> Numrows: $numRows";
        if($numRows > 0 && empty($objFundingMasterChild->error))
        {  
            unset($objFundingMasterChild);
            $cnt = 0;	
            $count = $start + 1;
            // echo "<pre>";print_r($rsFundingMasterData);exit;
            foreach($rsFundingMasterData AS $data)
            {
                $id = $data['id']; 
                $name = $data['name']; 
                $discription = $data['discription'];
				$amount = $data['amount'];
				$startDate = $data['start_date'];
				$endDate = $data['end_date'];
				$isActive = $data['is_active'];
				$remarks = $data['remarks'];
				$isDelete = $data['is_deleted'];
				
                //$key is from config file
                global $key;
                $idMd = md5($key.$id);
                $dataArray[$cnt]['DT_RowId'] = "row_".$id;
                $dataArray[$cnt]['id'] = $id;
                $dataArray[$cnt]['count'] = $count;
                $dataArray[$cnt]['funding_name'] = ucfirst($name);
                $dataArray[$cnt]['funding_description'] = ucfirst($discription);
                $dataArray[$cnt]['funding_amount'] = $amount;
				$dataArray[$cnt]['start_date'] = $startDate;
                $dataArray[$cnt]['end_date'] = $endDate;
                $dataArray[$cnt]['is_active'] = $isActive;
				$dataArray[$cnt]['funding_remarks'] = ucfirst($remarks);
                $dataArray[$cnt]['is_delete'] = $isDelete;
                $dataArray[$cnt]['idMd'] = $idMd;
                $cnt++;
                $count++;
            }	//foreach ends here
        }
        else
        {
            unset($objFundingMasterChild);
        }
    }
    else
    {
        unset($objFundingMaster);
    }
    // Refference : https://datatables.net/manual/server-side
    $responseArray = array();
    /* draw - strongly recommended for security reasons that you cast this parameter to an integer, rather than simply echoing back to the client what it sent in the draw parameter, in order to prevent Cross Site Scripting (XSS) attacks.*/
    $responseArray['draw'] = $_REQUEST['draw'];
    /*Total records, before filtering (i.e. the total number of records in the database)*/
    $responseArray['recordsTotal'] = $recordsTotal;
    /*Total records, after filtering (i.e. the total number of records after filtering has been applied - not just the number of records being returned for this page of data).*/
    $responseArray['recordsFiltered'] = $recordsFiltered;
    $responseArray['data'] = str_replace("\r\n","",$dataArray); // Set data, If exist
	//print_r($responseArray);
    return $responseArray;
} // districtListing() ends here

// Function to get funding data from funding id
function getFundingData($id)
{ 
    $fundingId = getFundingId($id);
    if($fundingId != 0)
    {
        $paramArray = array($fundingId);
        $objFundingMasterChild = new fundingMasterChild();
        $objFundingMasterChild->selectColumn = "id, name, discription, amount, start_date, end_date, remarks";
        $objFundingMasterChild->param = $paramArray;
        $objFundingMasterChild->condition = "id = ?";
      	$rsFundingMaster = $objFundingMasterChild->selectByColumn();
        $numRowsFundingMaster = $objFundingMasterChild->numRows;
        $dataArray = array();
        if($numRowsFundingMaster > 0 && empty($objFundingMasterChild->error))
        {
            $dataArray['fundingName'] = $rsFundingMaster[0]['name'];
            $dataArray['fundingDescription'] = $rsFundingMaster[0]['discription'];
            $dataArray['fundingAmount'] = $rsFundingMaster[0]['amount'];
            $dataArray['startDate'] = $rsFundingMaster[0]['start_date'];
            $dataArray['endDate'] = $rsFundingMaster[0]['end_date'];
            $dataArray['remarks'] = $rsFundingMaster[0]['remarks'];
           
            $response = array(200, $dataArray); // Success
        }
        else
        {
            $response = array(704); // No records present
        }
        unset($objFundingMasterChild);
    }
    else
    {
        $response = array(704); // No records present
    }
    return $response;
} // getFundingData() ends here
// Function to get funding id from md5 funding id

function getFundingId($id)
{
    global $key;
    $objFunding = new fundingMasterChild();
    $objFunding->query = "SELECT id FROM (SELECT id, md5( CONCAT('$key', id) ) AS fundingid FROM funding_master) AS tempfunding WHERE fundingid = '$id'";
    $rsFundingMaster = $objFunding->customSelectData();
    $numRows = $objFunding->numRows;
    //echo "num rows :: $numRows";
    // echo "Error :: ";print_r($objFunding->error); 
    if($numRows > 0 && empty($objFunding->error))
    {
        $fundingId = $rsFundingMaster[0]['id'];
    }
    else
    {
        $fundingId = 0;
    }
    return $fundingId;
} // getFundingId() ends here


// function to edit funding records
function editFunding($editId ,$name ,$discription , $amount ,$startDate ,$endDate , $remarks)
{
	// set default value
    if(empty($discription))
        $discription = NULL;
    if(empty($amount))
        $amount = 0;
    if(empty($startDate))
        $startDate = NULL;
     if(empty($endDate))
        $endDate = NULL;
	if(empty($remarks))
        $remarks = NULL;
 
    $currentDateTime = date('Y-m-d H:i:s');
    $fundingId = getFundingId($editId);
    if($fundingId != 0)
    {
        $objFundingMasterChild = new fundingMasterChild();
        $objFundingMasterChild->name = $name;
        $objFundingMasterChild->discription = $discription;
        $objFundingMasterChild->amount = $amount;
        $objFundingMasterChild->start_date = $startDate;
        $objFundingMasterChild->end_date = $endDate;
        $objFundingMasterChild->remarks = $remarks;
        $objFundingMasterChild->modified = $currentDateTime;
        $objFundingMasterChild->condition = "id = $fundingId";
        $objFundingMasterChild->update();
        //echo "error >> ".$fundingMasterChild->error;exit;
        if(empty($objFundingMasterChild->error))
        {
            $response = array(200); // Success
        }
        else 
        {
            $response = array(304); // Record could not be updated
        }
        unset($objFundingMasterChild);
    }
    else
    {
        $response = array(304); // Record could not be updated
    }
    return $response;
} // editFunding() ends here

?>