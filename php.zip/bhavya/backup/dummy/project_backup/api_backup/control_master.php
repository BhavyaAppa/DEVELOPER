<?php
/*
    This API is used to get the controls from the control_master table
    Created by priyanka
*/
require_once("../inc/php/config.php");
require_once("../inc/dal/baseclasses/class.database.php");
require_once("../inc/php/functions.php");
require_once("../inc/dal/controls_master.child.php");
$requestedData = $_REQUEST;
$action = $_REQUEST['action'];
//echo "Requested data :: <pre>";print_r($requestedData);
//echo "Action :: $action";exit; 
switch($action)
{   
    case "get_control_type_list": // Getting all the types from the table
        $response = getControlTypeList();
        if($response[0] == 200)
        {
            $data_flag = true;
            $data = $response[1];
        }
        $code = $response[0]; // Success code
        $status = getStatusCodeMessage($code); // to get the status message
    break; 
    case "get_control_type_data": // Getting data from the controls_master for the selected control
        $controlMasterId = $requestedData['control_master_id'];
        if(isset($controlMasterId) && !empty($controlMasterId))
        {
            $response = getControlTypeData($controlMasterId);
            if($response[0] == 200)
            {
                $data_flag = true;
                $data = $response[1];
            }
            $code = $response[0]; // Code
            $status = getStatusCodeMessage($code); // to get the status message
        }
        else
        {
            $code = 701; // Mandatory parameters are missing
            $status = getStatusCodeMessage($code); // to get the status message
        }
    break; 
    default:
        $code = 708; // unknown request
        $status = getStatusCodeMessage($code); // to get the status message
    break;       
      
} // switch case ends here 
$response_arr['header']['status'] = $code;
$response_arr['header']['message'] = $status; // Show status message
if($data_flag == 'true') // if this flag is set to true that means it contains the data
    $response_arr['data'] = str_replace("\r\n","",$data); // set Data, If exist
// print response in json format
$json_data = generateJSON($response_arr); // json encode
echo $json_data; // to throw response
// Function to get the control list
function getControlTypeList()
{
    $paramArray = array(0);
    $objControlsMaster = new controlsMasterChild();
    $objControlsMaster->selectColumn = "id, control_type";
    $objControlsMaster->param = $paramArray;
    $objControlsMaster->condition = "is_deleted = ?";
    $rsControlsMaster = $objControlsMaster->selectByColumn();
    $numRow = $objControlsMaster->numRows;
    if($numRow > 0 && empty($objControlsMaster->error))
    {
        unset($objControlsMaster);
        $result = array(200, $rsControlsMaster); // Success
    }
    else
    {
        unset($objControlsMaster);
        $result = array(704); // No record present
    }
    return $result;
} // getControlTypeList() ends here
/* Function to get the record from the controls_master table for the selected control type */
function getControlTypeData($controlMasterId)
{
    $paramArray = array(0, $controlMasterId);
    $objControlsMaster = new controlsMasterChild();
    $objControlsMaster->selectColumn = "id, control_type, control_form_parameters, control_json_structure";
    $objControlsMaster->param = $paramArray;
    $objControlsMaster->condition = "is_deleted = ? AND id = ?";
    $rsControlsMaster = $objControlsMaster->selectByColumn();
    $numRow = $objControlsMaster->numRows;
    if($numRow > 0 && empty($objControlsMaster->error))
    {
        unset($objControlsMaster);
        $result = array(200, $rsControlsMaster[0]); // Success
    }
    else
    {
        unset($objControlsMaster);
        $result = array(704); // No record present
    }
    return $result;
} // getControlTypeData() ends here
?>