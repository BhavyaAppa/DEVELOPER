<!doctype html>
<html class="no-js">
<head>
	<title>Add Assets</title>  
	<?php require_once ('inc/php/head.php'); ?>
	<!-- jQuery UI css & js -->	
	<link rel="stylesheet" href="inc/css/jquery-ui.css">
	<script src="inc/js/jquery-ui.js"></script>
	<!-- tagify css & js -->	
	<link rel="stylesheet" href="inc/css/tagify.css">	
	<script type="text/javascript" src="inc/js/tagify.js"></script>
	<script type="text/javascript">
		var tagsValueArray = [];
		$(document).ready(function()
		{
			getControlTypeList()
			$("#purchasedDate").datepicker({
				dateFormat: 'mm-dd-yy'
			});
			// Reference url for options : https://www.jqueryscript.net/demo/Tiny-Text-Field-Based-Tags-Input-Plugin-For-jQuery-Tagify/
			// Examples of tagify : 
			// 1) https://codepen.io/vsync/pen/abNOmWz
			// 2) https://maelsov.id/jasabox/assets/js/custom_template_js/jquery-tagify/
			var optionsField = document.querySelector('input[id=fieldOptionsValue]');
			// initialize Tagify on the above input node reference
			var tagifyOptions = new Tagify(optionsField,
			{
				editTags: false
			})
			// tagifyOptions.editTags(null)
			/* when adding options in the options value field add that option in default value dropdown also to select default value from the added option */
			/* Add tag */
			tagifyOptions.on('add', function(e)
			{
				var value = e.detail.data.value
				tagsValueArray.push(value)
				// console.log(tagsValueArray)
				var selectOption = '<option value='+value+'>'+value+'</option>'
				$("#fieldDefaultvalueSelect").append(selectOption)
			})
			tagifyOptions.on('edit', function(e)
			{
				var value = e.detail.data.value
				// tagsValueArray.push(value)
				console.log(e)
				// var selectOption = '<option value='+value+'>'+value+'</option>'
				// $("#fieldDefaultvalueSelect").append(selectOption)
			})
			/* when removing options in the options value field remove that option from the default value dropdown. */
			/* Remove tag */
			tagifyOptions.on('remove', function(e)
			{
				var value = e.detail.data.value
				tagsValueArray.splice(tagsValueArray.indexOf(value), 1);
				// console.log(tagsValueArray)
				$("#fieldDefaultvalueSelect option[value="+value+"]").remove();
			})
		})
		function openModal()
		{			
			// var pageScroll = $(document).scrollTop();
			// $('#addAssetsModel .modelWrapper').css({ top: pageScroll + 'px'});
			$("html, body").animate({ scrollTop: 0 }, 600);
			$("#addAssetsOverlay").show();
			$("#addAssetsModel").show();
		}
		function closeModal()
		{	
			$("#addAssetsOverlay").hide();
			$("#addAssetsModel").hide();
		}
		// getControlTypeList() starts here
		function getControlTypeList()
		{
			$.ajax({
				url : 'api/control_master.php',
				type: 'POST',
				data: {
					"action" : 'get_control_type_list'
				},
				timeout: 30000,
				async: true,
				cache: false,
				dataType: 'json',
				beforeSend: function()
				{},
				success : function(response)
				{
					// console.log(response);
					var status = response.header.status;
					var message = response.header.message;
					if(status == 200)
					{
						var data = response.data;
						for(let i = 0; i < data.length; i++)
						{
							var id = data[i]['id'];
							var type = data[i]['control_type'];
							$("#hdnFieldType").val(type.toLowerCase())
							var isSelected = "";
							if(type.toLowerCase() == "radio_button")
							{
								getControlTypeData(id)
								isSelected = "selected";
							}
							else
							{
								isSelected = "";
							}
							// alert(isSelected);
							var controlType = type.charAt(0).toUpperCase()+type.slice(1).replaceAll("_", " ");
							var option = "<option value="+id+" "+isSelected+" data-value="+type+">"+controlType+"</option>";
							$("#fieldType").append(option);
						}
					}
				},
				error: function(XHRHttpResponse, errorStatus, errorThrown)
				{
					alert("There is something wrong, Please try after sometime!")
				},
				complete : function()
				{}
			})
		} // getControlTypeList ends here
		// getControlTypeData() starts here
		function getControlTypeData(id)
		{
			// alert("id : "+id);
			$(".errorSpan").text("");
			$(".errorSpan").hide;
			$.ajax({
				url : 'api/control_master.php',
				type: 'POST',
				data: {
					"action" : 'get_control_type_data',
					"control_master_id" : id
				},
				timeout: 30000,
				async: true,
				cache: false,
				dataType: 'json',
				beforeSend: function()
				{},
				success : function(response)
				{
					// console.log(response);
					var status = response.header.status;
					var message = response.header.message;
					if(status == 200)
					{
						var data = response.data;
						// console.log("data : "+JSON.stringify(data))
						var controlFormParam = JSON.parse(data['control_form_parameters'])
						// console.log("form param : "+controlFormParam);
						var controlJsonStructure = data['control_json_structure']
						// console.log("json structure : "+controlJsonStructure);
						$("#hdnControlJsonStructure").val(controlJsonStructure)
						var requiredParamArray = [];
						showHideCustomFieldLi(controlFormParam, requiredParamArray);
					}
				},
				error: function(XHRHttpResponse, errorStatus, errorThrown)
				{
					alert("There is something wrong, Please try after sometime!")
				},
				complete : function()
				{}
			})
		} // getControlTypeData ends here
		// showHideCustomFieldLi() starts here
		function showHideCustomFieldLi(controlFormParam, requiredParamArray)
		{
			var isOptionsFlagTrue = false;
			$.each(controlFormParam, function(index, value)
			{
				var controlParam = index.charAt(0).toUpperCase()+index.slice(1).replaceAll("_", "");
				var controlLiId = "field"+controlParam+"Li"; // Note : Please not that id of the each li must be defined as controlLiId variable. "controlParam" contains default_value, caption, reuired, etc,... (controlParam is the key each node of control_form_parameters json from the controls_master table)
				if(value == "yes")
				{
					$("#"+controlLiId).show();
					if(index == "options")
					{
						isOptionsFlagTrue = true;
					}
					requiredParamArray.push(index)
				}
				else
				{
					$("#"+controlLiId).hide();
				}
				// console.log("index : "+index+" :: value : "+value)
			})
			if(isOptionsFlagTrue == true)
			{
				// alert("Inside if");
				$("#fieldDefaultvalue").hide();
				$("#fieldDefaultvalueSelect").show();
			}
			else
			{
				$("#fieldDefaultvalueSelect").hide();
				$("#fieldDefaultvalue").show();
			}
			$("#hdnRequiredParamArray").val(requiredParamArray);
		} // showHideCustomFieldLi ends here
		// function to validate form starts here
		function validateCustomFieldForm()
		{
			var isOptionsExists = false
			var requiredParamArray = $("#hdnRequiredParamArray").val().split(',');
			// alert(requiredParamArray)
			if(requiredParamArray.indexOf('options') == true)
			{
				isOptionsExists = true
			}
			var isValidForm = true;
			var hdnControlJsonStructure = JSON.parse($("#hdnControlJsonStructure").val());
			// console.log("hdnControlJsonStructure : "+hdnControlJsonStructure["caption"])
			$.each(requiredParamArray, function(index, value)
			{
				var optionsLength = 0;
				var controlParam = value.charAt(0).toUpperCase()+value.slice(1).replaceAll("_", "");
				var controlId = "field"+controlParam
				// console.log("value :" +controlId)
				if(value != "default_value")
				{
					if(value != "required")
					{
						if(value == "options" && isOptionsExists == true)
						{
							optionsLength = $('#fieldDefaultvalueSelect option').length
							var controlValue = tagsValueArray;
						}
						else
						{
							var controlValue = $("#"+controlId).val()
						}
					}
					else
					{
						var controlValue = $("input[name="+controlId+"]:checked").val()
					}
					// alert("control id : "+controlId+" :: control value : "+controlValue)
					if(((controlValue == undefined || controlValue == null || controlValue == "") && value != 'options') || optionsLength == 1)
					{
						$("#"+controlId+"Error").text("This field is required!")
						$("#"+controlId+"Error").show();
						isValidForm = false
					}
					else
					{
						if(value == "required")
						{
							hdnControlJsonStructure['validation']['is_required'] = controlValue;
						}
						else if(value == "options")
						{
							// console.log(tagsValueArray.toString())
							hdnControlJsonStructure['configuration']['options'] = tagsValueArray.toString();
						}
						else if(value == "placeholder")
						{
							hdnControlJsonStructure['configuration']['placeholder'] = controlValue;
						}
						else
						{
							// alert("inside else :"+value)
							hdnControlJsonStructure[value] = controlValue;
						}
					}
				}
				else
				{
					if(isOptionsExists == true)
						var defaultValue = $('#fieldDefaultvalueSelect').val()
					else
						var defaultValue = $('#fieldDefaultvalue').val()
					hdnControlJsonStructure['configuration']['default_value'] = defaultValue;
				}
			})
			var type = $("#fieldType option:selected").attr('data-value');
			var controlMasterId = $("#fieldType option:selected").attr('value');
			// console.log("control json : "+JSON.stringify(hdnControlJsonStructure))
			// return false
			hdnControlJsonStructure['type'] = type;
			// console.log("control json : "+JSON.stringify(hdnControlJsonStructure))
			if(isValidForm == true)
			{
				addCustomFieldData(hdnControlJsonStructure, controlMasterId)
			}
			else
			{
				alert("There is something wrong, Please try after sometime!");
				return false;
			}
		} // validateCustomFieldForm ends here
		// addCustomFieldData() starts here
		function addCustomFieldData(controlJsonStructure, controlMasterId)
		{
			var formId = 1;
			$.ajax({
				url: 'api/custom_fields.php',
				type : 'POST',
				dataType : 'json',
				timeout : 3000,
				async: true,
				data: {
					'action': 'add',
					'formId': formId,
					'controlMasterId': controlMasterId,
					'controlJsonStructure': controlJsonStructure
				},
                cache: false,
                beforeSend : function()
                {
                    $("#customFieldLoader").show(); // show loader
                },
                success: function(response)
                {
                    var status = response.header.status; // get status code
                    var message = response.header.message; // get message
                    // console.log("status ::"+status);
                    // console.log("message ::"+message);                    
                    if(status == 200)
                    {
						$("#customFieldForm").trigger("reset"); // Reset form
						closeModal(); // Close Model
						$("#successMessageLabel").text('Custom field added sucessfully.');
						$("#successMessageDiv").show();
						$("#successMessageDiv").fadeIn().delay(7000).fadeOut();
                    } 
                    else
                    {
                        $("#errorMessageLabel").text(message);
						$("#errorMessageDiv").show();
						$("#errorMessageDiv").fadeIn().delay(7000).fadeOut();
                    }
                },
                error: function(XMLHttpRequest, errorStatus, errorThrown) 
                {
                    console.log("XHR :: "+JSON.stringify(XMLHttpRequest));
                    console.log("Status :: "+errorStatus);
                    console.log("error :: "+errorThrown);
                    var errorStatus = XMLHttpRequest['status'];
                    if(errorThrown == 'timeout')
                    {
                        alert('Request has been timeout. Please check your internet connection! (Error: '+errorStatus+')');
                        return false;
                    }
                    else
                    {
                        alert('There is something wrong! Please try again! (Error: '+errorStatus+')');
                        return false;
                    }
                },
                complete:function()
                {
                    $("#customFieldLoader").hide(); // hide loader
                }
			})
		} // addCustomFieldData ends here
		// hideError starts here
		function hideError(id)
		{
			$("#"+id).text("");
			$("#"+id).hide();
		} // hideError ends here
		// validateAddAssetsForm() starts here
		function validateAddAssetsForm()
		{
			var isValidForm = true;
			var assetsTitleValue = $("#assetsTitle").val();
			var assetsCategoryValue = $("#assetsCategory").val();
			var purchasedDateValue = $("#purchasedDate").val();
			var purchasedAmountValue = $("#purchasedAmount").val();
			if(assetsTitleValue == undefined || assetsTitleValue == "" || assetsTitleValue == null)
			{
				$("#assetsTitleError").show()
				$("#assetsTitleError").text("This field is required")
				isValidForm = false
			}
			if(assetsCategoryValue == undefined || assetsCategoryValue == "" || assetsCategoryValue == null)
			{
				$("#assetsCategoryError").show()
				$("#assetsCategoryError").text("This field is required")
				isValidForm = false
			}
			if(purchasedDateValue == undefined || purchasedDateValue == "" || purchasedDateValue == null)
			{
				$("#purchasedDateError").show()
				$("#purchasedDateError").text("This field is required")
				isValidForm = false
			}
			if(purchasedAmountValue == undefined || purchasedAmountValue == "" || purchasedAmountValue == null)
			{
				$("#purchasedAmountError").show()
				$("#purchasedAmountError").text("This field is required")
				isValidForm = false
			}
			if(isValidForm == true)
			{
				submitAssetsForm() // form is valid submit data using ajax
			}
			else
			{
				return false;
			}
		} // validateAddAssetsForm ends here
		// submitAssetsForm() starts here
		function submitAssetsForm()
		{
			alert("Form is valid");
		} // submitAssetsForm ends here
	</script>
</head>
<body class="noMenu">
<!-- 
	=============== 
	Model Box :: 
	=============== 
-->
<!-- Reference to add options in field options column : https://www.jqueryscript.net/form/Tiny-Text-Field-Based-Tags-Input-Plugin-For-jQuery-Tagify.html -->
<div class="overlay" id="addAssetsOverlay" style="display:none;"></div>
<div class="model scroll addAssets" id="addAssetsModel" style="display:none;">
	<div class="modelWrapper">   
		<form method="POST" name="customFieldForm" id="customFieldForm">
			<div class="card addFormFields">
				<h2>Add New Fields</h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
				<ul class="form">
					<li id="fieldTypeLi">
						<div class="lbl">Field Type<span>*</span></div>
						<div class="val">
							<select name="fieldType" id="fieldType" class="input" style="width:80%;" onchange="getControlTypeData(this.value)"></select>
							<div class="validation">
								<span style="display:none;" class="errorSpan" id="fieldTypeError"></span>
							</div>
						</div>
					</li>
					<li id="fieldCaptionLi" class="customFieldLi">
						<div class="lbl">Field Caption<span>*</span></div>
						<div class="val">
							<input type="text" autocomplete="off" name="fieldCaption" id="fieldCaption" class="input" placeholder="Enter field caption" style="width:80%;" onkeyup="hideError('fieldCaptionError')"> 
							<div class="validation">
								<span style="display:none;" class="errorSpan" id="fieldCaptionError"></span>
							</div>
						</div>
					</li>	
					<li id="fieldPlaceholderLi" class="customFieldLi">
						<div class="lbl">Field Placeholder<span>*</span></div>
						<div class="val">
							<input type="text" autocomplete="off" name="fieldPlaceholder" id="fieldPlaceholder" class="input" placeholder="Enter field placeholder" style="width:80%;" onkeyup="hideError('fieldPlaceholderError')"> 
							<div class="validation">
								<span style="display:none;" class="errorSpan" id="fieldPlaceholderError"></span>
							</div>
						</div>
					</li>	
					<li id="fieldRequiredLi" class="customFieldLi">
						<div class="lbl">Required Field<span>*</span></div>
						<div class="val">
							<div class="horizontalField">
								<label class="radioBtn">
									<input type="radio" name="fieldRequired" value="true" onchange="hideError('fieldRequiredError')"><span class="checkmark" ></span>Yes
								</label>							
								<label class="radioBtn">
									<input type="radio" name="fieldRequired" value="false" onchange="hideError('fieldRequiredError')"><span class="checkmark"></span>No
								</label>
							</div>
							<div class="validation">
								<span style="display:none;" class="errorSpan" id="fieldRequiredError"></span>
							</div>
						</div>
					</li>
					<li id="fieldOptionsLi" class="customFieldLi">
						<div class="lbl">Field Option values<span>*</span></div>
						<div class="val">
							<input type="text" placeholder="Enter field option value" id="fieldOptionsValue" value="" style="width:80%;" class="input" onchange="hideError('fieldOptionsError')">
							<input type="hidden" name="fieldOptions" id="fieldOptions" />
							<div class="validation">
								<span style="display:none;" class="errorSpan" id="fieldOptionsError"></span>
							</div>
						</div>
					</li>				
					<li id="fieldDefaultvalueLi" class="customFieldLi">
						<div class="lbl">Field Default Value</div>
						<div class="val">
							<input type="text" autocomplete="off" name="fieldDefaultvalue" id="fieldDefaultvalue" class="input" placeholder="Enter field value" style="width:80%;" onkeyup="hideError('fieldDefaultvalueError')"> 
							<select name="fieldDefaultvalueSelect" id="fieldDefaultvalueSelect" class="input" style="width:80%;" onchange="hideError('fieldDefaultvalueError')">
								<option value="">Select default value</option>
							</select> 
							<div class="validation">
								<span style="display:none;" class="errorSpan" id="fieldDefaultvalueError"></span>
							</div>
						</div>
					</li>
					<input type="hidden" id="hdnFieldType"/>
				</ul>
				<!---Bottom Button ---->
				<div class="bottomButton">
					<div class="button border">
						<div class="btnLoader" style="display:none;">
							<span class="spinLoader small"></span>
						</div>	
						<input type="button" class="btn" value="Cancel" onclick="closeModal();">
					</div>	
					<div class="button blue">
						<div class="btnLoader" id="customFieldLoader" style="display:none;">
							<span class="spinLoader small"></span>
						</div>	
						<input type="button" class="btn" onclick="validateCustomFieldForm()" value="Add Field">
					</div>
				</div>
				<input type="hidden" name="hdnControlJsonStructure" id="hdnControlJsonStructure" />
				<input type="hidden" name="hdnRequiredParamArray" id="hdnRequiredParamArray" />
			</form>
		</div>
		<!-- Preview Field -->
		<div class="previewFiled">		
			<h3>Field Preview</h3>
			<ul class="card form">
				<li>
					<div class="lbl">{Field_label}<span>*</span></div>
					<div class="val">
						<input type="text" class="input" placeholder="TextBox" style="width:85%;"> 
						<a class="ico"></a>
						<div class="validation">
							<span style="display:none"></span>
						</div>
					</div>
					<!-- value Ends -->
				</li>
			</ul>
		</div>
	</div>
</div>
<!--
	============
	Header Start
	============
-->
<?php require_once ('inc/php/header.php'); ?>
<!--
	================
	Page Title Start
	================
-->
<section class="pageTitle">
	<h1>Add Assets</h1>	
	<a href="javascript:;" class="back">Back</a>
    <div class="clr"></div>
</section>
<!--
	==============
	Page Title End
	==============
-->
<!--
	==================
	Page Content Start
	==================
-->
<section  class="pageContent navigationForm addLeftTab referenceGuide">
	<div class="navigation">
		<div class="tabs timeline">
			<!--Left Tab Steps Details Tabs ul -->
			<ul>
				<li><a class="active" href="#getCollectionData">Basic Detail</a></li>		
				<!--Section Tabs ul -->
				<li><a href="#postCollectionData">Custom Field</a></li>
				<li><a href="#postBulkCollectionData">Depriciation</a></li>
				<li><a href="#postBulkCollectionData">Attachments</a></li>
			</ul>
		</div>
	</div>
	<!--
		==========
		Form Start
		==========
	-->
	<form method="POST" name="addAssetsForm" enctype="multipart/form-data">		
	<!--
		===================
		Alert :: Success
		===================
	-->	
	<div class="alert alert-success" style="display:none;" id="successMessageDiv">
		<img src="images/success-tik.svg" />
		<strong>Success!</strong>
		<label id="successMessageLabel"></label>
	</div>
	<!--
		===================
		Alert :: Error
		===================
	-->	
	<div class="alert alert-error" style="display:none;" id="errorMessageDiv"> 			
		<img src="images/error_x.svg" />
		<strong>Error!</strong>
		<label id="errorMessageLabel"></label>
	</div>
		<!--
			====================
			Business Information
			====================
		-->
		<div class="card">
			<h2>Basic Detail</h2>
			<ul class="form">
				<li>
					<div class="lbl">Assets Title<span>*</span></div>
					<div class="val">
						<input type="text" autocomplete="off" name="assetsTitle" id="assetsTitle" class="input" placeholder="Enter Assets Title" style="width:50%;" onkeyup="hideError('assetsTitleError')"> 
						<div class="validation">
							<span style="display:none" id="assetsTitleError"></span>
						</div>
					</div>
					<!-- value Ends -->
				</li>					
				<li>
					<div class="lbl">Category<span>*</span></div>
					<div class="val">
						<input type="text" autocomplete="off" name="assetsCategory" id="assetsCategory" class="input tooltrip" placeholder="Enter Category" style="width:50%;" onkeyup="hideError('assetsCategoryError')">
						<div class="tooltip">
							<a href="" class="remove"></a>
							<a href="" class="move"></a>
							<span class="tooltiptext">Remove This Field</span>
						</div>
						<div class="validation">
							<span style="display:none" id="assetsCategoryError"></span>
						</div>
					</div>
					<!-- value Ends -->
				</li>
				<li>
					<div class="lbl">Purchased Date<span>*</span></div>
						<div class="dateSelections" style="width:50%;">
							<input type="text" autocomplete="off" name="purchasedDate" id="purchasedDate" class="input hasDatepicker" placeholder="Select Purchased Date" onkeyup="hideError('purchasedDateError')">
						<div class="validation">
							<span style="display:none" id="purchasedDateError"></span>
						</div>
					</div>
					<!-- value Ends -->
				</li>	
				<li>
					<div class="lbl">Purchased Amount<span>*</span></div>
					<div class="val">
						<input type="text" autocomplete="off" name="purchasedAmount" id="purchasedAmount" class="input" placeholder="Enter Purchased Amount " style="width:50%;" onkeyup="hideError('purchasedAmountError')"> 
						<div class="validation">
							<span style="display:none" id="purchasedAmountError"></span>
						</div>
					</div>
					<!-- value Ends -->
				</li>
			</ul>
		</div>
		<!--
			====================
			Custom Field
			====================
		-->
		<div class="card">
			<h2 style="color:#3E9ACD;">Custom Field</h2>
			<div>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
				Ut enim ad minim veniam</p>		
				<div href="javascript:;" onclick="openModal()" class="addField"><a>Add New Field</a></div>
			</div>
		</div>
		<!--
			=================
			Depriciation
			=================
		-->
		<div class="card">
			<h2 style="color:#D6993E;">Depriciation</h2>
				<div>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
					Ut enim ad minim veniam</p>
				</div>	
			</ul>
		</div>
		<!--
			========================
			Attachments
			========================
		-->
		<div class="card">
			<h2 style="color:#258054;">Attachments</h2>
				<div>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
					Ut enim ad minim veniam</p>
				</div>	
			</ul>
		</div>	
		<div class="submitBtn submit" style="display:inline-block; margin-left: calc(250px + 20px);">
			<div class="btnLoader" style="display:none;">
				<span class="spinLoader"></span>
			</div>
			<input value="Submit" name="assetsAddBtn" id="assetsAddBtn" class="btn" type="submit" onclick="return validateAddAssetsForm()">
		</div>
	</form>	
	<!--
		========
		Form End
		========
	-->  
</section>
<!--
	================
	Page Content End
	================
-->
<!-- 
	============
	Footer Start
	============
-->
<?php require_once ('inc/php/footer.php'); ?>
<script>
	$(".customFieldLi").hide();
</script>
</body>
</html>