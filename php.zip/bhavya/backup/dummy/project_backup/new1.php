<?php
echo "test";
$test = "new";

echo "$test";
?>