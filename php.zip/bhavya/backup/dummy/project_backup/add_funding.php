<!-- 
    Created by Bhavya 9 march 2022
 -->
 <?php
    require_once 'inc/php/config.php';
    require_once 'inc/dal/baseclasses/class.database.php';
    require_once 'inc/dal/settings.child.php';
    require_once 'inc/php/functions.php';
    require_once 'inc/dal/baseclasses/class.database.php';
    require_once 'inc/dal/funding_master.child.php';
    
    $codeUrl = getCodeUrl(); // call function and get code url
	$formAction = 'add'; // action = add

	 if((isset($_REQUEST['action']) && !empty($_REQUEST['action'])) && isset($_REQUEST['id']) && !empty($_REQUEST['id']))
    { 
        $formAction = $_REQUEST['action']; // action = edit
        $fundingId = $_REQUEST['id'];
        $hdnFundingId = $fundingId; // update $hdnFundingId
    } 
?>
<!doctype html>
<html class="no-js">
<head>
    <title><?php echo ucfirst($formAction); ?> Add Funding </title>
    <?php require_once ('inc/php/head.php'); ?>
	<script src="inc/js/jquery-ui.js"></script>
    <script type="text/javascript">
        var codeUrl = '<?php echo $codeUrl; ?>'; // code url
		var formAction = '<?php echo $formAction;?>'; // action = add, edit

		$(document).ready(function()
		{	  
			$('#fundingStartDate').datepicker({
				dateFormat: 'mm-dd-yy'
			});			
			$('#fundingEndDate').datepicker({
				dateFormat: 'mm-dd-yy'
			});
			
			// if action is edit 
      		if(formAction == 'edit') 
            { 
                var fundingId = '<?php echo $fundingId; ?>'; 
                getFundingDataThroughAjax(fundingId); 	// getFundingDataThroughAjax() call when action is edit  
            }
			 // hide error message
			 $("#fundingname").keypress(function(){
			   $("#errorFundingName").hide();
			   });
			  
			$(document).on('click','#addFunding',function(e) 
			{
				// Declaration
				var name= ($("#fundingname").val()).trim();
				var regex = new RegExp("^[a-zA-Z]*$");
				var isFormValidate = true; // set flag
				
				// validation
				if(name == '' || name == null || name == undefined) 
				{
					$("#errorFundingName").text("Please Enter Name");
					isFormValidate = false;
					return false;	
				}
				else if((regex.test(name) === false)) 
				{ 
					$("#errorFundingName").text("Please Enter Only Alphabets");
					isFormValidate = false;
					return false;
				}
				else
				{ 
					// alert("allRequestData >> "+JSON.stringify(allRequestData));
					submitDataThroughAjax();
				}
				
				function submitDataThroughAjax()
				{
					var formData = new FormData(); // create object
					var allRequestData = $('#addFundingForm').serializeArray();
							
					$.each(allRequestData,function(key,input)
					{
						// alert("name >> "+input.name+" value >> "+input.value);
						formData.append(input.name,input.value);
					});
					
					//alert("formData >> "+JSON.stringify(formData));

					var finalUrl = codeUrl+"api/funding_master.php"; // finalUrl
					
					$.ajax({
						type: "POST",
						url: finalUrl,
						data: formData,
						dataType: "json",
						contentType:false,
						cache: false,
						processData: false,
						timeout : 30000, 
						beforeSend : function()
						{ 
							$("#addFundingLoader").show(); // show loader
						},
						success: function(response)
						{ 
							var status = response.header.status; // get status code
							var message = response.header.message; // get message

							console.log("status ::"+status);
							console.log("message ::"+message);
							
							if(status == 200)
							{                   
								window.location.href="funding.php"; // redirect on page
							} 
							else
							{		
                                $('#errorMessageDiv').css("display","block");
                                $('#errorMessageLableId').html(message);
								setTimeout(function () { 
                                     $('#errorMessageDiv').css("display","none");
                                 }, 2500); // timeout for 2.5 second for message 
                               
							}
							return false;
						},
						error: function(XMLHttpRequest, errorStatus, errorThrown) 
						{
							console.log("XHR :: "+JSON.stringify(XMLHttpRequest));
							console.log("Status :: "+errorStatus);
							console.log("error :: "+errorThrown);
							var errorStatus = XMLHttpRequest['status'];
							if(errorThrown == 'timeout')
							{
								alert('Request has been timeout. Please check your internet connection! (Error: '+errorStatus+')');
								return false;
							}
							else
							{
								alert('There is something wrong! Please try again! (Error: '+errorStatus+')');
								return false;
							}
						},
						complete: function()
						{
							$("#addFundingLoader").hide(); // hide loader
						}
					});
						e.preventDefault();
					return false;		
				
				}
			});
			
			
        // function start here
        function getFundingDataThroughAjax(fundingId)
        {
            var finalUrl = codeUrl + "api/funding_master.php" ; // final url
            // ajax start
            $.ajax({
                    type: "POST",
                    url: finalUrl,
                    data : "action=get_funding_data&funding_id="+fundingId,
                    cache: true,
                    async: true,
                    timeout: 30000,
                    dataType : "json",
                    beforeSend: function() 
                    {
                        // $("#addFundingLoader").show(); // start loader
                    },
                    success: function(response) 
                    {
                        var status = response.header.status; // get status code
                        var message = response.header.message; // get message

                        console.log("status ::"+status);
                        console.log("message ::"+message);

                        if (status === 200 && message == 'OK') 
                        {
                            var data = response.data; // get data
                            console.log("data :: " + JSON.stringify(data));

                            if(data)
                            {	
                                var fundingName = data[0].fundingName; 
								var fundingDescription = data[0].fundingDescription;
								var fundingAmount = data[0].fundingAmount; 
								var startDate = data[0].startDate;
								var endDate = data[0].endDate;
								var remarks = data[0].remarks; 
							
                                $("#fundingname").val(fundingName);  
								$("#fundingdescription").text(fundingDescription);
								$("#fundingamount").val(fundingAmount);
								$("#startDate").val(startDate); 
								$("#endDate").val(endDate); 
								$("#fundingremarks").text(remarks); 	
                            }
                        }
                        else 
                        {
                            $("#errorMessageDiv").show();
                            $("#errorMessageLableId").text('');
                            $("#errorMessageLableId").text(message);	
                        }
                    },
                    error: function(XMLHttpRequest, errorStatus, errorThrown) 
                    {
                        console.log("XHR :: "+JSON.stringify(XMLHttpRequest));
                        console.log("Status :: "+errorStatus);
                        console.log("error :: "+errorThrown);
                        var errorStatus = XMLHttpRequest['status'];
                        if(errorThrown == 'timeout')
                        {
                            alert('Request has been timeout. Please check your internet connection! (Error: '+errorStatus+')');
                        }
                        else
                        {
                            alert('There is something wrong! Please try again! (Error: '+errorStatus+')');
                        }
                    },
                    complete: function() 
                    {
                        // $("#addCategoryLoader").hide(); // hide loader
                    }
            });
    // ajax end here
        }
		});
    </script>
</head>
<body class="noMenu">
<!--
	================
	Header Start
	================
-->
<?php require_once ('inc/php/header.php'); ?>
<!-- 
	=============== 
	Page Title Start
	=============== 
-->
<section class="pageTitle">
    <h1>Add Funding</h1>
    <a href="" class="back">Back</a>
    <div class="clr"></div>
</section>
<!-- 
	=============== 
	Page Title End
	=============== 
-->
<!-- 
	===============
	Page Content Start 
	===============
-->
<section class="pageContent widget">

    <!--
		===================
		Alert :: Success
		===================
	-->
    <div class="alert alert-success" style="display: none;" id="successMessageDiv">
        <img src="images/success-tik.svg" />
        <strong>Success!</strong>
        <lable id="successMessageLableId"></lable>
    </div>

	<!--
		===================
		Alert :: Error
		===================
	-->
    <div class="alert alert-error" style="display: none;" id="errorMessageDiv">
        <img src="images/error_x.svg" />
        <strong>Error!</strong>
        <lable id="errorMessageLableId"></lable>
    </div>	
	<!-- form stat -->	
    <form id="addFundingForm" name="addFundingForm" method="post">
        <div class="card">
            <ul class="form">
                <li>
                    <div class="lbl">Name<span>*</span></div>
                    <div class="val">
                        <input autocomplete="off" type="text" class="input" placeholder="Please Enter Name" id="fundingname" name="fundingname" value=""/>
                        <div class="validation">
                            <span id="errorFundingName"></span>
                        </div>
                    </div>
		</li>
		
		<li>
		 <div class="lbl">Description</div>
                    <div class="val">
                        <textarea name="fundingdescription" id="fundingdescription" rows="4" cols="30" placeholder="Enter description Here..."></textarea>
                    </div>
                </li>
		
			<li>
				<div class="lbl">Amount</div>
				<div class="val">
					<input autocomplete="off" type="number" class="input" placeholder="Please Enter Amount" id="fundingamount" name="fundingamount" step="any" />
				</div>
			</li>                
			<li> 
				<div class="lbl">Remarks</div>
				<div class="val">
					<textarea name="fundingremarks" id="fundingremarks" rows="4" cols="30" placeholder="Enter Remarks Here..."></textarea>
				</div>
			</li>
			<li>
				<div class="lbl">Start Date</div>
				<div class="val">
					<input autocomplete="off" type="text" class="input" placeholder="Enter Start Date" id="fundingStartDate" name="fundingStartDate" value='' />
				</div>
            </li>            
            <li>
				<div class="lbl">End Date</div>
				<div class="val">
					<input autocomplete="off" type="text" class="input" placeholder="Enter End Date" id="fundingEndDate" name="fundingEndDate" value='' />
				</div>
			</li>
				
			 <input type="hidden" name="action" value="<?php echo $formAction ?>">
            <input type="hidden" id="hdnFundingId" name="hdnFundingId" value="<?php echo $hdnFundingId; ?>">
          </ul>
        </div>
        <div class="submitBtn submit" style="display:inline-block; margin-left:calc(250px + 20px);">
            <div class="btnLoader" id="addFundingLoader" style="display:none;">
                <span class="spinLoader"></span>
            </div>
			 <input value="<?php echo ucfirst($formAction); ?> Funding" class="btn" type="button" id="addFunding" name="addFunding">
     
        </div>

    </form>
    <!-- form end -->	

</section>
<!-- 
	=============== 
	Page Content Ends
	===============
-->

<!-- 
	=============== 
	Footer Start
	===============
-->
<?php require_once ('inc/php/footer.php'); ?>
</body>
</html>
