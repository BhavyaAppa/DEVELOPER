<html>
	<head>
		<title> 
			This Is Title of Registration form
		</title>
		
		<h1> Registration Form </h1> 

		<script  type="text/javascript">
			var countryObject = 
			{
				// Value Initialization Dynamically Start From Here
				"India": 
					 {
						"Gujarat": ["Ahmedabad","Surat","Baroda"],
						"Maharastra": ["Bombay","Nagpur","Pune"],
						"Goa": ["Ponda", "Margao", "Mapusa"]
					},
				"USA": 
					{
						"California": ["Alameda","Belmont","Calistoga"],
						"Florida": ["Boca Raton","Cocoa Beach","De Land"]
					},

				"Canada": 
					{
						"British Columbia": ["Dawson Creek","Delta"," Esquimalt"],
						"Nova Scotia": ["Baddeck","Digby","Glace Bay"]

					}

				// Value Initialization Dynamically Ends Here
			}

			// Onload Function Starts From Here		
			window.onload = function()
			{
				// Variable Declaration Start From Here
				var country = document.getElementById( "country" ); 
				var state = document.getElementById( "state" );
				var city = document.getElementById( "city" );
				// Variable Declaration Ends Here
			
				//  For Loop Start For Contry Object From Here
				for (var x in countryObject) 
				{
				    country.options[country.options.length] = new Option(x, x);
				}
				//  For Loop Ends For Contry Object Here

				// Onchange Function For State Starts From Here
				country.onchange = function() 
				{
					city.length = 1;
					state.length = 1;

				    	// display correct values Using For Loop Starts From Here
					for (var y in countryObject[this.value])
					{
						state.options[state.options.length] = new Option(y, y);
					}	
					// display correct values Using For Loop Ends Here
				}	
				// Onchange Function For State Ends Here

				// Onchange Function For City Starts From Here
				state.onchange = function() 
				{
					//empty City dropdown
					city.length = 1;

					// correct values Using For Loop Start From Here
					var z = countryObject[country.value][this.value];

					for (var i = 0; i < z.length; i++) 
					{
				      		city.options[city.options.length] = new Option(z[i], z[i]);
				    	}
					// correct values Using For Loop Ends Here
				  }
				// Onchange Function For City Ends Here		
			}
			// Onload Function Ends Here

		</script>	
       		 	
	</head>  

	<body bgcolor="#f2f2f2">


		<form name="user_registration" method="post"> 
		
		<table>	

			<tr>
				<td>	FirstName :-	 </td>
				<td>	<input type="text" name="firstname" id="firstname" placeholder="Enter FirstName" autofocus="autofocus">
				</td>		
		 	</tr>

			<tr>
				<td>	LastName :-	 </td>
				<td>	<input type="text" name="lastname" id="lastname" placeholder="Enter LastName"> 
				</td>
		 	</tr>
		
			<tr>
				<td>	Email Id :- 	</td>
				<td>	
					<input type="text" name="email" id="email" placeholder="Enter Email">	
				</td>			
			</tr>
			
			<tr>
				<td> Country :- </td>
				<td> 
					<select id="country" name="country">
						<option value="" selected="selected"> Select contry </option>
					</select>
				</td>			
			</tr>
		
			<tr>
				<td> State :- </td>
				<td> 
					<select id="state" name="state">
						<option value="" selected="selected"> Select State </option>
					</select>
				</td>			
			</tr>

			<tr>
				<td> City :- </td>
				<td> 
					<select id="city" name="city">
						<option value="" selected="selected"> Select City </option>
					</select>
				</td>			
			</tr>

			<tr>
				<td>	Mobile No :-	</td>
				<td>	<input type="phone" id="mobile" placeholder="Enter Mobile No" maxlength="10" name="mobile"> 	
				</td> 

			</tr>
		
			<tr>
				<td>	Address :- 	</td>
				<td>	<textarea name="address" id="address" rows="5" cols="30" name="address">   </textarea>
				</td>
			</tr>
			
			<tr>
				<td>	Gender :- 	</td>
				<td>	<input type="radio" name="gender_radio" value="Male"> Male  
       			  	  	<input type="radio" name="gender_radio" value="Female"> Female 
				  	<input type="radio" name="gender_radio" value="Others"> Others  
				</td>

			</tr>


			<tr>
				<td>	Department :- 	</td>
				<td>	<input type="radio" name="department_radio" value="General"> General  
       			  	  	<input type="radio" name="department_radio" value="Marketing"> Markting 
				 	<input type="radio" name="department_radio" value="Finance"> Finance  
				</td>
			</tr>

			<tr>
				<td>	Technology :- 	</td>
				<td>	<input type="checkbox" name="technology[]" value="React JS"> React JS
					<input type="checkbox" name="technology[]" value="Node JS">Node JS
					<input type="checkbox" name="technology[]" value="PHP"> PHP
				</td>

			</tr>

			<tr>
				<td>	Username :-	 </td>
				<td>	<input type="text" name="username" id="username" placeholder="Enter Username"> 
				</td>
			</tr>

			
			<tr>
				<td>	Password :-	</td>
				<td>	<input type="password" id="password" placeholder="Enter Password" name="password"> 	
				</td> 
			</tr>

			<tr>
				<td>	</td>
				<td> <input type="submit" name="insert" value="Insert"> </td>
			</tr>

			<tr>
				<td>	</td>
				<td> <input type="submit" name="update" value="Update"> </td>
			</tr>

		</table>

		</form>	





		<?php 
			// declaration start from here
			$firstName = $lastName = $email = $country = $state = $city = $mobile = $address = $gender = $department = $technology = $username = $password =  "";
			$serverName = "localhost";
			$username = "root";
			$password = "admin";
			$database = "bhavya";
			// declaration end here

			
			$connection = mysqli_connect($serverName,$username,$password,$database);

			// connection established or not start from here
			if ($connection->connect_error)
 			{
 			 	die("Connection failed: " . $connection->connect_error);
			}
			// connection established or not end here
				
					// firstname set or not start form here
					if (isset($_REQUEST["firstname"]) && !empty($_REQUEST["firstname"]))
					{
						$firstName =  addslashes($_REQUEST["firstname"]);
					}
					// firstname set or not end here
					echo "<br> Firstname :-$firstName<br>";
					
					// lastname set or not start form here
					if (isset($_REQUEST["lastname"]) && !empty($_REQUEST["lastname"]))
					{
					    	$lastName =  addslashes($_REQUEST["lastname"]);	    	
					}
					// lastname set or not end here
					echo "Lastname :-$lastName<br>";

					// email set or not start form here
					if (isset($_REQUEST["email"]) && !empty($_REQUEST["email"]))
					{	
						$email =  $_REQUEST["email"];
					}
					// email set or not end here
					echo "Email :-  $email <br>";

					// country set or not start form here
					if (isset($_REQUEST["country"]) && !empty($_REQUEST["country"]))
					{
						$country = $_REQUEST["country"] ;
					}
					// country set or not end here
					echo "Country :- $country <br>";
					
					// state set or not start form here
					if (isset($_REQUEST["state"]) && !empty($_REQUEST["state"]))
					{		
						$state =  $_REQUEST["state"] ;
					}
					// state set or not end here
					echo "State :-  $state <br>";

					// city set or not start form here
					if (isset($_REQUEST["city"]) && !empty($_REQUEST["city"]))
					{	
						$city =  $_REQUEST["city"] ;
					}
					// city set or not end here
					echo "City :-  $city <br>";
		
					// mobileno set or not start form here
					if (isset($_REQUEST["mobile"]) && !empty($_REQUEST["mobile"]))
					{
						$mobile =  $_REQUEST["mobile"] ;
					}
					// mobileno set or not end here
					echo  "Mobile :-  $mobile  <br>";
		
					// address set or not start form here
					if (isset($_REQUEST["address"]) && !empty($_REQUEST["address"]))
					{
						$address = $_REQUEST["address"] ;
					}
					// address set or not end here
					echo  "Address :-  $address  <br>";

					// gender set or not start form here
					if (isset($_REQUEST["gender_radio"]) && !empty($_REQUEST["gender_radio"]))
					{	
						$gender = $_REQUEST["gender_radio"] ;		
					}
					// gender set or not end here
					echo  "Gender :-  $gender	<br>";
					
					// department set or not start form here
					if (isset($_REQUEST["department_radio"]) && !empty($_REQUEST["department_radio"]))
					{
						$department = $_REQUEST["department_radio"] ;
					}
					// department set or not start form here
					echo "Department :-  $department <br>";
	
					// technology set or not start form here
					if (isset($_REQUEST["technology"]) && !empty($_REQUEST["technology"]))
					{	
						foreach( $_REQUEST["technology"] as $values )
						{
							$technology = $_REQUEST["technology"] ;
							echo " Technology :-   $values  <br>" ;
						}
					}
					// technology set or not end here

					// username set or not start form here
					if (isset($_REQUEST["username"]) && !empty($_REQUEST["username"]))
					{
						$username = $_REQUEST["username"] ;	
					}
					// username set or not end here
					echo " Username :- $username  <br>";

					// password set or not start form here
					if (isset($_REQUEST["password"]) && !empty($_REQUEST["password"]))
					{
						$password = $_REQUEST["password"] ;		
					}
					// password set or not end here
					echo  "Password :-  $password <br>";	
					
					// array convert into string start from here
					if( isset( $technology ) && !empty( $technology ) )
					{
						$technology = implode( "  AND  " , $technology );
					}
					// array convert into string end here

					
					// insert query start from here
					$insert = $connection->query("INSERT INTO user(first_name,last_name,email,country,state,city,mobile,address,gender,department,technology,username,password)VALUES('$firstName','$lastName','$email','$country','$state','$city','$mobile','$address','$gender','$department','$technology','$username','$password')");
					// insert query end here
					// query execcute by if condition start from here
					$lastInsertedId = $connection->insert_id;
					
					if ($lastInsertedId != 0) 
					{
					  echo "Data Insert Successfully <br><br>";
					} 
					else 
					{
					  echo "<br> Error: <br>" . $connection->error;
					
					}
					// query execute by if condition end here

					mysqli_close($connection);
					
					
		?>
	
	</body>
</html>

			
