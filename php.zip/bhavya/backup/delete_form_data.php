﻿<?php include 'connection.php';?>
<html>
	<head>	
		<style> 
			table 
			{
				text-align: center;
			}  
		</style>
	</head>

	<body> 

	<?php 
		$id=" ";
		// count total no of request for delete data start from here 
		if(count($_REQUEST)>0) 
		{
				// declaration start from here
			$firstName = $lastName = $email = $country = $state = $city = $mobile = $address = $gender = $department = $technology = $username = $password =  "";
				// declaration ends here

				// delete button click start from here
				if(isset($_REQUEST['delete'])) 
				{
					// id set or not start form here
					if (isset($_REQUEST["id"]) && !empty($_REQUEST["id"]))
					{
						$id =  $_REQUEST["id"];
					}
					// id set or not end here
					
			
					// firstname set or not start form here
					if (isset($_REQUEST["firstname"]) && !empty($_REQUEST["firstname"]))
					{
						$firstName =  addslashes($_REQUEST["firstname"]);
					}
					// firstname set or not end here
					
					
					// lastname set or not start form here
					if (isset($_REQUEST["lastname"]) && !empty($_REQUEST["lastname"]))
					{
					    	$lastName =  addslashes($_REQUEST["lastname"]);	    	
					}
					// lastname set or not end here
					

					// email set or not start form here
					if (isset($_REQUEST["email"]) && !empty($_REQUEST["email"]))
					{	
						$email =  $_REQUEST["email"];
					}
					// email set or not end here
					

					// country set or not start form here
					if (isset($_REQUEST["country"]) && !empty($_REQUEST["country"]))
					{
						$country = $_REQUEST["country"] ;
					}
					// country set or not end here
					
					
					// state set or not start form here
					if (isset($_REQUEST["state"]) && !empty($_REQUEST["state"]))
					{		
						$state =  $_REQUEST["state"] ;
					}
					// state set or not end here
					

					// city set or not start form here
					if (isset($_REQUEST["city"]) && !empty($_REQUEST["city"]))
					{	
						$city =  $_REQUEST["city"] ;
					}
					// city set or not end here
					
		
					// mobileno set or not start form here
					if (isset($_REQUEST["mobile"]) && !empty($_REQUEST["mobile"]))
					{
						$mobile =  $_REQUEST["mobile"] ;
					}
					// mobileno set or not end here
					
		
					// address set or not start form here
					if (isset($_REQUEST["address"]) && !empty($_REQUEST["address"]))
					{
						$address = $_REQUEST["address"] ;
					}
					// address set or not end here
					

					// gender set or not start form here
					if (isset($_REQUEST["gender_radio"]) && !empty($_REQUEST["gender_radio"]))
					{	
						$gender = $_REQUEST["gender_radio"] ;		
					}
					// gender set or not end here
					
					
					// department set or not start form here
					if (isset($_REQUEST["department_radio"]) && !empty($_REQUEST["department_radio"]))
					{
						$department = $_REQUEST["department_radio"] ;
					}
					// department set or not start form here
					
	
					// technology set or not start form here
					if (isset($_REQUEST["technology"]) && !empty($_REQUEST["technology"]))
					{	
						foreach( $_REQUEST["technology"] as $values )
						{
							$technology = $_REQUEST["technology"] ;
						}
					}
					
					// technology set or not end here
					
					// username set or not start form here
					if (isset($_REQUEST["username"]) && !empty($_REQUEST["username"]))
					{
						$username = $_REQUEST["username"] ;	
					}
					// username set or not end here
					
					// password set or not start form here
					if (isset($_REQUEST["password"]) && !empty($_REQUEST["password"]))
					{
						$password = $_REQUEST["password"] ;		
					}
					// password set or not end here
					
					
					// array convert into string start from here
					if( isset( $technology ) && !empty( $technology ) )
					{
						$technology = implode( "," , $technology );
					}
					// array convert into string end here


		// Delete query for delete data into database start from here
		$delete = $connection->query("DELETE FROM user WHERE id='".$id."'");
		// Delete query for delete data into database end here
	
					// query execute by if condition start from here
					if ( empty($connection->error) ) 
					{
					  echo "Data Delete Successfully <br><br>";
					} 
					else 
					{
					  echo "<br> " . $connection->error . "<br><br>";
				          
					}
					// query execute by if condition end here
				}
				// delete button click end here
		}
		// count total no of request for delete data end here
		
		// id set or not start form here
		if (isset($_REQUEST["id"]) && !empty($_REQUEST["id"]))
		{
			$id =  $_REQUEST["id"];
		}
		// id set or not end here

		// fetch all data by select query start from here
		$result = $connection->query("SELECT * FROM user WHERE id='" . $id . "'");
			if ( empty($connection->error) ) 
			{
				$row= $result->fetch_array();
			} 
			else 
			{
				echo "<br> " . $connection->error . "<br><br>";	
				print_r($connection -> error_list);          
			}
		
	?>

		<form name="delete_form_data" method="post" action="">
				
		<table border="1">	

			<tr>
				<td>	FirstName :-	 </td>
				<td>	<?php echo $row['first_name']; ?> </td>		
		 	</tr>

			<tr>
				<td>	LastName :-	 </td>
				<td>	<?php echo $row['last_name']; ?> </td>
		 	</tr>
		
			<tr>
				<td>	Email Id :- 	</td>
				<td>	<?php echo $row['email']; ?>	</td>			
			</tr>
			
			<tr>
				<td> Country :- </td>
				<td> <?php echo $row['country']; ?>	</td>					
			</tr>
		
			<tr>
				<td> State :- </td>
				<td> <?php echo $row['state']; ?>  </td>					
			</tr>

			<tr>
				<td> City :- </td>
				<td> <?php echo $row['city']; ?> </td>			
			</tr>

			<tr>
				<td> Mobile No :- </td>
				<td>	<?php echo $row['mobile']; ?>	</td>		
			</tr>
		
			<tr>
				<td>	Address :- 	</td>
				<td>	<?php echo $row['address']; ?> </td>		
			</tr>

			<tr>
				<td>	Gender :- 	</td>
				<td>	<?php echo $row['gender']; ?>	</td>		
			</tr>

			<tr>
				<td>	Department :- 	</td>
				<td>	<?php echo $row['department']; ?>	</td>		
			</tr>
				
			<tr>
				<td>	Technology :- 	</td>
				<td>	<?php echo $row['technology']; ?>	</td>		
			</tr>

			<tr>
				<td>	Username :-	 </td>
				<td>	<?php echo $row['username']; ?>	</td>		
			</tr>

			<tr>
				<td>	Password :-	</td>
				<td>	<?php echo $row['password']; ?>	</td>		
			</tr>

			<tr>
				<td colspan="2"> <input type="submit" name="delete" value="Delete"> </td>
			</tr>


		</table>
					
	</body>
</html> 

	
