<?php
// **********************
// CLASS DECLARATION
// **********************

class user extends Database
{ 	// class : begin

// **********************
// ATTRIBUTE DECLARATION
// **********************

var $id;   // KEY ATTR. WITH AUTOINCREMENT

		var $first_name;   // (normal Attribute)
		var $last_name;   // (normal Attribute)
		var $email;   // (normal Attribute)
		var $country;   // (normal Attribute)
		var $state;   // (normal Attribute)
		var $city;   // (normal Attribute)
		var $mobile;   // (normal Attribute)
		var $address;   // (normal Attribute)
		var $gender;   // (normal Attribute)
		var $department;   // (normal Attribute)
		var $technology;   // (normal Attribute)
		var $username;   // (normal Attribute)
		var $password;   // (normal Attribute)
		var $created;   // (normal Attribute)
		var $modified;   // (normal Attribute)

var $criteria; //criteria of search
var $numRows; // numRows for total records

// **********************
// CONSTRUCTOR METHOD
// **********************
function __construct()
{ 
    $numArgs = func_num_args();
        
	if ($numArgs >=1)
	{
            parent::__construct(func_get_arg(0));
	}	
	else
            parent::__construct();   
   
    $this->condition = '1 = 1';
}

// **********************
// SELECT METHOD / LOAD
// **********************

function select()
{
$query = "SELECT * FROM user WHERE ";
$condition= $this->condition;
$param = $this->param;
	if (is_array($condition)) 
	{
		if(isset($condition['where_clause']) && !empty($condition['where_clause']))
		{
			$query .= $condition['where_clause'];
		} // if ends here of checking where_clause
		else 
		{
			$this->error = "where clause is  missing";
			return $this->error;
		} // else ends here of checking where_clause
		
		if(isset($condition['limit_clause']) && !empty($condition['limit_clause']))
		{
			$query .= $condition['limit_clause'];
		} // if ends here of checking limit_clause
		
	}// if ends here
	else
	{
		$query .= $condition;
	} // else ends here
		
	try
	{		
		$sql = $this->conn->prepare("$query");
		// echo "<pre>";print_r($sql);	
		$sql->setFetchMode(PDO::FETCH_ASSOC);
		$sql->execute($param);
		$result = $sql->fetch();	
		//print_r($result);	

$this->id = $sqlResult["id"];
$this->first_name = $sqlResult["first_name"];
$this->last_name = $sqlResult["last_name"];
$this->email = $sqlResult["email"];
$this->country = $sqlResult["country"];
$this->state = $sqlResult["state"];
$this->city = $sqlResult["city"];
$this->mobile = $sqlResult["mobile"];
$this->address = $sqlResult["address"];
$this->gender = $sqlResult["gender"];
$this->department = $sqlResult["department"];
$this->technology = $sqlResult["technology"];
$this->username = $sqlResult["username"];
$this->password = $sqlResult["password"];
$this->created = $sqlResult["created"];
$this->modified = $sqlResult["modified"];
		
		
		return $result;
	} // try block ends here
	catch(PDOException $e)
	{
		file_put_contents("PDOErrors.txt", $e->getMessage(), FILE_APPEND);
    	return $this->error = "Query execution error";
	} // catch block ends here
} // function ends here

// **********************
// SELECTALL  METHOD / LOAD
// **********************

function selectAll()
{
		
try
{
	$sql = $this->conn->prepare("SELECT * FROM user");
	//echo "<pre>";print_r($sql);
	$sql->setFetchMode(PDO::FETCH_ASSOC);
	$sql->execute();
	$sqlResult = $sql->fetchAll();
	

$this->id = $sqlResult["id"];
$this->first_name = $sqlResult["first_name"];
$this->last_name = $sqlResult["last_name"];
$this->email = $sqlResult["email"];
$this->country = $sqlResult["country"];
$this->state = $sqlResult["state"];
$this->city = $sqlResult["city"];
$this->mobile = $sqlResult["mobile"];
$this->address = $sqlResult["address"];
$this->gender = $sqlResult["gender"];
$this->department = $sqlResult["department"];
$this->technology = $sqlResult["technology"];
$this->username = $sqlResult["username"];
$this->password = $sqlResult["password"];
$this->created = $sqlResult["created"];
$this->modified = $sqlResult["modified"];
return $sqlResult;
} // try block ends here
catch(PDOException $e)
{
		file_put_contents("PDOErrors.txt", $e->getMessage(), FILE_APPEND);
    	return $this->error = "Query execution error";
    
} // catch block ends here
} // function ends here
				

// **********************
// selectByCriteria  METHOD / LOAD
// **********************

function selectByCriteria()
{
	
$query = "SELECT * FROM user WHERE ";
$condition= $this->condition;
$param = $this->param;
	if (is_array($condition)) 
	{
		if(isset($condition['where_clause']) && !empty($condition['where_clause']))
		{
			$query .= $condition['where_clause'];
		} // if ends here of checking where_clause
		else 
		{
			$this->error = "where clause is  missing";
			return $this->error;
		} // else ends here of checking where_clause
		
		if(isset($condition['limit_clause']) && !empty($condition['limit_clause']))
		{
			$query .= $condition['limit_clause'];
		} // if ends here of checking limit_clause
		
	}// if ends here
	else
	{
		$query .= $condition;
	} // else ends here
		
	try
	{		
		$sql = $this->conn->prepare("$query");
		//echo "<pre>";print_r($sql);	
		$sql->setFetchMode(PDO::FETCH_ASSOC);
		$sql->execute($param);
		$result = $sql->fetchAll();	
		//print_r($result);

$this->id = $sqlResult["id"];
$this->first_name = $sqlResult["first_name"];
$this->last_name = $sqlResult["last_name"];
$this->email = $sqlResult["email"];
$this->country = $sqlResult["country"];
$this->state = $sqlResult["state"];
$this->city = $sqlResult["city"];
$this->mobile = $sqlResult["mobile"];
$this->address = $sqlResult["address"];
$this->gender = $sqlResult["gender"];
$this->department = $sqlResult["department"];
$this->technology = $sqlResult["technology"];
$this->username = $sqlResult["username"];
$this->password = $sqlResult["password"];
$this->created = $sqlResult["created"];
$this->modified = $sqlResult["modified"];
$this->numRows = $sql->rowCount();

		
return $result;
} // try block ends here
catch(PDOException $e)
{
	file_put_contents("PDOErrors.txt", $e->getMessage(), FILE_APPEND);
   	return $this->error = "Query execution error";
	    
} // catch block ends here
} // function ends here

// **********************
// DELETE
// **********************

function delete()
{
	try
	{	
		$sql =  $this->conn->prepare("DELETE FROM user  WHERE $this->condition");
		//echo "<pre>";print_r($sql);
		$result = $sql->execute();
		$this->numRows = $sql->rowCount();
		return $result;
	} // try block ends here
	catch(PDOException $e)
	{
		file_put_contents("PDOErrors.txt", $e->getMessage(), FILE_APPEND);
    	return $this->error = "Query execution error";
    	
	    
	} // catch block ends here
} // function ends here
    			

// **********************
// INSERT
// **********************

function insert()
{

$this->id = ""; // clear key for autoincrement

$valueClause = array();
$columnClause = array();
	if(isset($this->first_name))
	 { 
		array_push($columnClause,"first_name" );
		array_push($valueClause,"$this->first_name");
	 } 
	if(isset($this->last_name))
	 { 
		array_push($columnClause,"last_name" );
		array_push($valueClause,"$this->last_name");
	 } 
	if(isset($this->email))
	 { 
		array_push($columnClause,"email" );
		array_push($valueClause,"$this->email");
	 } 
	if(isset($this->country))
	 { 
		array_push($columnClause,"country" );
		array_push($valueClause,"$this->country");
	 } 
	if(isset($this->state))
	 { 
		array_push($columnClause,"state" );
		array_push($valueClause,"$this->state");
	 } 
	if(isset($this->city))
	 { 
		array_push($columnClause,"city" );
		array_push($valueClause,"$this->city");
	 } 
	if(isset($this->mobile))
	 { 
		array_push($columnClause,"mobile" );
		array_push($valueClause,"$this->mobile");
	 } 
	if(isset($this->address))
	 { 
		array_push($columnClause,"address" );
		array_push($valueClause,"$this->address");
	 } 
	if(isset($this->gender))
	 { 
		array_push($columnClause,"gender" );
		array_push($valueClause,"$this->gender");
	 } 
	if(isset($this->department))
	 { 
		array_push($columnClause,"department" );
		array_push($valueClause,"$this->department");
	 } 
	if(isset($this->technology))
	 { 
		array_push($columnClause,"technology" );
		array_push($valueClause,"$this->technology");
	 } 
	if(isset($this->username))
	 { 
		array_push($columnClause,"username" );
		array_push($valueClause,"$this->username");
	 } 
	if(isset($this->password))
	 { 
		array_push($columnClause,"password" );
		array_push($valueClause,"$this->password");
	 } 
	if(isset($this->created))
	 { 
		array_push($columnClause,"created" );
		array_push($valueClause,"$this->created");
	 } 
	if(isset($this->modified))
	 { 
		array_push($columnClause,"modified" );
		array_push($valueClause,"$this->modified");
	 } 

for ($i=0; $i<count($columnClause);$i++)
	{
		if ($i != 0)
			$tempColumnValues .= ", ";
			
		$tempColumnValues .= "?";
	} 
$columnName = implode(',',$columnClause); 
$columnValue = implode(',',$valueClause);
	try
	{	
		$sql = $this->conn->prepare("INSERT INTO user ($columnName ) VALUES ( $tempColumnValues )");
		//echo "<pre>";print_r($sql); print_r($valueClause);
		$result = $sql->execute($valueClause);
		$this->id = $this->conn->lastInsertId();	
		return $result;		
	} // try block ends here
	catch(PDOException $e)
	{
		file_put_contents("PDOErrors.txt", $e->getMessage(), FILE_APPEND);
    	return $this->error = "Query execution error";
	} // catch block ends here
} // function ends here
		
		
		

// **********************
// UPDATE
// **********************

function update()
{
$valueClause = array();
$setClause = array();
	if(isset($this->first_name))
	 { 
		array_push($setClause,"first_name" );
		array_push($valueClause,"$this->first_name");
	 } 
	if(isset($this->last_name))
	 { 
		array_push($setClause,"last_name" );
		array_push($valueClause,"$this->last_name");
	 } 
	if(isset($this->email))
	 { 
		array_push($setClause,"email" );
		array_push($valueClause,"$this->email");
	 } 
	if(isset($this->country))
	 { 
		array_push($setClause,"country" );
		array_push($valueClause,"$this->country");
	 } 
	if(isset($this->state))
	 { 
		array_push($setClause,"state" );
		array_push($valueClause,"$this->state");
	 } 
	if(isset($this->city))
	 { 
		array_push($setClause,"city" );
		array_push($valueClause,"$this->city");
	 } 
	if(isset($this->mobile))
	 { 
		array_push($setClause,"mobile" );
		array_push($valueClause,"$this->mobile");
	 } 
	if(isset($this->address))
	 { 
		array_push($setClause,"address" );
		array_push($valueClause,"$this->address");
	 } 
	if(isset($this->gender))
	 { 
		array_push($setClause,"gender" );
		array_push($valueClause,"$this->gender");
	 } 
	if(isset($this->department))
	 { 
		array_push($setClause,"department" );
		array_push($valueClause,"$this->department");
	 } 
	if(isset($this->technology))
	 { 
		array_push($setClause,"technology" );
		array_push($valueClause,"$this->technology");
	 } 
	if(isset($this->username))
	 { 
		array_push($setClause,"username" );
		array_push($valueClause,"$this->username");
	 } 
	if(isset($this->password))
	 { 
		array_push($setClause,"password" );
		array_push($valueClause,"$this->password");
	 } 
	if(isset($this->created))
	 { 
		array_push($setClause,"created" );
		array_push($valueClause,"$this->created");
	 } 
	if(isset($this->modified))
	 { 
		array_push($setClause,"modified" );
		array_push($valueClause,"$this->modified");
	 } 

    for ($i=0; $i<count($setClause);$i++)
    {
        if ($i != 0)
        {
            $columnName .= " , $setClause[$i] = ?";
        }
        else
        {
            $columnName .= "$setClause[$i] = ?";
        }
    } 

	try
	{	
		$sql = $this->conn->prepare("UPDATE user SET  $columnName WHERE $this->condition ");
		//echo "<pre>";print_r($sql); print_r($valueClause);
		$result = $sql->execute($valueClause);
		$this->id = $sql->rowCount();
		return $result;
	} // try block ends here
	catch(PDOException $e)
	{
		file_put_contents("PDOErrors.txt", $e->getMessage(), FILE_APPEND);
    	return $this->error = "Query execution error";
    
	} // catch block ends here
} // function ends here

} // class ends here
