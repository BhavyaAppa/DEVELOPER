<?php
		define('SERVERNAME', 'localhost');
		define('USERNAME', 'root');
		define('PASSWORD', 'admin');
		define('DATABASE', 'bhavya');
		 
		try
		{
			$connection = new PDO("mysql:host=" . SERVERNAME . ";dbname=" . DATABASE, USERNAME, PASSWORD);
		    
			//  echo "Connected successfully <br><br>";
			
		} 
		catch(PDOException $e)
		{
		    die("ERROR: Could not connect. " . $e->getMessage());
		}
?>


