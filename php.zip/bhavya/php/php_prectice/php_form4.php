<html>
	<head>
		<title>	this is title	</title>
		<script>
			// function validate start from here
			function validate()
			{
				// variable declaration start from here
				var name = document.getElementById("name").value; 
				var letters = /[^0-9 ]/g;
				var mobile = document.getElementById("mobile").value;
				var email = document.getElementById("email").value;
				var expression  = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
				var password = document.getElementById("password").value;
				var passwordExpression = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})");
				var address = document.getElementById("address").value;
				var hobby = document.getElementById("hobby");
				var hobby2 = hobby.options[hobby.selectedIndex];
				// variable declaration end here		

				// Name Validation start from here
				if( name == "" || letters.test(name) == false )
				{
					document.getElementById("nameError").style.color="red";	
					document.getElementById("nameError").innerHTML = "Please enter name";
					return false;	
				}
				// Name Validation end here	

				// Mobile No Validation start from here

			 	else if( mobile == "" || isNaN(mobile) || mobile.length != 10 )
				{
					document.getElementById("mobileError").style.color="red";
					document.getElementById("mobileError").innerHTML = "Please enter valid mobile no";
					return false;	
				}
				// Mobile No Validation ends here
		
				//  Email Validation start from here

				else if( expression.test(email) == false )
				{
					document.getElementById("emailError").style.color="red";
					document.getElementById("emailError").innerHTML = "Please enter the valid email !!";
					return false;	
				}				
				//  Email Validation ends here
				
				else if( password == "" )
				{
					document.getElementById("passwordError").style.color="red";
					document.getElementById("passwordError").innerHTML = "Please enter password !!";
					return false;	
				}
			
				else if( passwordExpression.test(password) == false )
				{
					document.getElementById("passwordError").style.color="red";
					document.getElementById("passwordError").innerHTML = "PassWord Must Be Min. Length = 8 , Lowercase  = 1 , Uppercase = 1 , Digit = 1 , Special Character = 1 !!";
					return false;	
				}
		
				// Adress validation start from here	
				else if( address.length == "" )
				{
					document.getElementById("addressError1").style.color="red";
					document.getElementById("addressError1").innerHTML = "Plz Enter Residence Address !!";
					return false;
				}
	
				else if( address.length <= 20 || address.length >= 100 )
				{
					document.getElementById("addressError2").style.color="red";
					document.getElementById("addressError2").innerHTML = "Residence Address Length Should Be Between 20 To 100 Character !!";
					return false;
				}
				// Adress validation ends here

				// Dropdownlist Validation start from here
				else if( hobby2.index == 0 )
				{
					document.getElementById("hobbyError").style.color="red";
					document.getElementById("hobbyError").innerHTML = "Plz  Select Hobby !!";
					return false;
				}		
				// Dropdownlist Validation ends here
			
			}
			// function validate end here




			// Error Message function start from here
			function errorMessage()
			{
				document.getElementById("nameError").innerHTML = "";
				document.getElementById("mobileError").innerHTML = "";
				document.getElementById("emailError").innerHTML = "";
				document.getElementById("passwordError").innerHTML = "";
				document.getElementById("addressError1").innerHTML = "";
				document.getElementById("addressError2").innerHTML = "";
				document.getElementById("hobbyError").innerHTML = "";
			}
			// Error Message function end here
		</script>
	</head>

	<body bgcolor="#f2f2f2">

		
		<form name="myform" method="post" action="php_print2.php" align="center" onsubmit="return validate()">
		
		<table>		
			<tr>
				<td>	Name :-	 </td>
				<td>	<input type="text" name="name" id="name" placeholder="Enter Name" onkeyup="errorMessage()" autofocus="autofocus"> 
				</td>
				<td>	<p id="nameError">	</p>	</td>
		 	</tr>
		

			<tr>
				<td>	Mobile No :-	</td>
				<td>	<input type="phone" id="mobile" name="mobile" placeholder="Enter Mobile No" maxlength="10" onkeyup="errorMessage()"> 	
				</td> 
				<td>	<p id="mobileError">	</p>	</td>
			</tr>
		

			<tr>
				<td>	Email Id :- 	</td>
				<td>	<input type="email" name="email" id="email" placeholder="Enter Email" onkeyup="errorMessage()">	
				</td>
				<td>	<p id="emailError">	</p>	</td>
			</tr>

			<tr>
				<td> Password </td>
				<td> <input type="password" name="password" id="password" placeholder="Enter Password" onkeyup="errorMessage()" /> </td>
				<td> <p id="passwordError"> </p> </td>
			</tr>

			<tr>
				<td>	Adress :- 	</td>
				<td>	<textarea name="address" id="address" rows="5" cols="30" onkeyup="errorMessage()">   </textarea>
				</td>
				<td>	<p id="addressError1">	<p id="addressError2">	</p>	</td>
			</tr>
		
			<tr>
				<td>	Hobby :-   </td>
				<td>	<select id="hobby" name="hobby" onmouseup="errorMessage()">		
						<option>	Select		</option>
						<option>	Cricket		</option>
						<option>	Football	</option>
						<option>	Vollyball	</option>
						<option>	Tennis		</option>
				    	</select>	
				</td>
				<td>	<p id="hobbyError"> <p>	</td>
			<tr>
				<td>	</td>
				<td>	<input type="submit" value="Submit">   </td>
			</tr>
		</table>

		</form>

	</body>
</htmL>



