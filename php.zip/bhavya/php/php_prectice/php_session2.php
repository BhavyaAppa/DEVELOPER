<?php
	session_start();
?>

<html>
	<head> <h4> this is session stored </h4> </head>

	<body>
	
	<?php 
	
	echo $_SESSION["user"]; echo "<br><br>";
	echo $_SESSION["password"];

	?>

	</body>
</html>
