<html>
	<body>

		<?php
		    // interface start from here
		    interface Animal
		    {	
			// functio declaration here
		    	public function demo();
		    }
		    // interface end here

		    // Dog class start from here
		    class Dog implements Animal 
		    {
			// demo function implements start from here
		    	public function demo()
			{
				echo "dog";	
			}	
			// demo function implements end  here
		    }
		     // Dog class end here

		    // Cat class start from here
		    class Cat implements Animal
		    {
			// demo function implements start from here
		    	public function demo()
			{	
				echo "Cat";	
			}
			// demo function implements end here
		    }
		    // Cat class end here

		     // Rat class start from here
		    class Rat implements Animal
		    {
			// demo function implements start from here
		    	public function demo()
			{	
				echo "Rat";	
			}
			// demo function implements end here
		    }
		     // Rat class end here

		    // create object start from here
		    $dog = new Dog();
		    $cat = new Cat();
		    $rat = new Rat();
		    // create object end here

		    $animal = array($dog , $cat , $rat);
		    
		    // foreach loop for object calling start from here
		    foreach($animal as $value)
		    {
		    	$value->demo();
		    }
		     // foreach loop for object calling end shere
		?>    

</body>
</html>







