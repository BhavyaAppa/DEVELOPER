<!DOCTYPE html>
<html>
<body>

 <?php
 class fruit
    {
    	public $name;
        public $color;
        
        function __construct( $name , $color )
        {
        	$this->name = $name;
            	$this->color = $color;
        }
         
        function get_name()
        {
        	return $this->name;
        }
        
        function get_color()
        {
        	return $this->color;
        }
        
       	function __destruct()
        {
        	echo "<br> the fruit is	" . $this->name;
            	echo "<br> the color is	" . $this->color;
        }
    }
    
    $object  = new fruit("banana" , "apple");
    echo $object->get_name()."<br>". $object->get_color();
 ?>
</body>
</html>

