<!DOCTYPE html>
<html>
<body>
 
<?php
	// trait keyword for declaration start from here
	trait message
	{
		// function start from here
		public function msg()
		{	
			echo "Hello Fun";
		}
		// function end here
	}
	// trait end here

	// class welcome start from here
	class Welcome
	{
		// use keyword for message class
		use message;
	}
	// class welcome end here

	// object creation start from here
	$obj = new Welcome();
	$obj->msg();
	// object creation end here
?>

</body>
</html>

