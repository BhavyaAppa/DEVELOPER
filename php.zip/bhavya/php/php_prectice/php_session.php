
<?php
	session_start();	

?>

<html>
	<head>
		<title> this is title </title>
	</head>
	<body>
	<?php 
	
	$_SESSION["user"] = "bhavya";
	$_SESSION["password"] = "bhavya@123";
	echo "session created <br>";

	?>

	<a href="session2.php"> visit next page </a>
	</body>
