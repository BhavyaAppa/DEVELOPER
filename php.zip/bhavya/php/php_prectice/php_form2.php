<html>
	<head>
		<title>	this is title	</title>

		<script>
			// function validate start from here
			function validate()
			{
				// variable declaration start from here
				var name = document.getElementById("name").value; 
				var letters = /[^0-9 ]/g;
				var mobile = document.getElementById("mobile").value;
				var email = document.getElementById("email").value;
				var expression  = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
				var password = document.getElementById("password").value;
				var passwordExpression = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})");
				// variable declaration end here		

				// Name Validation start from here
				if( name == "" || letters.test(name) == false )
				{
					document.getElementById("nameError").style.color="red";	
					document.getElementById("nameError").innerHTML = "Please enter name";
					return false;	
				}
				// Name Validation end here	

				// Mobile No Validation start from here

			 	else if( mobile == "" || isNaN(mobile) || mobile.length != 10 )
				{
					document.getElementById("mobileError").style.color="red";
					document.getElementById("mobileError").innerHTML = "Please enter valid mobile no";
					return false;	
				}
				// Mobile No Validation ends here
		
				//  Email Validation start from here
				else if( expression.test(email) == false )
				{
					document.getElementById("emailError").style.color="red";
					document.getElementById("emailError").innerHTML = "Please enter the valid email !!";
					return false;	
				}				
				//  Email Validation ends here
				
				//  password Validation start from here
				else if( password == "" )
				{
					document.getElementById("passwordError").style.color="red";
					document.getElementById("passwordError").innerHTML = "Please enter password !!";
					return false;	
				}
			
				else if( passwordExpression.test(password) == false )
				{
					document.getElementById("passwordError").style.color="red";
					document.getElementById("passwordError").innerHTML = "PassWord Must Be Min. Length = 8 , Lowercase  = 1 , Uppercase = 1 , Digit = 1 , Special Character = 1 !!";
					return false;	
				}
				//  password Validation end here

			}
			// function validate end here


			// Error Message function start from here
			function errorMessage()
			{
				document.getElementById("nameError").innerHTML = "";
				document.getElementById("mobileError").innerHTML = "";
				document.getElementById("emailError").innerHTML = "";
				document.getElementById("passwordError").innerHTML = "";
			}
			// Error Message function end here
		</script>
	</head>

	<body bgcolor="#f2f2f2">

		

		<form name="myform" method="post" action="php_print.php" align="center" onsubmit="return validate()">
		
		<table>		
			<tr>
				<td>	Name :-	 </td>
				<td>	<input type="text" name="name" id="name" placeholder="Enter Name" onkeyup="errorMessage()" autofocus="autofocus"> 
				</td>
				<td>	<p id="nameError">	</p>	</td>
		 	</tr>
		

			<tr>
				<td>	Mobile No :-	</td>
				<td>	<input type="phone" id="mobile" name="mobile" placeholder="Enter Mobile No" maxlength="10" onkeyup="errorMessage()"> 	
				</td> 
				<td>	<p id="mobileError">	</p>	</td>
			</tr>
		

			<tr>
				<td>	Email Id :- 	</td>
				<td>	<input type="email" name="email" id="email" placeholder="shahbhavya171099@gmail.com" onkeyup="errorMessage()">	
				</td>
				<td>	<p id="emailError">	</p>	</td>
			</tr>

			<tr>
				<td> Password </td>
				<td> <input type="password" name="password" id="password" placeholder="Enter Password" onkeyup="errorMessage()" /> </td>
				<td> <p id="passwordError"> </p> </td>
			</tr>

			<tr>
				<td>	</td>
				<td>	<input type="submit" value="Submit">   </td>
			</tr>
		</table>

		</form>

	</body>
</htmL>


