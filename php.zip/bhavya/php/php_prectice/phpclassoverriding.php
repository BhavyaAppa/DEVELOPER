<!DOCTYPE html>
<html>
<body>		 
		<?php
		// class fruit start form here
		class fruit
		{
			public $name;
			public $color;

			// constructor start from here
			public function __construct($name , $color)
			{
				$this->name = $name;
				$this->color = $color;
			}
			// constructor end here

			// function intro start from here
			public function intro()
			{
				echo "the fruit is {$this->name} and color is {$this->color}.";
			}
			// function intro end  here
		}
		// class fruit end here
		
		// class sabji start form here
		class sabji extends fruit
		{
			public $weight;
			
			// constructor start from here
			public function __construct($name , $color , $weight )
			{
				$this->name = $name;
				$this->color = $color;
				$this->weight = $weight;
			}
			 // constructor end here
			 
			// function intro start from here
			public function intro()
			{
				echo "the fruit is {$this->name} the color is {$this->color} and weight is {$this->weight} .";
			}
		  // function intro end here
		}
		// class sabji end here

		// object creatiion start from here
		$obj = new sabji("banana" , "yellow" , 100);
		$obj->intro(); echo "<br>";

		$obj2 = new fruit("mango" , "orange");
		$obj2->intro(); echo "<br>";
		// object creatiion start from here
	?>
</body>
</html>



