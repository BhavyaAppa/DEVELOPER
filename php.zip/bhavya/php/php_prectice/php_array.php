

<?php 
	// array declaration start from here
	
	// array using key and values start from here
	$employee = array(
		"name"=>"alex",
		"email"=> "alex_@gmail.com",
		"age"=>21,
		"gender"=> "male"
		);
	// array using key and values end here

	$emp = array("demo1", "demo2", "demo3", "demo4");

	// multidiamensional array start from here
	$emp2 = array(
		array("demo1","demo2","demo3","demo4"),
		array("demo11","demo12","demo13","demo14"),
		array("demo21","demo22","demo23","demo24"),
		array("demo31","demo32","demo33","demo34")
		);
	// multidiamensional array end here 

	// array declaration end here
	
	// constant value use by define() method	
	define("MESSAGE" , "hii i am bhavya and I am using constant <br><br><br>");
	
	echo MESSAGE;
	
	// display foreach loop by associative array start from here 
	foreach( $employee as $key => $element )
	{
		echo $key . " : " . $element;
		echo "<br>";
	}
	// display foreach loop by associative array end here

	// for loop for display start from here
	for( $x = 0; $x < count($emp) ; $x++ )
	{
		echo "<br><br>" . $emp[$x];
	}
	// for loop for display end here

	// for loop for multidiamensional array start from here 
	for( $i = 0 ; $i < 4 ; $i++ )
	{
		for( $j = 0 ; $j < 4 ; $j++ )
		{
			echo "<br> " . $emp2[$i][$j] ;
		}
		echo "<br>";
	}
	// for loop for multidiamensional array end here
?>
