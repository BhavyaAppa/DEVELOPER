<html>
	<body>
		<?php
			// abstract class start from here
			abstract class Car 
			{
				public $name;
				//  constructor start from here
				public function __construct( $name )
				{
					$this->name = $name;
				}
				//  constructor end here
				
				// abstract function declaration  here
				abstract public function intro() : string;
			}
			// abstract class end here
			
			// class audi start form here
			class Audi extends Car
			{
				// function implementation start form here
				public function intro() : string
				{
					return $this->name;
				}
				// function implementation end here
			}
			// class audi start form here
			
			// class volvo start form here
			class Volvo extends Car 
			{
				// function implementation start form here
				public function intro() : string
				{
					return $this->name;
				}
				// function implementation end here
			}
			// class volvo end here
			
			// class BMW start form here
			class Bmw extends Car
			{
				// function implementation start form here
				public function intro() : string
				{
					return $this->name;
				}
				// function implementation end here
			}
			}			
			// class BMW end here

			// object creation  and calling start form here
			$audi = new Audi( "Audi" );
			echo $audi->intro() ;		echo"<br>";

			$volvo = new Volvo( "Volvo" );
			echo $volvo->intro();	echo"<br>";

			$bmw = new Bmw( "BMW" );
			echo  $bmw->intro();	echo"<br>";
			// object creation  and calling end here
		?>
	
	</body>
</html>









