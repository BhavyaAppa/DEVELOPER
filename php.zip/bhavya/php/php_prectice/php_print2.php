<html>
	<head>
		<title> this is title </title>

		<h2> This is Form Data </h2>
	</head>

	<body bgcolor="#ffcccc">
	<?php
	
		if( $_SERVER["REQUEST_METHOD"] == "POST" )
		{
		// Data Get from server by global variables start from here
		$name = $_POST["name"];
		$mobile = $_POST["mobile"];
		$email = $_POST["email"];
		$password = $_POST["password"];
		$address = $_POST["address"];
		$hobby = $_POST["hobby"];
		// Data Get from server by global variables end here

		// Data print on the second page start from here
		echo "Name :-  $name . <br><br> ";
		echo "Mobile :-  $mobile . <br><br> ";
		echo "Email :-  $email . <br><br> ";
		echo "Password :-  $password . <br><br> ";
		echo "Address :- $address . <br><br> ";
		echo "Hobby :- $hobby .<br><br>";
		// Data print on the second page end from here
		}

		else
		{
			echo "Error in method";
		}
	
	?>

	</body>
</html>
