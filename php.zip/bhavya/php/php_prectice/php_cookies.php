
<?php 
// set cookie name and value 
setcookie("user", "bhavya");

?>

<html>
	<head> 	</head>

	<body>

	<?php
		// check cookie is set or not 
		
		if(!isset($_COOKIE["user"]))
		{
			echo "cookie not found !!!";
		}
		
		else 
		{
			echo "<br> Cookie value is : " . $_COOKIE["user"];
		}
		
	?>
	</body>
</html>

<?php
	// use for delete cookie
	setcookie("user" , "bhavya",time() - 3600 );
	echo "cookie is delete";
?>
