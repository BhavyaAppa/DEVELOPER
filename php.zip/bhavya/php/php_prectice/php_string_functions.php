
<?php
	// str declaration start here
	$str = "good morning everyone.";
	$str2 = "good morning everyone.";

	echo "before print :- " . $str;
	echo "</br>";

	// uc words method start from here
	$result1 = ucwords( $str ) ;
	echo "<br><br> Ucwords :- " . $result1 ;

	// lc first method start from here
	$result2 = lcfirst( $result1 ) ;
	echo "<br><br> Lcfirst :-" . $result2 ;

	// uc first method start from here
	$result3 = ucfirst( $result2 ) ;
	echo "<br><br> Ucfirst :-" . $result3 ;

	// find string length by strlen start from here
	$result4 = strlen( $result3 ) ;
	echo "<br><br> Str length :-" . $result4 ;

	//string length start from here
	$result5 = strrev( $result3 ) ;
	echo "<br><br> Str Reverse :- " . $result5 ;

	// string replace start from here
	$result6 = str_replace( "everyone" , "bhavya" , $str ) ;
	echo "<br><br> String Replace :-" . $result6;

	// string compare start from here
	$result7 = strcmp( $str , $str2 ) ;
	echo "<br><br> String Compare :-" . $result7 ;

	// string word count start from here
	$result8 = str_word_count( $str ) ;
	echo "<br><br> String Word Count :-" . $result8 ; 

	// string toupper start from here 
	$result9 = strtoupper( $str ) ;
	echo "<br><br> String ToUpper Case :-" . $result9 ;
	
	// string tolower start from here
	$result10 = strtolower( $result9 ) ;
	echo "<br><br> String Tolower Case :-"  . $result10 ;

	// string repeat start from here
	$result11 = str_repeat( $result10 , 2 ) ;
	echo "<br><br> String Repeat :-" . $result11 ; 

	// substring method start from here
	$result12 = substr( $str , 3 , 13 );	
	echo "<br><br> Sub String :- " . $result12 ; 

	// ltrim method start from here
	$result13 = trim( $str2 );	
	echo "<br><br> trim :- " . $result13 ;

	// count string start from here
	$result14 = count( $str );
	echo "<br><br> Count :-s
	
?>
