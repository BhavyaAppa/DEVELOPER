
<html>
	<head>
		<title> this is title </title>

	</head>

	<body>
	
	<?php
	# assign variable start from here
	$x = 6; // global data
	# assign variable end here 

	// function myTest start from here
	function myTest()
	{
		$y = 4;		 // local data
		global $x;		//Global data
		$z = $x + $y;

		echo "<p> variable x inside function is $z  </p> ";
	}
	// function myTest end here

	myTest();

	echo "<p> variable outside function is $x </p>";
	?>
	</body>
</html>

