<!DOCTYPE html>
<html>
	<body>
		<?php
		class fruit
		{
		    public $name ; 
		    public $color;
		    const MESSAGE = "Thank you for use constant keyword";

		    public function __construct($name, $color) 
		    {
		    	$this->name = $name;
			$this->color = $color;
		    }
		    
		    public function intro()
		    {
			echo self :: MESSAGE;	echo"<br>";
		    	echo "the name is {$this->name} and color is {$this->color} .";
		    }
		}

		class sabji extends fruit
		{
		    public function message() 
		    {
		    	echo "this is message function";
		    }
		}

		$sabji = new sabji("banana", "yellow");
		echo"<br>";	$sabji->message();
		echo"<br>";	$sabji->intro();
		?>
	</body>
</html>
