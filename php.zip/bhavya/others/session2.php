<?php
	// session start method for store and pass data
	session_start();
?>

<html>
	<head> <h4> this is session stored </h4> </head>

	<body>
	
	<?php 
	// print session name and value 
	echo "Name :- " . $_SESSION["user"]; echo "<br><br>";
	echo "value :- " . $_SESSION["password"];
	
	// session value unset and destroy after using datas
	session_unset();
	echo "<br><br> session unset <br><br>";

	session_destroy();
	echo "session destroy";

	?>
	</body>
</html>
