
<?php
	// session start method for store and pass data
	session_start();	

?>

<html>
	<head>
		<title> this is title </title>
	</head>
	<body>
	<?php 
	// session value set by $_SESSION 
	$_SESSION["user"] = "bhavya";
	$_SESSION["password"] = "bhavya@123";
	echo "session created <br>";

	?>

	<a href="php_session2.php"> visit next page </a>
	</body>
</html>

 
