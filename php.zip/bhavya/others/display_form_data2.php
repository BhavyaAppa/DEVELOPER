<html>
	<head>
		<title> Submit all Data </title>

		<h3> This is Submit Data  </h3>
		
	<style> 
	error 
	{
		color: #FF0001;
	}  
	</style>  
		
	</head>

	<body>

	<?php 
			// declaration start from here
			$firstName = $lastName = $email = $country = $state = $city = $mobile = $address = $gender_radio = $department_radio = $technology = $username = $password = $array1 =  "";

		/*			
			$regex = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/'; 
			$passwordExpression = "/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/";

			// declaration end here

			
				// firstname validation start from here
				if ( empty( $_REQUEST["firstname"] ) )
				{
					echo  "<br>  Please enter a firstname <br>";
				}
				// firstname validation end here

				// lastname validation start from here
				else if ( empty( $_REQUEST["lastname"] ) )
				{
					echo "<br> Please enter a lastname <br>";
				}
				// lastname validation end here
			
				// email validation start from here
				else if( empty( $_REQUEST["email"] ) )
				{
					echo "<br> Please Enter Email <br>";
				}
	
				else if( !preg_match($regex , $_REQUEST["email"] ) )
				{
					echo "<br> Please Enter valid Email <br>";

				}
				// email validation end here
				
				// contry select validation start from here
				else if( empty( $_REQUEST["country"] ) )
				{
					echo "<br> Please Select Contry <br>";
				}
				// contry select validation end here
	
				// state select validation start from here
				else if( empty( $_REQUEST["state"] ) )
				{
					echo "<br> Please Select State <br>";
				}
				// state select validation end here
	
				// city select validation start from here
				else if( empty( $_REQUEST["city"] ) )
				{
					echo "<br> Please Select City <br>";
				}
				// city select validation end here
	
				// mobile no validation start from here
				else if( empty( $_REQUEST["mobile"] ) )
				{
					echo "<br> Please Enter Mobile No <br>";
				}

				else if( !preg_match( "/^[0-9]*$/", $_REQUEST["mobile"] ) )
				{
					echo "<br> Please enter valid Mobile No <br>";
							
				}
				// mobile no validation end here

				// address validation start from here
				else if( empty( $_REQUEST["address"] ) )
				{
					echo "<br> Please Enter Adress <br>" ;
				}
	
				else if( strlen( $_REQUEST["address"] ) > 1 && strlen( $_REQUEST["address"] ) < 10 )
				{
					echo "<br> Please Enter Address Length > 10 <br>";
				}
				// address validation start from here

				// gender validation start from here
				else if( empty($_REQUEST["gender_radio"] ) )
				{
					echo "<br> Please Select Gender <br>";
				}
				// gender validation end here

				// Deprtment validation start from here
				else if( empty( $_REQUEST["department_radio"] ) )
				{
					echo "<br> Please Select Department <br> ";
				}
				// Department validation end here
				
				// Technology select by checkbox start from here
				else if( empty( $_REQUEST["technology"] ) )
				{
					echo "<br> Please Select Atleast One Technology <br>";
				}
				// Technology select by checkbox end here
		
				// username validation start from here
				else if ( empty( $_REQUEST["username"] ) )
				{
					echo  "<br> Please enter a Username <br>";
				}
				// username validation end here
				
				// password validation start form here
				else if ( empty( $_REQUEST["password"] ) )
				{
					echo  "<br> Please enter a Password <br>";
				}	
		
				else if( !preg_match( $passwordExpression, $_REQUEST["password"] ) )
				{
					echo "<br> Please enter valid password which include total length = 8 , uppercase = 1 , lowercase = 1 , special character = 1 , digit = 1 <br>";
							
				}  
		*/
				// password validation end here
			
				// Display all data start from here
				
					if (isset($_REQUEST["firstname"]) && !empty($_REQUEST["firstname"]))
					{
						$firstName =  $_REQUEST["firstname"] ;
					}
					echo "<br> Firstname :-$firstName<br>";
	
					if (isset($_REQUEST["lastname"]) && !empty($_REQUEST["lastname"]))
					{
					    	$lastName =  $_REQUEST["lastname"] ;	    	
					}
					echo "<br> Lastname :-$lastName<br>";

					if (isset($_REQUEST["email"]) && !empty($_REQUEST["email"]))
					{	
						$email =  $_REQUEST["email"];
					}
					echo "<br> Email :-  $email <br>";

					if (isset($_REQUEST["country"]) && !empty($_REQUEST["country"]))
					{
						$country = $_REQUEST["country"] ;
					}
					echo "<br> Country :- $country <br>";
					
					if (isset($_REQUEST["state"]) && !empty($_REQUEST["state"]))
					{		
						$state =  $_REQUEST["state"] ;
					}
					echo "<br> State :-  $state <br>";

					if (isset($_REQUEST["city"]) && !empty($_REQUEST["city"]))
					{	
						$city =  $_REQUEST["city"] ;
					}
					echo "<br> City :-  $city <br>";
		
					if (isset($_REQUEST["mobile"]) && !empty($_REQUEST["mobile"]))
					{
						$mobile =  $_REQUEST["mobile"] ;
					}
					echo  "<br> Mobile :-  $mobile  <br>";
		
					if (isset($_REQUEST["address"]) && !empty($_REQUEST["address"]))
					{
						$address = $_REQUEST["address"] ;
					}
					echo  "<br> Address :-  $address  <br>";

					if (isset($_REQUEST["gender_radio"]) && !empty($_REQUEST["gender_radio"]))
					{	
						$gender_radio = $_REQUEST["gender_radio"] ;		
					}
					echo  "<br> Gender :-  $gender_radio	<br>";
					
					if (isset($_REQUEST["department_radio"]) && !empty($_REQUEST["department_radio"]))
					{
						$department_radio = $_REQUEST["department_radio"] ;
					}
					echo "<br> Department :-  $department_radio  <br>";
	
					if (isset($_REQUEST["technology"]) && !empty($_REQUEST["technology"]))
					{	
						foreach( $_REQUEST["technology"] as $values )
						{
							echo "<br> Technology :-   $values  <br>" ;
						}
					}
					else
					{
						$technology = "";
						echo "<br> Technology :-   $technology  <br>";
					}

					if (isset($_REQUEST["username"]) && !empty($_REQUEST["username"]))
					{
						$username = $_REQUEST["username"] ;	
					}
					echo "<br> Username :- $username  <br>";

					if (isset($_REQUEST["password"]) && !empty($_REQUEST["password"]))
					{
						$password = $_REQUEST["password"] ;		
					}
					echo  "<br> Password :-  $password <br>";	
					
		?>
	
		
	</body>
</html>

