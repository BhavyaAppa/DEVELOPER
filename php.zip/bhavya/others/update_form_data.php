﻿<html>
	<head>
		<script  type="text/javascript">
			var countryObject = 
			{
				// Value Initialization Dynamically Start From Here
				"India": 
					 {
						"Gujarat": ["Ahmedabad","Surat","Baroda"],
						"Maharastra": ["Bombay","Nagpur","Pune"],
						"Goa": ["Ponda", "Margao", "Mapusa"]
					},
				"USA": 
					{
						"California": ["Alameda","Belmont","Calistoga"],
						"Florida": ["Boca Raton","Cocoa Beach","De Land"]
					},

				"Canada": 
					{
						"British Columbia": ["Dawson Creek","Delta"," Esquimalt"],
						"Nova Scotia": ["Baddeck","Digby","Glace Bay"]

					}
				

				// Value Initialization Dynamically Ends Here
			}

			// Onload Function Starts From Here		
			window.onload = function()
			{
				// Variable Declaration Start From Here
				var country = document.getElementById( "country" ); 
				var state = document.getElementById( "state" );
				var city = document.getElementById( "city" );
				// Variable Declaration Ends Here
			
				//  For Loop Start For Contry Object From Here
				for (var x in countryObject) 
				{
				    country.options[country.options.length] = new Option(x, x);
				}
				//  For Loop Ends For Contry Object Here

				// Onchange Function For State Starts From Here
				country.onchange = function() 
				{
					city.length = 1;
					state.length = 1;

				    	// display correct values Using For Loop Starts From Here
					for (var y in countryObject[this.value])
					{
						state.options[state.options.length] = new Option(y, y);
					}	
					// display correct values Using For Loop Ends Here
				}	
				// Onchange Function For State Ends Here

				// Onchange Function For City Starts From Here
				state.onchange = function() 
				{
					//empty City dropdown
					city.length = 1;

					// correct values Using For Loop Start From Here
					var z = countryObject[country.value][this.value];

					for (var i = 0; i < z.length; i++) 
					{
				      		city.options[city.options.length] = new Option(z[i], z[i]);
				    	}
					// correct values Using For Loop Ends Here
				  }
				// Onchange Function For City Ends Here		
			}
			// Onload Function Ends Here

		</script>	
       		 	
	</head>

	<body> 

	<?php 
			// declaration start from here
			$firstName = $lastName = $email = $country = $state = $city = $mobile = $address = $gender = $department = $technology = $username = $password =  "";
			$serverName = "localhost";
			$username = "root";
			$password = "admin";
			$database = "bhavya";
			// declaration end here

			
			$connection = mysqli_connect($serverName,$username,$password,$database);

			// connection established or not start from here
			if ($connection->connect_error)
 			{
 			 	die("Connection failed: " . $connection->connect_error);
			}
			// connection established or not end here
	?>




		<?php

		// count total no of request for update data start from here 
		if(count($_REQUEST)>0) 
		{
				$id=$firstName = $lastName = $email = $country = $state = $city = $mobile = $address = $gender = $department = $technology = $username = $password =  "";

				// update button click start from here
				if(isset($_REQUEST['update'])) 
				{
					// firstname set or not start form here
					if (isset($_REQUEST["id"]) && !empty($_REQUEST["id"]))
					{
						$id =  $_REQUEST["id"];
					}
					// firstname set or not end here
					
			
					// firstname set or not start form here
					if (isset($_REQUEST["firstname"]) && !empty($_REQUEST["firstname"]))
					{
						$firstName =  addslashes($_REQUEST["firstname"]);
					}
					// firstname set or not end here
					
					
					// lastname set or not start form here
					if (isset($_REQUEST["lastname"]) && !empty($_REQUEST["lastname"]))
					{
					    	$lastName =  addslashes($_REQUEST["lastname"]);	    	
					}
					// lastname set or not end here
					

					// email set or not start form here
					if (isset($_REQUEST["email"]) && !empty($_REQUEST["email"]))
					{	
						$email =  $_REQUEST["email"];
					}
					// email set or not end here
					

					// country set or not start form here
					if (isset($_REQUEST["country"]) && !empty($_REQUEST["country"]))
					{
						$country = $_REQUEST["country"] ;
					}
					// country set or not end here
					
					
					// state set or not start form here
					if (isset($_REQUEST["state"]) && !empty($_REQUEST["state"]))
					{		
						$state =  $_REQUEST["state"] ;
					}
					// state set or not end here
					

					// city set or not start form here
					if (isset($_REQUEST["city"]) && !empty($_REQUEST["city"]))
					{	
						$city =  $_REQUEST["city"] ;
					}
					// city set or not end here
					
		
					// mobileno set or not start form here
					if (isset($_REQUEST["mobile"]) && !empty($_REQUEST["mobile"]))
					{
						$mobile =  $_REQUEST["mobile"] ;
					}
					// mobileno set or not end here
					
		
					// address set or not start form here
					if (isset($_REQUEST["address"]) && !empty($_REQUEST["address"]))
					{
						$address = $_REQUEST["address"] ;
					}
					// address set or not end here
					

					// gender set or not start form here
					if (isset($_REQUEST["gender_radio"]) && !empty($_REQUEST["gender_radio"]))
					{	
						$gender = $_REQUEST["gender_radio"] ;		
					}
					// gender set or not end here
					
					
					// department set or not start form here
					if (isset($_REQUEST["department_radio"]) && !empty($_REQUEST["department_radio"]))
					{
						$department = $_REQUEST["department_radio"] ;
					}
					// department set or not start form here
					
	
					// technology set or not start form here
					if (isset($_REQUEST["technology"]) && !empty($_REQUEST["technology"]))
					{	
						foreach( $_REQUEST["technology"] as $values )
						{
							$technology = $_REQUEST["technology"] ;
						}
					}
					

					// technology set or not end here
					
					// username set or not start form here
					if (isset($_REQUEST["username"]) && !empty($_REQUEST["username"]))
					{
						$username = $_REQUEST["username"] ;	
					}
					// username set or not end here
					
					// password set or not start form here
					if (isset($_REQUEST["password"]) && !empty($_REQUEST["password"]))
					{
						$password = $_REQUEST["password"] ;		
					}
					// password set or not end here
					
					
					// array convert into string start from here
					if( isset( $technology ) && !empty( $technology ) )
					{
						$technology = implode( "," , $technology );
					}
					// array convert into string end here


		// Update query for update data into database start from here
		$update = $connection->query("UPDATE user set id='".$id."',first_name='".$firstName."',last_name='".$lastName."',email='".$email."',country='".$country."',state='".$state."',city='".$city."',mobile='".$mobile."',address='".$address."',gender='".$gender."',  department='".$department."',technology='".$technology."',username='".$username."',password='".$password."' WHERE id='".$id."'");
		// Update query for update data into database end here
	
					// query execcute by if condition start from here
					if ( empty($connection->error) ) 
					{
					  echo "Data Update Successfully <br><br>";
					} 
					else 
					{
					  echo "<br> " . $connection->error . "<br><br>";
				          
					}
					// query execute by if condition end here
				}
				// update button click end here
		}
		// count total no of request for update data end here

		// fetch all data by select query start from here
		$result = $connection->query("SELECT * FROM user WHERE id='" . $_REQUEST['id'] . "'");
				if ( empty($connection->error) ) 
				{
				  $row= $result->fetch_array();
				} 
				else 
				{
				  echo "<br> " . $connection->error . "<br><br>";	
				  print_r($connection -> error_list);          
				}
		
?>

		<form name="display_form_data" method="post" action="">
				
		<table>	

			<tr>
				<td>	FirstName :-	 </td>
				<td>	<input type="text" name="firstname" id="firstname" placeholder="Enter FirstName" autofocus="autofocus"  value="<?php echo $row['first_name']; ?>">
				</td>		
		 	</tr>

			<tr>
				<td>	LastName :-	 </td>
				<td>	<input type="text" name="lastname" id="lastname" placeholder="Enter LastName" value="<?php echo $row['last_name']; ?>"> 
				</td>
		 	</tr>
		
			<tr>
				<td>	Email Id :- 	</td>
				<td>	
					<input type="text" name="email" id="email" placeholder="Enter Email" value="<?php echo $row['email']; ?>">	
				</td>			
			</tr>
			
			<tr>
				<td> Country :- </td>
				<td> 
					<select id="country" name="country">
						<option value=""> Select country </option>
					</select>
				</td>			
			</tr>
		
			<tr>
				<td> State :- </td>
				<td> 
					<select id="state" name="state">
						<option value=""> Select state </option>
					</select>
				</td>			
			</tr>

			<tr>
				<td> City :- </td>
				<td> 
					<select id="city" name="city">
						<option value="" selected="selected"> Select city </option>
					</select>
				</td>			
			</tr>

			<tr>
				<td>	Mobile No :-	</td>
				<td>	<input type="phone" id="mobile" placeholder="Enter Mobile No" maxlength="10" name="mobile" value="<?php echo $row['mobile']; ?>"> 	
				</td> 

			</tr>
		
			<tr>
				<td>	Address :- 	</td>
				<td>	<textarea name="address" id="address" rows="5" cols="30" name="address"> <?php echo $row['address']; ?>  </textarea>
				</td>
			</tr>
			
			

			<tr>
				<td>	Gender :- 	</td>
				<td>	<input type="radio" name="gender_radio" id="gender1" value="Male" <?php if($row['gender'] == 'male') { echo 'checked' ;} ?> > Male  
       			  	  	<input type="radio" name="gender_radio" id="gender2" value="Female"  <?php if($row['gender'] == 'female') { echo 'checked' ;} ?> > Female 
				  	<input type="radio" name="gender_radio" id="gender3" value="Others"  <?php if($row['gender'] == 'others') { echo 'checked' ;} ?> > Others  
				</td>

			</tr>


			<tr>
				<td>	Department :- 	</td>
				<td>	<input type="radio" name="department_radio" value="General"  <?php if($row['department'] == 'general') { echo 'checked' ;} ?> > General  
       			  	  	<input type="radio" name="department_radio" value="Marketing"  <?php if($row['department'] == 'marketing') { echo 'checked' ;} ?>> Marketing 
				 	<input type="radio" name="department_radio" value="Finance"  <?php if($row['department'] == 'finance') { echo 'checked' ;} ?> > Finance  
				</td>
			</tr>
				
			<tr>
				<td>	Technology :- 	</td>
				<td>	
					<?php $row['technology'] = explode(",",$row['technology']); ?>

					<input type="checkbox" name="technology[]" value="React"  <?php if(in_array("React", $row['technology'])) { echo 'checked' ;} ?> > React
					<input type="checkbox" name="technology[]" value="Node"  <?php if(in_array("Node", $row['technology'])) { echo 'checked' ;} ?> >Node
					<input type="checkbox" name="technology[]" value="PHP"   <?php if(in_array("PHP", $row['technology'])) { echo 'checked' ;} ?> > PHP  
				</td>

			</tr>

			<tr>
				<td>	Username :-	 </td>
				<td>	<input type="text" name="username" id="username" placeholder="Enter Username" value="<?php echo $row['username']; ?>"> 
				</td>
			</tr>

			
			<tr>
				<td>	Password :-	</td>
				<td>	<input type="password" id="password" placeholder="Enter Password" name="password" value="<?php echo $row['password']; ?>"> 	
				</td> 
			</tr>

			<tr>
				<td>	</td>
				<td> <input type="submit" name="update" value="Update"> </td>
			</tr>


		</table>
					
	</body>
</html> 

	
