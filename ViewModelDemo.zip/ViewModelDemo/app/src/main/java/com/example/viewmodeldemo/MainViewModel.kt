package com.example.viewmodeldemo


import androidx.lifecycle.ViewModel

class MainViewModel(var intitalValue : Int) : ViewModel() {
    var counter : Int = intitalValue
    fun  increment(){
        counter++

    }
}