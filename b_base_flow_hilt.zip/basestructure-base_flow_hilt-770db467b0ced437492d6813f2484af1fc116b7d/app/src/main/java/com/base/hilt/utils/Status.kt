package com.base.hilt.utils

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}