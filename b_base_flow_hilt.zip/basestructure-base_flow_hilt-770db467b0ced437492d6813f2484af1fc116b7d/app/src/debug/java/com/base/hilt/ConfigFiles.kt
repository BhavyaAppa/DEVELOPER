package com.base.hilt

object ConfigFiles {
    const val DEV_BASE_URL = "https://wellness.brainvire.dev/wellness-apis/public/front/api/"
    const val API_VERSION = "v1/"
}
