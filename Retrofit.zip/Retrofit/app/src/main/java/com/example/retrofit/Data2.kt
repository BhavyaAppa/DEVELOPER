package com.example.retrofit

data class Data2(
    val code: Int,
    val `data`: List<UserList>,
    val meta: Meta
)