package com.example.retrofit

data class Meta(
    val pagination: Pagination
)