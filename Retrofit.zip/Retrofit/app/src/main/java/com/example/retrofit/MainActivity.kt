package com.example.retrofit

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() , RecyclerviewAdapter.onItemClickListner{
    lateinit var recyclerviewAdapter: RecyclerviewAdapter
    lateinit var viewModel: MainActivityViewModel
    lateinit var createuser : Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        createuser = findViewById(R.id.createuser)
        initRecyclerview()
        initViewModel()
        searchUser()
        createuser.setOnClickListener {
            startActivity(Intent(this@MainActivity,CreateNewUserActivity::class.java))
        }
    }

    private fun  searchUser(){
        val serarchUser = findViewById<Button>(R.id.search)
        val searchEditText = findViewById<EditText>(R.id.searchtext)
        serarchUser.setOnClickListener {
            if(!TextUtils.isEmpty(searchEditText.text.toString())){
                viewModel.searchUser(searchEditText.text.toString())
            }
            else{
                viewModel.getUserList()
            }
        }
    }

    private fun initRecyclerview(){
        var recyclerView = findViewById<RecyclerView>(R.id.recyclerview)

        recyclerView.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            val decoration = DividerItemDecoration(this@MainActivity,DividerItemDecoration.VERTICAL)
            addItemDecoration(decoration)
            recyclerviewAdapter = RecyclerviewAdapter(this@MainActivity)
            adapter = recyclerviewAdapter
        }
    }
    @SuppressLint("NotifyDataSetChanged")
    fun initViewModel(){
      viewModel = ViewModelProvider(this).get(MainActivityViewModel::class.java)
      viewModel.getUserListObservable().observe(this, Observer<UserList>{
          if(it == null){
              Toast.makeText(this@MainActivity, "No Result Found", Toast.LENGTH_SHORT).show()
          }
          else{
              recyclerviewAdapter.userList = it.data.toMutableList()
              recyclerviewAdapter.notifyDataSetChanged()
          }
      })
    }

    override fun onItemEditClick(user: User) {
        val intent = Intent(this@MainActivity,CreateNewUserActivity::class.java)
        intent.putExtra("user_id",user.id)
        startActivityForResult(intent,1000)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if(requestCode == 1000) {
            viewModel.getUserList()
        }
        super.onActivityResult(requestCode, resultCode, data)

    }
}