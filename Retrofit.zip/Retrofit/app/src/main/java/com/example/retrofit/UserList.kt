package com.example.retrofit
data class UserList(
    val data: List<User>
)
data class User(
    val id: Int,
    val name: String,
    val email: String,
    val status: String,
    val gender: String
)
data class UserResponse(
    val code: Int,
    val meta: Meta,
    val data: User,
)