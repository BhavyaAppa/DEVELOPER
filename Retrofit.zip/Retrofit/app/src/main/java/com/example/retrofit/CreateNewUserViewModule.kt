package com.example.retrofit

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CreateNewUserViewModule : ViewModel() {

   lateinit var createNewUserLiveData : MutableLiveData<UserResponse?>
    lateinit var loadUserData : MutableLiveData<UserResponse?>

   init {
       createNewUserLiveData = MutableLiveData()
       loadUserData = MutableLiveData()
   }

    fun getUserListObservable() : MutableLiveData<UserResponse?>
    {
        return createNewUserLiveData
    }
    fun getLoadUserObservable() : MutableLiveData<UserResponse?> {
        return loadUserData
    }
    fun createUser(user: User){
        val  retrofitInstance = RetrofitInstance.getRetrofitInstance().create(RetroService::class.java)
        val call = retrofitInstance.createUser(user)
        call.enqueue(object : Callback<UserResponse>{

            override fun onFailure(call: Call<UserResponse?>, t: Throwable) {
               createNewUserLiveData.postValue(null)
            }

            override fun onResponse(call: Call<UserResponse>, response: Response<UserResponse>) {
                if(response.isSuccessful)
                {
                    createNewUserLiveData.postValue(response.body())
                }
                else{
                    createNewUserLiveData.postValue(null)
                }
            }
        })
    }
}

fun getUserData(user_id: String?){
    val  retrofitInstance = RetrofitInstance.getRetrofitInstance().create(RetroService::class.java)
    val call = retrofitInstance.createUser(user_id!!)
    call.enqueue(object : Callback<UserResponse>{

        override fun onFailure(call: Call<UserResponse?>, t: Throwable) {
            loadUserData.postValue(null)
        }

        override fun onResponse(call: Call<UserResponse>, response: Response<UserResponse>) {
            if(response.isSuccessful)
            {
                loadUserData.postValue(response.body())
            }
            else{
                createNewUserLiveData.postValue(null)
            }
        }
    })
}