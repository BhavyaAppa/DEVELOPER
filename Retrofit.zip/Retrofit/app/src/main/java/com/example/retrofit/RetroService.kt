package com.example.retrofit

import android.widget.EditText
import retrofit2.Call
import retrofit2.http.*

// b2fb443069418e95787006188661c58934c31132b5080f51a9ff9138971dee0a
interface RetroService {

    // https://gorest.co.in/public-api/users
    @GET("users")
    @Headers("Accept:application/json","Content-Type:application/json")
    fun getHtttpList() : Call<UserList>

    // https://gorest.co.in/public-api/users?name=a
    @GET("users")
    @Headers("Accept:application/json","Content-Type:application/json")
    fun searchUsers(@Query("name") searchText : String) : Call<UserList>

   //  https://gorest.co.in/public-api/users/121
    @GET("users/{user_id}")
    @Headers("Accept:application/json","Content-Type:application/json")
    fun getUser(@Path("user_id") user_id : String) : Call<UserList>

    @POST("users")
    @Headers( "Accept:application/json","Content-Type:application/json"
        ,"Authorization: Bearer b2fb443069418e95787006188661c58934c31132b5080f51a9ff9138971dee0a")
    fun createUser(@Body param: User) : Call<UserResponse>

    @PATCH("users/{user_id}")
    @Headers("Accept:application/json","Content-Type:application/json")
    fun updateUser(@Path("user_id") user_id : String,@Body param: User) : Call<UserList>

    @DELETE("users/{user_id}")
    @Headers("Accept:application/json","Content-Type:application/json")
    fun deleteUser(@Path("user_id") user_id : String) : Call<UserList>
}