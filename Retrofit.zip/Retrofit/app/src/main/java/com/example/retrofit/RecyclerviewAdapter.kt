package com.example.retrofit

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RecyclerviewAdapter(val clickListner: onItemClickListner) : RecyclerView.Adapter<RecyclerviewAdapter.MyViewHolder>() {
    var userList = mutableListOf<User>()
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerviewAdapter.MyViewHolder {
       val v = LayoutInflater.from(parent.context).inflate(R.layout.recular_row_list,parent,false)
        return MyViewHolder(v)
    }

    override fun onBindViewHolder(holder: RecyclerviewAdapter.MyViewHolder, position: Int) {
        holder.bind(userList[position])
        holder.itemView.setOnClickListener{
            clickListner.onItemEditClick(userList[position])
        }

    }

    override fun getItemCount(): Int {
        return userList.size
    }

    class MyViewHolder(itemView : View) : RecyclerView.ViewHolder(itemView) {

        val textviewname = itemView.findViewById<TextView>(R.id.textviewname)
        val textviewemail = itemView.findViewById<TextView>(R.id.textviewemail)
        val textviewstats = itemView.findViewById<TextView>(R.id.textviewstats)

        fun bind(data : User){
            textviewname.text = data.name
            textviewemail.text = data.email
            textviewstats.text = data.status
        }
    }

    interface onItemClickListner{
        fun onItemEditClick(user: User)
    }
}