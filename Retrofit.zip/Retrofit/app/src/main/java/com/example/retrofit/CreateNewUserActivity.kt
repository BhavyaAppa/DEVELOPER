package com.example.retrofit

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View.GONE
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider

class CreateNewUserActivity : AppCompatActivity() {
    lateinit var viewModel : CreateNewUserViewModule
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_new_user)
        val createbutton = findViewById<Button>(R.id.createbutton)
        val user_id = intent.getStringArrayExtra("user_id")
        initModel()
        createUserObeservable()

        if(user_id != null){
            onLoadUserData(user_id)
        }
        createbutton.setOnClickListener {
            createUser()
        }
    }

    private fun onLoadUserData(use_id: String?){
        val editText  : EditText
        val editEmail  : EditText
        val createButton : Button
        val deleteButton : Button

        editText = findViewById(R.id.editname)
        editEmail = findViewById(R.id.editemail)
        createButton = findViewById<Button>(R.id.createbutton)
        deleteButton = findViewById<Button>(R.id.deletebutton)
        viewModel.getLoadUserObservable().observe(this, Observer {
            if(it != null)
            {
                editText.setText(it.data.name)
                editEmail.setText(it.data.email)
                createButton.setText("Update")
                deleteButton.visibility = GONE
            }
            else{
                Toast.makeText(this@CreateNewUserActivity, "Succesfully Created  New User  ", Toast.LENGTH_SHORT).show()
                finish()
            }
        })
        viewModel.getUserData(use_id)
    }

    private fun createUser(use_id : String) {
        val editName = findViewById<EditText>(R.id.editname)
        val editeEmail= findViewById<EditText>(R.id.editemail)
        val user = User(1,editName.text.toString(),editeEmail.text.toString(),"Active","Male")

        if(use_id == null) {
            viewModel.createUser(user)
        }
        else{

        }
    }

    private fun initModel() {

        viewModel = ViewModelProvider(this).get(CreateNewUserViewModule::class.java)
    }
    private fun createUserObeservable(){
        viewModel.getUserListObservable().observe(this, Observer {
            if(it == null)
            {
                Toast.makeText(this@CreateNewUserActivity, "Failed To Create New User  ", Toast.LENGTH_SHORT).show()
            }
            else{
                Toast.makeText(this@CreateNewUserActivity, "Succesfully Created  New User  ", Toast.LENGTH_SHORT).show()
                finish()
            }
        })
    }
}