package com.example.mvvmroom

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.mvvmroom.data.Note

class NotesAdapter(private val arrayList: ArrayList<Note>
                    ,var deleteItemClickInterface : DeleteClickInterface
                    ,var updateItemClickinterface : updateClickInterface)
                    : RecyclerView.Adapter<NotesAdapter.ViewHolder>(){

    interface DeleteClickInterface{
        fun onItemClick(note: Note)
    }

    interface updateClickInterface{
        fun onItemClick2(note: Note)
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
       val view = LayoutInflater.from(parent.context).inflate(R.layout.list_item,parent,false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val currentItem = arrayList[position]
        holder.iddetails.text = currentItem.id.toString()
        holder.title.text = currentItem.title
        holder.discription.text = currentItem.discription
        holder.priority.text = currentItem.priority
        holder.delete.setOnClickListener {
            deleteItemClickInterface.onItemClick(arrayList[position])
        }
        holder.update.setOnClickListener {
            updateItemClickinterface.onItemClick2(arrayList[position])
        }
    }

    override fun getItemCount(): Int {
        return arrayList.size
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var iddetails = itemView.findViewById<TextView>(R.id.iddetails)
        val title = itemView.findViewById<TextView>(R.id.title)
        val discription = itemView.findViewById<TextView>(R.id.discription)
        val priority = itemView.findViewById<TextView>(R.id.priority)
        val update = itemView.findViewById<ImageView>(R.id.update)
        val delete = itemView.findViewById<ImageView>(R.id.delete)
    }

}