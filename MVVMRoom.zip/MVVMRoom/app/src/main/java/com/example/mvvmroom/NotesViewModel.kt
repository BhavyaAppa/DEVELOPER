package com.example.mvvmroom

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mvvmroom.data.Note
import com.example.mvvmroom.data.NoteDao
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class NotesViewModel(
    private val repository: NotesRepository
) : ViewModel() {

    val searchObj = MutableLiveData<String>()
  //  val liveObj : LiveData<String> get() = searchObj

    fun setData(p0 : String) {
        searchObj.value = p0
    }

    fun getData() : String{
        return searchObj.toString()
    }

    fun getAllObserveData() {
        fun searchNote(search_query : String) = repository.searchNote(search_query)
        getData()
    }

    val getSearchData : LiveData<String> get() = searchObj

    suspend fun insertNote(note: Note) = repository.insertNote(note)

    suspend fun updateNote(note: Note) = repository.updateNote(note)

    suspend fun deleteNote(note: Note) = repository.deleteNote(note)

    fun getAllNotes() = repository.getAllNotes()

    fun searchNote(search_query : String) = repository.searchNote(search_query)

//    suspend fun deleteNotesById(id : Int) = repository.deleteNotesById(id)

}