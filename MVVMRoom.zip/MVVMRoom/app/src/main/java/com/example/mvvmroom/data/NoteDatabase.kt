package com.example.mvvmroom.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Note::class],
    version = 2)

abstract class NoteDatabase : RoomDatabase(){
    abstract fun getNoteDao() : NoteDao

    companion object {
        @Volatile
        private var Instance: NoteDatabase? = null

        fun getDatabase(context: Context): NoteDatabase {
            if (Instance == null) {
                synchronized(this){
                    Instance = Room
                        .databaseBuilder(context.applicationContext
                            ,NoteDatabase::class.java, "contactDB")
                        .fallbackToDestructiveMigration()
                        .build()
                }
            }
            return Instance!!
        }
    }
}