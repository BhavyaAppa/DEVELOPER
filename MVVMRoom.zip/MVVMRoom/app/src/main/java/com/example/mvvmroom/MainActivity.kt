package com.example.mvvmroom

import android.annotation.SuppressLint
import android.app.Dialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.widget.TextView
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.mvvmroom.data.Note
import com.example.mvvmroom.data.NoteDatabase
import com.example.mvvmroom.databinding.ActivityMainBinding
import com.example.mvvmroom.databinding.UpdateAlertDialogBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity(), NotesAdapter.updateClickInterface,
    NotesAdapter.DeleteClickInterface {
    private lateinit var database: NoteDatabase
    private lateinit var factory: NotesViewModelFactory
    private lateinit var repository: NotesRepository
    private lateinit var viewModel: NotesViewModel
    private lateinit var binding: ActivityMainBinding
    private var arrayList: ArrayList<Note> = arrayListOf()
    private lateinit var adapter: NotesAdapter

   // private var recyclerView: RecyclerView = binding.recyclerview

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        database = NoteDatabase.getDatabase(this)
        repository = NotesRepository(database)
        factory = NotesViewModelFactory(repository)
        viewModel = ViewModelProvider(this, factory).get(NotesViewModel::class.java)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        lateinit var x : String
            viewModel.getSearchData.observe(this@MainActivity, Observer {
                binding.dummy1.text = it
                binding.dummy2.text = it
            })

        insertNotes()

        binding.title.addTextChangedListener(textWatcher)

        val recyclerView : RecyclerView = binding.recyclerview
        viewModel.getSearchData.observe(this@MainActivity, Observer {
            Log.e("RRRRRRR", it)

            viewModel.searchNote(it).observe(this@MainActivity, Observer {
                //     Log.e("search", it.toString())
                arrayList.clear()
                arrayList.addAll(it)
                recyclerView.layoutManager = LinearLayoutManager(applicationContext)
                adapter = NotesAdapter(arrayList,this@MainActivity,this@MainActivity)
                recyclerView.adapter = adapter
            })
        })

//        viewModel.searchNote("").observe(this@MainActivity, Observer {
//            //     Log.e("search", it.toString())
//            arrayList.clear()
//            arrayList.addAll(it)
//            recyclerView.layoutManager = LinearLayoutManager(applicationContext)
//            adapter = NotesAdapter(arrayList,this@MainActivity,this@MainActivity)
//            recyclerView.adapter = adapter
//        })
    }

    private val textWatcher = object : TextWatcher{
        override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
         //   Log.e("before","$p0")
        }

        override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
         //   Log.e("textchange","$p0")
            viewModel.setData(p0.toString())

        }
        override fun afterTextChanged(p0: Editable?) {
          //  Log.e("After","$p0")
        }
    }

    private fun insertNotes() {
        val btnInsert = binding.insert
        btnInsert.setOnClickListener {
            val title = binding.title.text
            val discription = binding.discription.text
            val priority = binding.priority.text
            if (title!!.isNotEmpty() && discription!!.isNotEmpty() && priority!!.isNotEmpty()) {
                lifecycleScope.launch(Dispatchers.IO) {
                    viewModel.insertNote(
                        Note(
                            title = "$title",
                            discription = "$discription",
                            priority = "$priority"
                        )
                    )
                }
            }
        }
        getAllNotes()
    }

    private fun getAllNotes() {
        val recyclerView : RecyclerView = binding.recyclerview
        viewModel.getAllNotes().observe(this@MainActivity, Observer {
            //   Log.e("Bhavya", it.toString())
            arrayList.clear()
            arrayList.addAll(it)
            recyclerView.layoutManager = LinearLayoutManager(this)
            adapter = NotesAdapter(arrayList, this, this)
            recyclerView.adapter = adapter
        })
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onItemClick(note: Note) {
        lifecycleScope.launch {
            viewModel.deleteNote(note)
            adapter.notifyDataSetChanged()
            Toast.makeText(applicationContext, "Item Delete Successfully", Toast.LENGTH_SHORT)
                .show()
        }
    }

    override fun onItemClick2(note: Note) {
            val dialog = Dialog(this)
            val binding2: UpdateAlertDialogBinding =
                UpdateAlertDialogBinding.inflate(LayoutInflater.from(this))
            dialog.setContentView(binding2.root)

            binding2.ok.setOnClickListener {
                val titledialog = binding2.titledialog.text.toString()
                val discriptiondialog = binding2.discriptiondialog.text.toString()
                val prioritydialog = binding2.prioritydialog.text.toString()
                Log.d("title", titledialog)
                if (titledialog.isNotEmpty() && discriptiondialog.isNotEmpty() && prioritydialog.isNotEmpty()) {
                    lifecycleScope.launch(Dispatchers.IO) {
                        viewModel.updateNote(
                            Note(
                                id = note.id,
                                title = titledialog,
                                discription = discriptiondialog,
                                priority = prioritydialog
                            )
                        )
                        withContext(Dispatchers.Main) {
                            Toast.makeText(
                                this@MainActivity,
                                "Item Update Successfully",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                        dialog.dismiss()
//                    adapter.notifyDataSetChanged()
                    }
                } else {
                    Toast.makeText(this, "Please Enter All Fields", Toast.LENGTH_SHORT).show()
                }
            }
            binding2.cancel.setOnClickListener {
                dialog.dismiss()
            }
            dialog.create()
            dialog.show()
        }

}