package com.example.mvvmroom.data

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface NoteDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: Note)

    @Update
    suspend fun updateDao(note: Note)

    @Delete
    suspend fun deleteDao(note: Note)

    @Query("SELECT * FROM notes ORDER BY priority DESC")
    fun getAllNotes() : LiveData<List<Note>>

    @Query("SELECT * FROM notes WHERE title LIKE '%' || :search_query || '%' ")
    fun searchNotes(search_query : String) : LiveData<List<Note>>

//    @Query("DELETE FROM notes WHERE id = id")
//    suspend fun deleteNotesById(id : Int)
}