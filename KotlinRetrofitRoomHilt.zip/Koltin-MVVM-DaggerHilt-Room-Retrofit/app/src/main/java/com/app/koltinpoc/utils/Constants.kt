package com.app.koltinpoc.utils

object Constants {

    val API_KEY = "f9b76813141b49d8831a879d6f2fa7c5" //GET YOUR API KEY BY SIGNING to https://newsapi.org
    val BASE_URL = "https://newsapi.org/"
    val COUNTRY_CODE = "in"

}