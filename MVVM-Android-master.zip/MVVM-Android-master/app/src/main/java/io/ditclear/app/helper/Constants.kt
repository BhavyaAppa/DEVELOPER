package io.ditclear.app.helper

/**
 * 页面描述：Constants
 *
 * Created by ditclear on 2017/11/19.
 */
object Constants {

    const val HOST_API="http://api.jcodecraeer.com/"

    const val HOST_PAO="http://jcodecraeer.com"
}