# To-Do App Developed in Kotlin for the purpose of an online course

Course Links 

Udemy: https://www.udemy.com/course/to-do-app-clean-architecture-android-development-kotlin/?referralCode=9836891EDBD1479ECF50

![alt text](https://i.postimg.cc/SsqJrbjX/thumb.png)
