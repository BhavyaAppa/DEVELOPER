package com.example.todoapp.data.models

enum class Priority {
    HIGH,
    MEDIUM,
    LOW
}