package com.example.recyclerviewcrud

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ExampleAdapter(private val exampleList: List<ExampleItem>,private val listner: OnItemClickListner) : RecyclerView.Adapter<ExampleAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.example_item,parent,false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val currentItem = exampleList[position]
       holder.imageView.setImageResource(currentItem.imageview)
       holder.texView1.text = currentItem.textview1
       holder.texView2.text = currentItem.textview2
    }

    override fun getItemCount(): Int {
        return exampleList.size
    }

   inner class ViewHolder(itemView : View) : RecyclerView.ViewHolder(itemView),View.OnClickListener {
        val imageView : ImageView = itemView.findViewById(R.id.imageview)
        val  texView1 : TextView = itemView.findViewById(R.id.textview1)
        val  texView2 : TextView = itemView.findViewById(R.id.textview2)

        init {
            itemView.setOnClickListener(this)
        }

        // implement by inherit View.OnclickListner
        override fun onClick(p0: View?) {
            val position = adapterPosition
            if(position != RecyclerView.NO_POSITION) {
                listner.onItemClick(position)
            }
        }
    }
        interface OnItemClickListner{
            fun onItemClick(position: Int)
        }
}