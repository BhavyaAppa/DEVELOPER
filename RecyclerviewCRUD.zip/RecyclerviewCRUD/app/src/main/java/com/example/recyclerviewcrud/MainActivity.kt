package com.example.recyclerviewcrud

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.Adapter
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.nio.file.Files.size
import kotlin.random.Random

class MainActivity : AppCompatActivity() , ExampleAdapter.OnItemClickListner{

    private lateinit var button1 : Button
    private lateinit var button2 : Button
//    private lateinit var exampleList : ArrayList<ExampleItem
    private val exampleList : ArrayList<ExampleItem> = generateDummyList(20)
    private val adapter =  ExampleAdapter(exampleList,this)
    private val exampleList2 : ArrayList<ExampleItem> = arrayListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val  recyclerView : RecyclerView = findViewById(R.id.recyclerview)
        button1 = findViewById(R.id.button1)
        button2 = findViewById(R.id.button2)

        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.setHasFixedSize(true)

        button1.setOnClickListener{
            insertItem()

        }
        button2.setOnClickListener {
            removeItem()
        }
    }

    fun insertItem(){
        var index : Int = Random.nextInt(5)
        var newItem = ExampleItem(R.drawable.ic_android_black_24dp,
            "New Item at $index","Line2")
        exampleList.add(index,newItem)
        adapter.notifyItemInserted(index)
    }

    fun removeItem(){
        var index = Random.nextInt(5)
        exampleList.removeAt(index)
        adapter.notifyItemRemoved(index)
    }


    private fun addInfo(x : String, y : String,p: Int) {
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_listiitem,null)
        var text1 = v.findViewById<EditText>(R.id.alerttext1)
        var text2 = v.findViewById<EditText>(R.id.alerttext2)
        // get data  in alertbox
        text1.setText(x)
        text2.setText(y)
        val addDialog = AlertDialog.Builder(this)
        addDialog.setView(v)
        addDialog.setPositiveButton("OK"){
                dialog,_->
            var t1 = text1.text.toString()
            var t2 = text2.text.toString()
            var t3 = t1 + t2
            exampleList.add(ExampleItem(R.drawable.ic_android_black_24dp, t1, t2))
            adapter.notifyItemInserted(exampleList.size - 1)
            adapter.notifyDataSetChanged()
            return@setPositiveButton
        }
        addDialog.setNegativeButton("Cancel"){
                dialog,_->
            dialog.dismiss()
            Toast.makeText(this, "Cancel", Toast.LENGTH_SHORT).show()
        }
        addDialog.create()
        addDialog.show()
    }

    private fun generateDummyList(size : Int) : ArrayList<ExampleItem>
    {
        val  list = ArrayList<ExampleItem>()
        for(i in 0 until size)
        {
            var drawable = when(i % 3){
                0 -> R.drawable.ic_android_black_24dp
                1 -> R.drawable.ic_baseline_audiotrack_24
                else -> R.drawable.ic_baseline_settings_24
            }
            val item = ExampleItem(drawable,"Item $i","List2")
            list += item
        }
        return list
    }

    override fun onItemClick(position: Int) {
        Toast.makeText(this, "Item $position Clicked", Toast.LENGTH_SHORT).show()
        val clickedItem = exampleList[position]
        var x = clickedItem.textview1
        var y = clickedItem.textview2
        addInfo(x,y,position)

        clickedItem.textview1 = "Clicked"
        adapter.notifyItemChanged(position)
    }
}
