package com.example.recyclerviewcrud

data class ExampleItem(val imageview : Int,var textview1 : String,var  textview2 : String)
