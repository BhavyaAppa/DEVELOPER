package com.example.rxjavademo.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.rxjavademo.network.BookListModel
import com.example.rxjavademo.network.RetroService
import com.example.rxjavademo.network.RetrofitInstance
import io.reactivex.Observer
import io.reactivex.Scheduler
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import retrofit2.Retrofit

class MainActivityViewModel : ViewModel() {

   lateinit var bookList: MutableLiveData<BookListModel>

    init {
        bookList = MutableLiveData()
    }

    fun bookListObserver() : MutableLiveData<BookListModel>{
        return bookList
    }

    fun makeApiCall(query:  String){

       val retroInstance =  RetrofitInstance.getRetrofitInstance().create(RetroService::class.java)
        Log.d("VIEWMODEL","$retroInstance")

        retroInstance.getBookList(query)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(bookListObserverRxjava())
    }

    private fun bookListObserverRxjava() : Observer<BookListModel> {
        return object : Observer<BookListModel>{
            override fun onSubscribe(d: Disposable) {
                // Hide Progress Indicator
            }

            override fun onNext(t: BookListModel) {
                Log.d("VIEWMODEL","$t")
                bookList.postValue(t)
            }

            override fun onError(e: Throwable) {
                bookList.postValue(null)
            }

            override fun onComplete() {
                // Start Showing Progress Indicator
            }

        }

    }
}