package com.example.rxjavademo

import android.graphics.drawable.ClipDrawable.VERTICAL
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.rxjavademo.adapter.BookListAdapter
import com.example.rxjavademo.databinding.ActivityMainBinding
import com.example.rxjavademo.databinding.ListItemBinding
import com.example.rxjavademo.network.BookListModel
import com.example.rxjavademo.network.VolumeInfo
import com.example.rxjavademo.viewmodel.MainActivityViewModel

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    lateinit var viewModel: MainActivityViewModel

      var bookListAdapter: BookListAdapter = BookListAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initSearchBox()
        initRecyclerView()
    }

    private fun initRecyclerView() {
       /* binding.recyclerview.layoutManager = LinearLayoutManager(applicationContext, VERTICAL,false)
        binding.recyclerview.adapter = bookListAdapter*/

        binding.recyclerview.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = bookListAdapter
        }
    }

    fun initSearchBox() {
        binding.edTxtBookName.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                loadApiData(p0.toString())
            }

            override fun afterTextChanged(p0: Editable?) {

            }
        })
    }

    fun loadApiData(input : String) {
        viewModel = ViewModelProvider(this).get(MainActivityViewModel::class.java)
        viewModel.bookListObserver().observe(this, Observer<BookListModel> {
            if (it != null) {
                Log.d("Response", "$it")
                bookListAdapter.bookListData = it.items
                bookListAdapter.notifyDataSetChanged()

            } else {
                Log.d("Error", "Error")
            }
        })

        viewModel.makeApiCall(input)
    }
}