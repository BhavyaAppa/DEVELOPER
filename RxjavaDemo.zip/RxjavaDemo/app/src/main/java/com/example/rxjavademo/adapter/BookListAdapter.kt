package com.example.rxjavademo.adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.rxjavademo.R
import com.example.rxjavademo.databinding.ListItemBinding
import com.example.rxjavademo.network.VolumeInfo


class BookListAdapter() : RecyclerView.Adapter<BookListAdapter.MyViewHolder>() {

    private lateinit var listItemBinding: ListItemBinding

    var bookListData = ArrayList<VolumeInfo>()


    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BookListAdapter.MyViewHolder {
        val binding = ListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return BookListAdapter.MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: BookListAdapter.MyViewHolder, position: Int) {
        val largeNews = bookListData[position]
        holder.bind(largeNews,holder)
    }

    override fun getItemCount(): Int = bookListData.size

    class MyViewHolder(binding: ListItemBinding) : RecyclerView.ViewHolder(binding.root) {
        val titleBook = binding.txtViewBookTitle
        val publisherBook = binding.txtViewBookPublisher
        val dicriptionBook = binding.txtViewBookDiscription
        val thumbImageBook = binding.imgViewBook

        fun bind(data: VolumeInfo,holder: MyViewHolder) {
            if (titleBook.text == null) {
                titleBook.setText("--")
            } else if (publisherBook.text == null) {
                publisherBook.setText("--")
            } else if (publisherBook.text == null) {
                dicriptionBook.setText("--")
            }

            titleBook.setText(data.volumeInfo.title)
            publisherBook.setText(data.volumeInfo.publisher)
            dicriptionBook.setText(data.volumeInfo.discription)

            val url = data?.volumeInfo?.imageLinks?.smallThumbnail

            if (url != null) {
                Log.d("URLIMG","$url")
                Glide.with(holder.itemView.context)
                    .load(url)
                    .apply(RequestOptions())
                    .into(thumbImageBook)
            }
        }
    }
}




