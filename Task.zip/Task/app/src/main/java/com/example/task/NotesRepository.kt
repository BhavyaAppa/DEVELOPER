package com.example.task

import androidx.lifecycle.LiveData
import com.example.task.Note
import com.example.task.NoteDatabase

class NotesRepository(private val database: NoteDatabase) {


    suspend fun insertNote(note: Note){
        return database.getNoteDao().insertNote(note)
    }

    suspend fun updateNote(note: Note){
        return database.getNoteDao().updateDao(note)
    }

    suspend fun deleteNote(note: Note){
        return database.getNoteDao().deleteDao(note)
    }

    fun getAllNotes() : LiveData<List<Note>> {
        return database.getNoteDao().getAllNotes()
    }

     fun searchNote(search_query : String) : LiveData<List<Note>>{
        return database.getNoteDao().searchNotes(search_query)
    }

//    suspend fun deleteNotesById(id : Int){
//        return database.getNoteDao().deleteNotesById(id)
//    }
}