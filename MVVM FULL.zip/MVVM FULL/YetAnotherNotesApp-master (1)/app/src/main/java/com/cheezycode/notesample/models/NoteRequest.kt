package com.cheezycode.notesample.models

data class NoteRequest(
    val title: String,
    val description: String
)