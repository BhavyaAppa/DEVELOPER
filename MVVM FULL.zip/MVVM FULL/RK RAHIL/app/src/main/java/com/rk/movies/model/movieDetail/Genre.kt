package com.rk.movies.model.movieDetail

data class Genre(
    val id: Int,
    val name: String
)