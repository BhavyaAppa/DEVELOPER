package com.example.recylerviewwithcheckbox

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.text.FieldPosition

class MainActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var arrayList: ArrayList<Language>
    private lateinit var addButton : FloatingActionButton
    private lateinit var adapter: MyAdapter
    private lateinit var buttonPosition: Button
    lateinit var heading : Array<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        heading = arrayOf(
            "data1 for babaji babaji babaji ",
            "data2 for trophy",
            "data3 for home home home",
            "data4 for heart",
            "data5 for setting",
            "data1 for babaji babaji babaji ",
            "data2 for trophy",
            "data3 for home home home",
            "data4 for heart",
            "data5 for setting",
            "data1 for babaji babaji babaji ",
            "data2 for trophy",
            "data3 for home home home",
            "data4 for heart",
            "data5 for setting",
            "data1 for babaji babaji babaji ",
            "data2 for trophy",
            "data3 for home home home",
            "data4 for heart",
            "data5 for setting",
            "data1 for babaji babaji babaji ",
            "data2 for trophy",
            "data3 for home home home",
            "data4 for heart",
            "data5 for setting",
            "data1 for babaji babaji babaji ",
            "data2 for trophy",
            "data3 for home home home",
            "data4 for heart",
            "data5 for setting"
        )



        recyclerView = findViewById(R.id.recyclerview)
        recyclerView.layoutManager = LinearLayoutManager(this)

        arrayList = arrayListOf()
        getUserData()

        addButton = findViewById<FloatingActionButton>(R.id.floatingButton)
        addButton.setOnClickListener{
            addInfo()
        }
     }

    // Add new item when click on floating button
    private fun addInfo() {
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_listitem,null)
        var userName = v.findViewById<EditText>(R.id.alerttext)
        val addDialog = AlertDialog.Builder(this)
        addDialog.setView(v)
        addDialog.setPositiveButton("OK"){
            dialog,_->
            var name = userName.text.toString()
            arrayList.add(Language("$name",false,false))
            adapter.notifyItemInserted(arrayList.size - 1);
            recyclerView.scrollToPosition(arrayList.size - 1);
            adapter.notifyDataSetChanged()

            Toast.makeText(this, "Adding Items", Toast.LENGTH_SHORT).show()
        }
        addDialog.setNegativeButton("Cancel"){
            dialog,_->
            dialog.dismiss()
            Toast.makeText(this, "Cancel", Toast.LENGTH_SHORT).show()
        }
        addDialog.create()
        addDialog.show()
    }

    private fun getUserData()
    {
        for(i in heading.indices)
        {
            val language  = Language(heading[i],false,false)
            arrayList.add(language)
        }

        adapter  = MyAdapter(arrayList)
       recyclerView.adapter = adapter
        adapter.setOnItemClickListner(object : MyAdapter.onItemClickListner{
            override fun onItemClick(position: Int) {
           //     Toast.makeText(this@MainActivity, "You click on ${position+1}", Toast.LENGTH_SHORT).show()
            }
        })
    }



}