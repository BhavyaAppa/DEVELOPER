package com.example.recylerviewwithcheckbox

data class LanguageList(var childTextView : String)
