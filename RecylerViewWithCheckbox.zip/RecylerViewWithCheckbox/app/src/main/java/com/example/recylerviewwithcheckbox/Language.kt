package com.example.recylerviewwithcheckbox

import android.text.BoringLayout
import android.widget.CheckBox

data class Language(var heading : String,var isChecked : Boolean,var parentCheckBox: Boolean)
