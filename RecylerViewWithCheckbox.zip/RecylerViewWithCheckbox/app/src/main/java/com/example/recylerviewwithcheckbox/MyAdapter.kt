package com.example.recylerviewwithcheckbox

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import kotlin.collections.ArrayList

class MyAdapter(private val languageList: ArrayList<Language>) :
    RecyclerView.Adapter<MyAdapter.MyViewHolder>() {
    private lateinit var recyclerView2 : RecyclerView
    private lateinit var mListner: onItemClickListner
    private var arrayList2 : ArrayList<LanguageList> = arrayListOf()
    private var visiblePosition = -1
    private var x  : Boolean = false
    private lateinit var parentCheckBox: CheckBox

    interface onItemClickListner{
        fun onItemClick(position: Int)
    }

    fun setOnItemClickListner(listner: onItemClickListner)
    {
        mListner = listner
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {

        var itemView =
            LayoutInflater.from(parent.context).inflate(R.layout.list_item, parent, false)
        return MyViewHolder(itemView,mListner)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
       // Toast.makeText(holder.itemView.context, "", Toast.LENGTH_SHORT).show()
        var currentItem = languageList[position]

        var position : Int = position
        var childViewVisible : Boolean = false
        holder.heading.text = currentItem.heading
        //Log.e("Item","$currentItem")

        arrayList2.clear()

      //  Toast.makeText(holder.itemView.context, "hoiiii $position", Toast.LENGTH_SHORT).show()
        arrayList2.add(LanguageList("Bhavya"))
        arrayList2.add(LanguageList("Bhavya"))
        arrayList2.add(LanguageList("Bhavya"))
       // Log.e("tag",arrayList2.size.toString())

       // holder.recyclerView2.adapter = ChildAdapter(arrayList2,position,holder.parentCheckBox.isChecked)
        Log.e("call function" ,"${holder.parentCheckBox.isChecked}")

        // visible and not visible current item
        if(languageList[position].isChecked)
        {
          //  Log.e("tag","visible")
            holder.recyclerView2.visibility = View.VISIBLE
        }
        else
        {
          //  Log.e("tag","Gone")
            holder.recyclerView2.visibility = View.GONE
        }

        holder.itemView.setOnClickListener {
            var x = holder.parentCheckBox.isChecked
            holder.recyclerView2.adapter = ChildAdapter(arrayList2,position,x)
        //     Toast.makeText(holder.itemView.context, "Parent Click {$position+1}", Toast.LENGTH_SHORT).show()
            Log.e("position",position.toString())
            Log.e("VisiblePosition",visiblePosition.toString())
            Log.e("click function" ,"${holder.parentCheckBox.isChecked}")

            if(holder.parentCheckBox.isChecked == true){
                Toast.makeText(holder.itemView.context, "${position+1}", Toast.LENGTH_SHORT).show()
            }

               Log.e("loanguagelist position",languageList[position].toString())

            // condition for when  click other previous  is invisible
            if (visiblePosition != -1) {
                if(visiblePosition == position)
                {
                    languageList[visiblePosition].isChecked = false
                    notifyItemChanged(visiblePosition)
                    visiblePosition = -1
                }
                else
                {
                    languageList[visiblePosition].isChecked = false
                    notifyItemChanged(visiblePosition)
                    visiblePosition = position
                    languageList[visiblePosition].isChecked = true
                    notifyItemChanged(visiblePosition)
            //        Log.e("Tag", currentItem.isChecked.toString())
                }
            }
            else  {
                visiblePosition = position
                languageList[visiblePosition].isChecked = true
                notifyItemChanged(visiblePosition)
            }



            // visible and not visible current item
            if(holder.recyclerView2.visibility == View.GONE) {
                holder.recyclerView2.visibility = View.VISIBLE
            }
            else
            {
                holder.recyclerView2.visibility = View.GONE
            }
        }
    }

    // recycvlerview view not change when scrolldown and scrollup
    override fun getItemViewType(position: Int): Int {
        return position
    }

    override fun getItemCount(): Int {
        return languageList.size
    }

    class MyViewHolder(itemView: View, listner: onItemClickListner) : RecyclerView.ViewHolder(itemView) {
        val heading = itemView.findViewById<TextView>(R.id.heading)
        var recyclerView2 : RecyclerView = itemView.findViewById(R.id.recyclerview2)
        var parentCheckBox : CheckBox = itemView.findViewById(R.id.parentCheckbox)

//        init {
//            itemView.setOnClickListener{
//                listner.onItemClick(adapterPosition)
//                recyclerView2.visibility = View.VISIBLE
//            }
//        }
        }
    }
