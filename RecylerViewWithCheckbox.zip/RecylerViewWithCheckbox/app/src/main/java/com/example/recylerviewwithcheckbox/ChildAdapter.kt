package com.example.recylerviewwithcheckbox

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import java.text.ParsePosition

class ChildAdapter(private val languageList: ArrayList<LanguageList>, private val parentPosition: Int,
                   private val parentCheckBox: Boolean) : RecyclerView.Adapter<ChildAdapter.MyViewHolder2>() {

    private var count : Int = 0
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder2 {
        var View = LayoutInflater.from(parent.context).inflate(R.layout.list_item2,parent,false)
        return MyViewHolder2(View)
    }

    override fun onBindViewHolder(holder: MyViewHolder2, position: Int) {
        var currentItem  = languageList[position]
        var count2 : Int = 0
     //   Log.e("Count","$currentItem")
        holder.childTextView.text = currentItem.childTextView
        holder.buttonPosition.text = "btn_ +  $parentPosition +  $position"


        if(parentCheckBox == true)
        {
            holder.childCheckBox.isChecked = true
            count2++
        }


      Toast.makeText(holder.itemView.context, "${position}", Toast.LENGTH_SHORT).show()
        count++
        Log.e("counnnnnnnnnnnn","$count")
        Log.e("counte222222222","$count2")
    }

    override fun getItemCount(): Int {
        return languageList.size
    }


    class MyViewHolder2(itemView : View) : RecyclerView.ViewHolder(itemView) {
        val childTextView = itemView.findViewById<TextView>(R.id.textview2)
        val buttonPosition = itemView.findViewById<Button>(R.id.buttonposition)
        var parentCheckBox =  itemView.findViewById<CheckBox>(R.id.parentCheckbox)
        var childCheckBox = itemView.findViewById<CheckBox>(R.id.childCheckbox)
    }

}