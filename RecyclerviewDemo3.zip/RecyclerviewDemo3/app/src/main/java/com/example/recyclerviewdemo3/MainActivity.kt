package com.example.recyclerviewdemo3

import android.annotation.SuppressLint
import android.graphics.Color
import android.graphics.PorterDuff
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Spannable
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.StaggeredGridLayoutManager

class MainActivity : AppCompatActivity() {
    private lateinit var newRecyclerView: RecyclerView
    private var newArrayList : ArrayList<News> = arrayListOf<News>()

    lateinit var imageId : Array<Int>
    lateinit var heading : Array<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var button1 = findViewById<Button>(R.id.button1)
        var button2 = findViewById<Button>(R.id.button2)
        var button3 = findViewById<Button>(R.id.button3)
        var button4 = findViewById<Button>(R.id.button4)

        imageId = arrayOf(
            R.drawable.a,
            R.drawable.b,
            R.drawable.c,
            R.drawable.d,
            R.drawable.e,
            R.drawable.a,
            R.drawable.b,
            R.drawable.c,
            R.drawable.d,
            R.drawable.e

        )

        heading = arrayOf(
            "data1 for babaji babaji babaji ",
            "data2 for trophy",
            "data3 for home home home",
            "data4 for heart",
            "data5 for setting",
            "data1 for babaji babaji babaji ",
            "data2 for trophy",
            "data3 for home home home",
            "data4 for heart",
            "data5 for setting"
        )

        newRecyclerView = findViewById(R.id.recyclerview)
        button1.setOnClickListener{ button1.setBackgroundColor(Color.RED)
            newRecyclerView.layoutManager = LinearLayoutManager(this)
            getUserData()
        }
        button2.setOnClickListener{ button2.setBackgroundColor(Color.RED)
            newRecyclerView.layoutManager = GridLayoutManager(this,3)
            getUserData()
        }
        button3.setOnClickListener{ button3.setBackgroundColor(Color.RED)
            newRecyclerView.layoutManager = StaggeredGridLayoutManager(3,StaggeredGridLayoutManager.VERTICAL)
            getUserData()
        }

    button4.setOnClickListener { button4.setBackgroundColor(Color.RED)
        val layoutManager = GridLayoutManager(this, 12)
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                return when (position) {
                    0,1,2 -> 3
                    3,4 -> 6
                    5,6,7,8->3
                    else -> 5
                }
            }
        }
        newRecyclerView.layoutManager = layoutManager
        getUserData()
 }


    }

    private fun getUserData() {
        for(i in imageId.indices)
        {
            val news = News(imageId[i], heading[i])
            newArrayList.add(news)
        }
        newRecyclerView.adapter = MyAdapter(newArrayList)
    }
}