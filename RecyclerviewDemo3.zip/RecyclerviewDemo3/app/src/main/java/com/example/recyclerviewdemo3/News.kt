package com.example.recyclerviewdemo3

data class News(var titleImaage : Int,var heading : String)
