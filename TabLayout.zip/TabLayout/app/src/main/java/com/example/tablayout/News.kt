package com.example.tablayout

import android.media.Image

data class News(var titleImaage : Int, var heading : String)
