package com.cheezycode.daggermvvm.productAdapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.cheezycode.daggermvvm.R
import com.cheezycode.daggermvvm.models.Product
import com.google.android.material.imageview.ShapeableImageView
import com.google.android.material.textview.MaterialTextView

class ListAdapter :
    ListAdapter<Product,com.cheezycode.daggermvvm.productAdapter.ListAdapter.ProductViewHolder>(
    DiffUtil()
) {

    class ProductViewHolder(view: View) : RecyclerView.ViewHolder(view){
        val imgview = view.findViewById<ShapeableImageView>(R.id.imgView)
        var id = view.findViewById<MaterialTextView>(R.id.txtViewId)
        val category = view.findViewById<MaterialTextView>(R.id.txtViewCategory)
        val price = view.findViewById<MaterialTextView>(R.id.txtViewPrice)
        val title = view.findViewById<MaterialTextView>(R.id.txtViewTitle)
        val  discription = view.findViewById<MaterialTextView>(R.id.txtViewDiscription)

        @SuppressLint("SetTextI18n")
        fun bind(item : Product, context: Context){
            Glide.with(context).load(item.image).into(imgview)
            id.text = "Id :-  " + item.id.toString()
            category.text = "Category :-  "+ item.category
            price.text = "Price :-  "+item.price.toString()
            title.text = "Title :-  " + item.title
            discription.text = "Discription :-  " + item.description
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.list_item,parent,false)
        return ProductViewHolder(view)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val item = getItem(position)
      val context =  holder.itemView.context
        holder.bind(item,context)
    }

    class DiffUtil : androidx.recyclerview.widget.DiffUtil.ItemCallback<Product>(){
        override fun areItemsTheSame(oldItem: Product, newItem: Product): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Product, newItem: Product): Boolean {
            return oldItem == newItem
        }
    }
}