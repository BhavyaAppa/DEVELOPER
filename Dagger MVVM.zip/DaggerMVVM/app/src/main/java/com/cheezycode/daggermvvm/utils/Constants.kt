package com.cheezycode.daggermvvm.utils

object Constants {
    const val BASE_URL = "https://fakestoreapi.com/"
}