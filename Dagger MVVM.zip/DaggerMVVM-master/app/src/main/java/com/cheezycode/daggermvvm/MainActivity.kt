package com.cheezycode.daggermvvm

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.widget.TextView
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.cheezycode.daggermvvm.databinding.ActivityMainBinding
import com.cheezycode.daggermvvm.db.FakerDB
import com.cheezycode.daggermvvm.viewmodels.MainViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    lateinit var mainViewModel: MainViewModel

    lateinit var dataBinding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dataBinding = DataBindingUtil.setContentView(this, R.layout.activity_main)

         mainViewModel = ViewModelProvider(this).get(MainViewModel::class.java)

        // Get Products Observe Start From Here
         mainViewModel.getProductsLiveData.observe(this)  {
             Log.d("GetProductResponse","$it")
         }
        // Get Products Observe End Here

        // Get Limit Products Observe Start From Here
        mainViewModel.getLimitProductsLiveData.observe(this) {
            Log.d("GetLimitProductResponse", "$it")
        }
        // Get Limit Products Observe End Here


    }
}



















