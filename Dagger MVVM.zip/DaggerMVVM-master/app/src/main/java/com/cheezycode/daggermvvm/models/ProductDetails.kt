package com.cheezycode.daggermvvm.models

data class ProductDetails(
    var productId: Int?,
    var quantity: Int?
)