package com.cheezycode.daggermvvm.models

data class GetProductLimit(
    var id: Int?,
    var date: String?,
    var products: List<ProductDetails>?,
    var userId: Int?
)