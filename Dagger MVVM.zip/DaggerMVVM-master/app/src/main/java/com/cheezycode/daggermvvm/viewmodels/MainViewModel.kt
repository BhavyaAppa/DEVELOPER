package com.cheezycode.daggermvvm.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cheezycode.daggermvvm.models.GetProductLimit
import com.cheezycode.daggermvvm.models.Product
import com.cheezycode.daggermvvm.repository.ProductRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(private val repository: ProductRepository) : ViewModel() {

    val getProductsLiveData : LiveData<List<Product>>
    get() = repository.getProducts

    val getLimitProductsLiveData : LiveData<List<GetProductLimit>>
        get() = repository.getLimitProducts

    init {
        viewModelScope.launch {
            repository.getProducts()
            repository.getLimitProducts()
        }
    }

}
