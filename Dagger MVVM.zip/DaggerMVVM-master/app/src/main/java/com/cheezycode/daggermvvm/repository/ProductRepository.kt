package com.cheezycode.daggermvvm.repository

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.cheezycode.daggermvvm.db.FakerDB
import com.cheezycode.daggermvvm.models.GetProductLimit
import com.cheezycode.daggermvvm.models.Product
import com.cheezycode.daggermvvm.retrofit.FakerAPI
import javax.inject.Inject

class ProductRepository @Inject constructor(
    private val fakerAPI: FakerAPI,
    private val fakerDB: FakerDB
) {

    private val _getProducts = MutableLiveData<List<Product>>()
    val getProducts: LiveData<List<Product>>
        get() = _getProducts

    private val _getLimitProducts = MutableLiveData<List<GetProductLimit>>()
    val getLimitProducts: LiveData<List<GetProductLimit>>
        get() = _getLimitProducts

    suspend fun getProducts() {
        val result = fakerAPI.getProducts()
        if (result.isSuccessful && result.body() != null) {
            Log.d("GetProductResult", "$result + ${result.body()}")
            fakerDB.getFakerDAO().addProducts(result.body()!!)
            _getProducts.postValue(result.body())
        }
    }

    suspend fun getLimitProducts() {
        val result = fakerAPI.getLimitProducts(6)
        if (result.isSuccessful && result.body() != null) {
            Log.d("GetLimitProductResult", "$result + ${result.body()}")
            _getLimitProducts.postValue(result.body())
        }
    }
}