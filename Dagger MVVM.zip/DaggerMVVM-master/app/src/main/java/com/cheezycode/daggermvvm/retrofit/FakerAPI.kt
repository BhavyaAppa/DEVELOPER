package com.cheezycode.daggermvvm.retrofit

import com.cheezycode.daggermvvm.models.GetProductLimit
import com.cheezycode.daggermvvm.models.Product
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface FakerAPI {

    @GET("products")
    suspend fun getProducts() : Response<List<Product>>

    @GET("carts")
    suspend fun getLimitProducts(@Query("limit") limit : Int) : Response<List<GetProductLimit>>

}