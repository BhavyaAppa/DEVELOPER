package com.cheezycode.quickpagingdemo.utils

object Constants {
    const val BASE_URL = "https://quotable.io/"
}