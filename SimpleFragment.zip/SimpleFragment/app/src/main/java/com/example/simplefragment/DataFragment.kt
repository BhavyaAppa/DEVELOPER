package com.example.simplefragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs

class DataFragment : Fragment() {
    private val args: DataFragmentArgs by navArgs<DataFragmentArgs>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view =  inflater.inflate(R.layout.fragment_data, container, false)
        val textview : TextView = view.findViewById(R.id.textView)
        val button = view.findViewById<Button>(R.id.databutton)
//        val args  = this.arguments
//        val output = args?.get("data")
//        textview.text = output.toString()

        val showMessage  = args.message
        textview.text = showMessage

        button.setOnClickListener{
            findNavController().navigate(R.id.action_dataFragment_to_newFragment)
        }
        return view
    }
}