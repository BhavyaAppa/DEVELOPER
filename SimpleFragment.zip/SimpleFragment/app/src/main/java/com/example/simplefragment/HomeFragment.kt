package com.example.simplefragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.findFragment
import androidx.navigation.fragment.findNavController


class HomeFragment : Fragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home,container,false)
        val button = view.findViewById<Button>(R.id.homebutton)
        button.setOnClickListener{
            val edittext : EditText = view.findViewById(R.id.edittext)
            val input = edittext.text.toString()
            val message = HomeFragmentDirections.actionHomeFragmentToDataFragment().setMessage(input)
//            val bundle  = Bundle()
//            bundle.putString("data",input)
            findNavController().navigate(message)
        }

        return view
    }

}