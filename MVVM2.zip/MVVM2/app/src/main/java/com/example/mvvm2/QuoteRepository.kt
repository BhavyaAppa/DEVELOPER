package com.example.mvvm2

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData

class QuoteRepository(private val quoteService : QuoteService) {

    private val quotesLiveData = MutableLiveData<QuoteList>()
    val quotes : LiveData<QuoteList>

    get() = quotesLiveData

    suspend fun getQuotes(page : Int){

        val result = quoteService.getQuote(page)


        if(result?.body() != null){
            Log.e("Result","${result.body()}")
            quotesLiveData.postValue(result.body())
        }
    }
}