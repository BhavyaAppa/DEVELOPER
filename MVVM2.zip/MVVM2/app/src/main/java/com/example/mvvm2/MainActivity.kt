package com.example.mvvm2

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.mvvm2.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding : ActivityMainBinding
    private lateinit var mainViewModel : MainViewModel
    private var arrayList: ArrayList<Result> = arrayListOf()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_main)
     //  var x =  binding.progressBar.progress


            if (checkForInternet(this@MainActivity)) {
                val quoteService = RetrofitHelper.getInstance().create(QuoteService::class.java)
                val repository = QuoteRepository(quoteService)
                mainViewModel = ViewModelProvider(this,MainViewModelFactory(repository)).get(MainViewModel::class.java)

                mainViewModel.quotes.observe(this, Observer {
                    Log.e("Resultdddddddd", "${it.results}")

                    arrayList.addAll(it.results)
                    val recyclerView = binding.recylerview
                    recyclerView.layoutManager = LinearLayoutManager(this)
                    val adapter = MyAdapter(arrayList)
                    binding.progressBar.visibility = View.GONE
                    recyclerView.adapter = adapter
                })
            } else {
                binding.progressBar.visibility = View.GONE
                Toast.makeText(this, "Disconnected", Toast.LENGTH_SHORT).show()
            }

    }
    private fun checkForInternet(context: Context): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val network = connectivityManager.activeNetwork ?: return false
            val activeNetwork = connectivityManager.getNetworkCapabilities(network) ?: return false

            return when {
                activeNetwork.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> true
                activeNetwork.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> true
                else -> false
            }
        } else {
            // if the android version is below M
            @Suppress("DEPRECATION") val networkInfo =
                connectivityManager.activeNetworkInfo ?: return false
            @Suppress("DEPRECATION")
            return networkInfo.isConnected
        }
    }
}

