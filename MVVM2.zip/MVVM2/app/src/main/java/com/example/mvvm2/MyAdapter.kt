package com.example.mvvm2

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.mvvm2.databinding.ListItemBinding

class MyAdapter(private val arrayList: ArrayList<Result>) :RecyclerView.Adapter<MyAdapter.ViewHolder>() {

    private lateinit var binding: ListItemBinding
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
         binding = ListItemBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        //var quote : QuoteList = arrayList[position]
        holder.text1.text = arrayList[position]._id
        holder.text2.text = arrayList[position].author
        holder.text3.text = arrayList[position].content
    }

    override fun getItemCount(): Int {
        return arrayList.size
    }

    class ViewHolder(binding: ListItemBinding) : RecyclerView.ViewHolder(binding.root){
        var text1 = binding.textview1
        var text2 = binding.textview2
        var text3 = binding.textview3
    }

}