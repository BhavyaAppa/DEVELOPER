package com.example.retrofitdemo2

import android.util.Log
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

// https://api.apilayer.com/exchangerates_data/timeseries?apikey=1w2rvVBn7BjhLLBfmw1Qby2HDNM61z11&start_date=2018-01-01&end_date=2018-09-01

interface RatesInterface
{
    @GET("timeseries")
    fun ratesData(@Query("start_date") start_date: String,
                @Query("end_date") end_date: String,
                @Query("base") base : String): Call<Rates>
}