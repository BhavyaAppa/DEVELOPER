package com.example.retrofitdemo2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ApiAdopter(var dataArrayList: ArrayList<X20180101>):
    RecyclerView.Adapter<ApiAdopter.MyViewHolder>() {
     class MyViewHolder (itemView : View):RecyclerView.ViewHolder(itemView){
        var txt1 = itemView.findViewById<TextView>(R.id.textView1)
        var txt2 = itemView.findViewById<TextView>(R.id.textView2)
        var txt3 = itemView.findViewById<TextView>(R.id.textView3)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view : View = LayoutInflater.from(parent.context).inflate(R.layout.list_item,parent,false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentPosition = dataArrayList[position]

        holder.apply {
            txt1.text = currentPosition.ALL.toString()
            txt2.text = currentPosition.AFN.toString()
            txt3.text = currentPosition.AED.toString()
        }
    }

    override fun getItemCount(): Int {
       return dataArrayList.size
    }
}