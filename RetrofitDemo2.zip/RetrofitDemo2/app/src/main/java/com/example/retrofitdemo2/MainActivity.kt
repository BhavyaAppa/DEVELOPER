package com.example.retrofitdemo2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.retrofitdemo2.databinding.ActivityMainBinding
import com.google.gson.Gson
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    lateinit var adapter: ApiAdopter
    lateinit var recyclerView: RecyclerView

    var mapArrayList = ArrayList<Map<String,Double>>()
    var dataArrayList = ArrayList<X20180101>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        getRates()
    }

    private fun getRates() {

        val rates : Call<Rates> = RetroInstance.getInstance()
            .ratesData("2018-01-01","2018-09-01" , "EUR")
        rates.enqueue(object : Callback<Rates>{
            override fun onResponse(call: Call<Rates>, response: Response<Rates>) {
                    val ratesResponse = response.body()

                    if (ratesResponse != null) {

                           // Log.e("Object Response","$obj")
                        for(i in ratesResponse.rates.keySet())
                        {
                            dataArrayList.add(Gson().fromJson(ratesResponse.rates[i],X20180101::class.java))
                        }
                        Log.e("mapArrayList","${dataArrayList}")
                        recyclerView = findViewById(R.id.recyclerview)
                        adapter = ApiAdopter(dataArrayList)
                        recyclerView.layoutManager = GridLayoutManager(this@MainActivity,2)
                        recyclerView.adapter = adapter
                    }
            }

            override fun onFailure(call: Call<Rates>, t: Throwable) {
                Log.e("Failure","${t.message}")
            }
        })
    }
}