package com.example.retrofitdemo2

import android.util.Log
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

// https://api.apilayer.com/exchangerates_data/timeseries?apikey=1w2rvVBn7BjhLLBfmw1Qby2HDNM61z11&start_date=2018-01-01&end_date=2018-09-01

const val Apikey = "URYdczv4Ik5SiBw1vFScCkGs5485qIOe"

class RetroInstance {
    companion object {
        private var retroIns: Retrofit? = null
        private var instance: RatesInterface? = null
        private var base_url = "https://api.apilayer.com/exchangerates_data/"

        private fun retroBuilder(): Retrofit {
            //commented code pasted here

            val headerInterceptor = Interceptor { chain ->
                var request = chain.request()
                request = request.newBuilder()
                    .addHeader("apikey","$Apikey")
                    .build()
                chain.proceed(request)
            }

            val okHttpClient = OkHttpClient.Builder()
                .addInterceptor(headerInterceptor)
                .readTimeout(60L,TimeUnit.SECONDS)
                .connectTimeout(60L,TimeUnit.SECONDS)
                .writeTimeout(60L,TimeUnit.SECONDS)
                .build()

            if (retroIns == null) {
                return Retrofit.Builder()
                    .baseUrl(base_url)
                    .addConverterFactory(GsonConverterFactory.create())
                    .client(okHttpClient)
                    .build()
            }
            return retroIns as Retrofit
        }

        @Synchronized
        fun getInstance(): RatesInterface {
            if (instance == null) {
                instance = retroBuilder().create(RatesInterface::class.java)
            }
            return instance as RatesInterface
        }
    }
}