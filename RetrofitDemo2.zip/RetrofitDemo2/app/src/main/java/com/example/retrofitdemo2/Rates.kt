package com.example.retrofitdemo2

import com.google.gson.JsonObject
import org.json.JSONObject


//data class Rates(
//    val start_date: String,
//    val end_date: String,
//    val rates: Rates2
//)

data class Rates(
    val base: String,
    val end_date: String,
    val rates: JsonObject,
    val start_date: String,
    val success: Boolean,
    val timeseries: Boolean
)