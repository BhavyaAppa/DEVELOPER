package com.example.form

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.core.view.isEmpty
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class MainActivity : AppCompatActivity() {

    private lateinit var name : TextInputEditText
    private lateinit var phone : TextInputEditText
    private lateinit var email : TextInputEditText
    private lateinit var password : TextInputEditText
    private lateinit var confirmpassword : TextInputEditText
    private lateinit var radiobtn1 : RadioButton
    private lateinit var radiobtn2 : RadioButton
    private lateinit var radiobtn3 : RadioButton
    private lateinit var btn : Button
    private lateinit var radiogroup : RadioGroup
    private var gender: String? = null
    private lateinit var languageItem : String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        name = findViewById<TextInputEditText>(R.id.name)
        phone  = findViewById<TextInputEditText>(R.id.phone)
        email = findViewById<TextInputEditText>(R.id.email)
        password = findViewById<TextInputEditText>(R.id.password)
        confirmpassword = findViewById<TextInputEditText>(R.id.confirmpassword)
        radiobtn1 = findViewById<RadioButton>(R.id.male)
        radiobtn2 = findViewById<RadioButton>(R.id.female)
        radiobtn3 = findViewById<RadioButton>(R.id.others)
        radiogroup = findViewById<RadioGroup>(R.id.radiogroup)
        val spinner = findViewById<Spinner>(R.id.spinner)
        val languages = resources.getStringArray(R.array.language)

        radiogroup.setOnCheckedChangeListener { group, checkedId ->
            if(R.id.male == checkedId)
            {
                gender = "Male"
            }
            else if(R.id.female == checkedId)
            {
                gender = "Female"
            }
            else if(R.id.others == checkedId)
            {
                gender = "Others"
            }
        }


        if(spinner != null){
            val adapter =   ArrayAdapter(this,android.R.layout.simple_spinner_item,languages)
            spinner.adapter = adapter

            spinner.onItemSelectedListener = object :
                AdapterView.OnItemSelectedListener{
                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    languageItem = languages[position]
//                    Toast.makeText(this@MainActivity,
//                        getString(R.string.select) + " " +
//                                "" + languages[position], Toast.LENGTH_SHORT).show()
                }
                override fun onNothingSelected(parent: AdapterView<*>) {
                }
            }
        }


        btn = findViewById<Button>(R.id.nextbtn)

        btn.setOnClickListener() {
            var name1 = name?.text.toString().trim()
            var emailPattern = "[a-zA-Z0-9]+@[a-z]+\\.+[a-z]+"
            var phone1 = phone?.text.toString().trim()
            var email1 = email?.text.toString().trim()
            var password1 = password?.text.toString().trim()
            var confirmpassword1 = confirmpassword?.text.toString().trim()
            var maleradiobutton = radiobtn1?.text.toString().trim()
            var femaleradiobutton = radiobtn2?.text.toString().trim()
            var othersradiobutton = radiobtn3?.text.toString().trim()

            if(name1.isEmpty())
            {
                name.error = "Plz Enter Name"
            }

            else if(phone1.isEmpty())
            {
                phone.error = "Plz Enter Phone Number"
            }
            else if(phone1.length != 10)
            {
                phone.error = "Phone No Length should be 10"
            }

            else if(email1.isEmpty())
            {
                email.error = "Plz Enter Email"
            }

            else if(!email1.matches(emailPattern.toRegex()))
            {
                email.error = "Plz Enter Valid Email"
            }

            else if(password1.isEmpty())
            {
                password.error = "Plz Enter Password"
            }

            else if(password1.length < 3)
            {
                password.error = "Length Should be Greter Than 3"
            }

            else if(confirmpassword1.isEmpty())
            {
                confirmpassword.error = "Plz Enter Confirm Password "
            }

            else if(password1 != confirmpassword1)
            {
                confirmpassword.error = "Both Password Not Match"
            }

            else
            {
                var intent = Intent(this@MainActivity,SecondActivity::class.java)
                intent.putExtra("Name",name1)
                intent.putExtra("Phone", phone1)
                intent.putExtra("Email",email1)
                intent.putExtra("Password",password1)
                intent.putExtra("Confirmpassword", confirmpassword1)
                intent.putExtra("Gender",gender)
                intent.putExtra("Language",languageItem)
                startActivity(intent)
            }
        }
    }
}