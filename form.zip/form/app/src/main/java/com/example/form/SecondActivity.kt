package com.example.form

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout


class SecondActivity : AppCompatActivity() {

    private lateinit var view : TextView

        override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

            view = findViewById<TextView>(R.id.textView)

            val intent = getIntent()
            var nameShow = intent.getStringExtra("Name",)
            var phoneShow = intent.getStringExtra("Phone")
            var emailShow = intent.getStringExtra("Email")
            var passwordShow = intent.getStringExtra("Password")
            var confirmpasswordShow = intent.getStringExtra("Confirmpassword")
            var genderShow = intent.getStringExtra("Gender")
            var languageitemshow = intent.getStringExtra("Language")



            view.text = "Name :- $nameShow  \n  Phone :- $phoneShow \n Email :- $emailShow  \n Password :- $passwordShow \n Confirm Password :- $confirmpasswordShow \n Gender :- $genderShow \n" +
                    "Language :- $languageitemshow"
    }
}