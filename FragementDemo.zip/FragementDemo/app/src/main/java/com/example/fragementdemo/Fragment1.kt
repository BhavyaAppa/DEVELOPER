package com.example.fragementdemo

import androidx.fragment.app.Fragment

class Fragment1 : Fragment(R.layout.fragment1) {

}