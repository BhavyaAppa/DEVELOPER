package com.example.fragementdemo

import androidx.fragment.app.Fragment

class Fragment2 : Fragment(R.layout.fragment2) {
}