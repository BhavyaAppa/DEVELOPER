package com.example.roomdemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.databinding.DataBindingUtil
import com.example.roomdemo.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var database: ContactDatabase
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_main)
       database = ContactDatabase.getDatabase(this)
//        database = Room
//            .databaseBuilder(applicationContext
//                ,ContactDatabase::class.java, "contactDB").build()
        MainScope().launch(Dispatchers.IO) {

            binding.insert.setOnClickListener {
                MainScope().launch(Dispatchers.IO) {
                    val y = binding.edittext2.text
                    val z = binding.edittext3.text
                    database.contactDao().insertContact(Contact(0, "$y", "$z", Date()))
                }
            }

            binding.update.setOnClickListener {
                MainScope().launch(Dispatchers.IO) {
                    val y = binding.edittext2.text
                    val z = binding.edittext3.text
                    database.contactDao().updateContact(Contact(1, "$y", "$z", Date()))
                }
            }

            binding.delete.setOnClickListener {
                MainScope().launch(Dispatchers.IO) {
                    val y = binding.edittext2.text
                    val z = binding.edittext3.text
                    database.contactDao().deleteContact(Contact(1, "$y", "$z", Date()))
                }
            }

            binding.get.setOnClickListener {
                MainScope().launch(Dispatchers.IO) {
                    var y = binding.edittext2.text
                    var z = binding.edittext3.text
                    database.contactDao().getContact()
                    database.contactDao().getContact().observe(this@MainActivity, {
                        Log.e("Bhavya", it.toString())
                    })
                }
            }
        }
    }
}