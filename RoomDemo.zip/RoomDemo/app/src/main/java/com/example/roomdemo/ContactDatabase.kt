package com.example.roomdemo

import android.content.Context
import androidx.room.*


@Database(entities = [Contact::class], version = 1)
@TypeConverters(Converters::class)
abstract class ContactDatabase  :RoomDatabase() {
    abstract fun contactDao(): ContactDAO
    companion object {
        @Volatile
        private var Instance: ContactDatabase? = null

        fun getDatabase(context: Context): ContactDatabase {
            if (Instance == null) {
                synchronized(this){
                    Instance = Room
                        .databaseBuilder(context.applicationContext
                            ,ContactDatabase::class.java, "contactDB").build()
                }
            }
            return Instance!!
        }
    }
}