package com.example.roomdemo

import androidx.room.Entity
import androidx.room.PrimaryKey
import org.w3c.dom.Text
import java.sql.Blob
import java.util.*

@Entity(tableName = "contact")
data class Contact(
    @PrimaryKey(autoGenerate = true)
    val id : Int,
    val  name : String,
    val photo : String,
    val  date : Date
)
