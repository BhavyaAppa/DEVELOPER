package com.example.shoppinglist.ui.shopping_list

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.shoppinglist.R
import com.example.shoppinglist.data.ShoppingDatabase
import com.example.shoppinglist.data.ShoppingItem
import com.example.shoppinglist.data.other.ShoppingItemAdapter
import com.example.shoppinglist.data.repository.ShoppingRepository
import com.example.shoppinglist.ui.ShoppingViewModel
import com.google.android.material.floatingactionbutton.FloatingActionButton

class ShoppingActivity : AppCompatActivity() {
    @SuppressLint("NotifyDataSetChanged")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shopping)
        var recyclerView = findViewById<RecyclerView>(R.id.recyclerview)
        var floatingActionButton = findViewById<FloatingActionButton>(R.id.floatingbutton)

        val database = ShoppingDatabase(this)
        val  repository = ShoppingRepository(database)
        val factory = ShoppingViewModelFactory(repository)
        val viewModel = ViewModelProvider(this,factory).get(ShoppingViewModel::class.java)
        val adapter = ShoppingItemAdapter(listOf(),viewModel)

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        viewModel.getAllShoppingItem().observe(this, Observer {
            adapter.items = it
            adapter.notifyDataSetChanged()
        })

        floatingActionButton.setOnClickListener {
            AddShoppingItemDialog(this,
            object : AddDialogListner{
                override fun onAddButtonClicked(item: ShoppingItem) {
                    viewModel.insert(item)
                }
            }).show()
        }
    }
}