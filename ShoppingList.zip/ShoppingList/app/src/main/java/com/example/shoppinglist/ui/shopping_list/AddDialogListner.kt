package com.example.shoppinglist.ui.shopping_list

import com.example.shoppinglist.data.ShoppingItem

interface AddDialogListner {
    fun onAddButtonClicked(item : ShoppingItem)
}