package com.example.shoppinglist.data.other

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.shoppinglist.R
import com.example.shoppinglist.data.ShoppingItem
import com.example.shoppinglist.ui.ShoppingViewModel

class ShoppingItemAdapter(var items : List<ShoppingItem>, private val viewModel: ShoppingViewModel)
    : RecyclerView.Adapter<ShoppingItemAdapter.ShoppingViewHolder>() {
    inner class ShoppingViewHolder(itemView : View) : RecyclerView.ViewHolder(itemView) {
        val name = itemView.findViewById<TextView>(R.id.textview1)
        val amount = itemView.findViewById<TextView>(R.id.textview2)
        val delete = itemView.findViewById<ImageView>(R.id.img1)
        val  plus = itemView.findViewById<ImageView>(R.id.img2)
        val minus = itemView.findViewById<ImageView>(R.id.img3)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ShoppingViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.shopping_item,parent,false)
        return ShoppingViewHolder(view)
    }

    override fun onBindViewHolder(holder: ShoppingViewHolder, position: Int) {
        val  currentShoppingItem = items[position]

        holder.name.text = currentShoppingItem.name
        holder.amount.text = currentShoppingItem.amount.toString()

        holder.delete.setOnClickListener {
            viewModel.delete(currentShoppingItem)
        }

        holder.plus.setOnClickListener {
            currentShoppingItem.amount++
            viewModel.insert(currentShoppingItem)
        }

        holder.minus.setOnClickListener {
            if(currentShoppingItem.amount > 0)
            {
                currentShoppingItem.amount--
                viewModel.insert(currentShoppingItem)
            }
        }
    }

    override fun getItemCount(): Int {
        return items.size
    }
}