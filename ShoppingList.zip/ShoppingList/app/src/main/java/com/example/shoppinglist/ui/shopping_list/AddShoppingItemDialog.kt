package com.example.shoppinglist.ui.shopping_list

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatDialog
import com.example.shoppinglist.R
import com.example.shoppinglist.data.ShoppingItem

class AddShoppingItemDialog(context: Context,var addDialogListner: AddDialogListner) : AppCompatDialog(context){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dialog_add_shopping_item)
        val save = findViewById<Button>(R.id.save)
        val cancel = findViewById<Button>(R.id.cancel)

        save?.setOnClickListener {
            val name1 = findViewById<EditText>(R.id.name)
            val amount1 = findViewById<EditText>(R.id.amount)
            val name = name1?.text.toString()
            val amount = amount1?.text.toString()
            if(name.isEmpty() || amount.isEmpty()){
                Toast.makeText(context, "Please Fill All Information", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val item = ShoppingItem(name,amount.toInt())
            addDialogListner.onAddButtonClicked(item)
            dismiss()
        }

        cancel?.setOnClickListener {
            cancel()
        }
    }
}