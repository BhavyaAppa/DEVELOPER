package com.example.shoppinglist.data.repository

import androidx.appcompat.view.menu.MenuItemWrapperICS
import com.example.shoppinglist.data.ShoppingDatabase
import com.example.shoppinglist.data.ShoppingItem

class ShoppingRepository(private val db : ShoppingDatabase){
    suspend fun insert(item: ShoppingItem) = db.getShoppingDao().insert(item)

    suspend fun delete(item: ShoppingItem) = db.getShoppingDao().delete(item)

    fun getAllShoppingItems() = db.getShoppingDao().getAllShoppingItems()
}