package com.example.bottomnavigationbar

import android.content.Context
import android.icu.text.IDNA
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.fragment.app.Fragment
import com.example.bottomnavigationbar.fragment.BlankFragment
import com.example.bottomnavigationbar.fragment.DashboardFragment
import com.example.bottomnavigationbar.fragment.InfoFragment
import com.example.bottomnavigationbar.fragment.SettingFragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    private val dashboardFragment = DashboardFragment()
    private val  settingFragment = SettingFragment()
    private val infoFragment = InfoFragment()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val bottomNavigation = findViewById<BottomNavigationView>(R.id.bottom_navigation)
        bottomNavigation.setOnItemSelectedListener{
            when(it.itemId){
                R.id.ic_dashboard -> replaceFragment(dashboardFragment)
                R.id.ic_setting -> replaceFragment(settingFragment)
                R.id.ic_info -> replaceFragment(infoFragment)
            }
            true
        }
        replaceFragment(dashboardFragment)

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.manu , menu)
        return true
    }

    private fun replaceFragment(fragment: Fragment){
        if(fragment != null){
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fragment_container,fragment)
            transaction.commit()
        }
    }
}