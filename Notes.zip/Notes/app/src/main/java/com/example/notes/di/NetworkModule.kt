package com.example.notes.di

import com.example.notes.api.UserApi
import com.example.notes.utils.Constants.base_url
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton

@InstallIn(SingletonComponent::class)
@Module
class NetworkModule {
    @Singleton
    @Provides
    fun provideRetrofit() : Retrofit{
        return Retrofit.Builder().addConverterFactory(GsonConverterFactory.create())
            .baseUrl(base_url).build()
    }

    @Singleton
    @Provides
    fun provideApi(retrofit: Retrofit) : UserApi{
        return retrofit.create(UserApi::class.java)
    }
}