package com.example.notes.utils

object Constants {
    const val base_url = "https:://notes-api-sample.herokuapp.com/"

}