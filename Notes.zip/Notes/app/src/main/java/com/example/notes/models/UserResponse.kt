package com.example.notes.models

import com.example.notes.models.User

data class UserResponse(
    val token: String,
    val user: User
)