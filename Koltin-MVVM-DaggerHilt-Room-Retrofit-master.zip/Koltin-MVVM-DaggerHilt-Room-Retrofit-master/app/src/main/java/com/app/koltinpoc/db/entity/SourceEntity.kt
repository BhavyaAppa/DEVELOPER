package com.app.koltinpoc.db.entity


data class SourceEntity(
    val id: String?,
    val name: String?
)