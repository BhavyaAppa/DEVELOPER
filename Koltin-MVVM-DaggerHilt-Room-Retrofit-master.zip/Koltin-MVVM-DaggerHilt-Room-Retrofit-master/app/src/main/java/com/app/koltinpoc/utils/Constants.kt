package com.app.koltinpoc.utils

object Constants {

    val API_KEY = "API_KEY" //GET YOUR API KEY BY SIGNING to https://newsapi.org
    val BASE_URL = "https://newsapi.org/"
    val COUNTRY_CODE = "in"

}