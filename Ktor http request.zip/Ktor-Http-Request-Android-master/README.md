# Ktor-Http-Request-Android

Bye Bye Retrofit .. Now it's time to shift on Ktor for Http Request i,e get,post,delete,update etc.. ktor is simple , easy to use , fully based on coroutines, doing asynchronous programming , less boilerplate code ❤️😍

Ktor is Awesome ✅

