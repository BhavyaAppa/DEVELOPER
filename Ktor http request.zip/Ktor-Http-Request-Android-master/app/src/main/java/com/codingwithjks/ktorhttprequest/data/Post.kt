package com.codingwithjks.ktorhttprequest.data

data class Post(
    val id:Int,
    val body:String
)
