package com.example.firebasedetailsapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.EditText
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import com.google.android.material.button.MaterialButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.database.DatabaseReference

class MainActivity : AppCompatActivity() {
    lateinit var name: EditText
    private lateinit var btnInsertData: MaterialButton
    private lateinit var btnFetchData: MaterialButton
    private lateinit var btnLogout: MaterialButton

    private lateinit var database: DatabaseReference

    // declare the GoogleSignInClient
    lateinit var mGoogleSignInClient: GoogleSignInClient
    // val auth is initialized by lazy
    private val auth by lazy {
        FirebaseAuth.getInstance()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        btnInsertData = findViewById(R.id.btnInsertData)
        btnFetchData = findViewById(R.id.btnFetchData)
        btnLogout = findViewById(R.id.btnLogout)

        btnInsertData.setOnClickListener {
            val intent = Intent(this, InsertionActivity::class.java)
            startActivity(intent)
        }

        btnFetchData.setOnClickListener {
            val intent = Intent(this, FetchingActivity::class.java)
            startActivity(intent)
        }

        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()
        mGoogleSignInClient= GoogleSignIn.getClient(this,gso)
// pass the same server client ID used while implementing the LogIn feature earlier.

        btnLogout.setOnClickListener {
            mGoogleSignInClient.signOut().addOnCompleteListener {
                val intent= Intent(this, LoginActivity::class.java)
                startActivity(intent)
                finish()
            }
        }
    }
}

// sha1 BF:F4:FF:FC:26:4D:D5:A7:AE:66:12:A4:97:83:D5:1B:53:8F:E1:13

// web API key  AIzaSyB1tQ6FbyhiVlVyiLJiwtsAO0XJLXuqLX4

// project id fir-detailsapp

// App id 1:59985793078:android:6b7fab7a36973e85c7c897

// Client id 59985793078-4t5k3upgul33sfoulahmtlmdhgtmumt3.apps.googleusercontent.com

//Client Secret  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

// {"web":{"client_id":"59985793078-4t5k3upgul33sfoulahmtlmdhgtmumt3.apps.googleusercontent.com","project_id":"fir-detailsapp","auth_uri":"https://accounts.google.com/o/oauth2/auth","token_uri":"https://oauth2.googleapis.com/token","auth_provider_x509_cert_url":"https://www.googleapis.com/oauth2/v1/certs","client_secret":"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"}}





