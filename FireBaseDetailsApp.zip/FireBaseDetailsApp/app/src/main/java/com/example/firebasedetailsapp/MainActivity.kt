package com.example.firebasedetailsapp

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.databinding.DataBindingUtil
import com.example.firebasedetailsapp.databinding.ActivityMainBinding
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.material.button.MaterialButton
import com.google.android.material.textview.MaterialTextView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    lateinit var name: EditText
    private lateinit var btnInsertData: MaterialButton
    private lateinit var btnFetchData: MaterialButton
    private lateinit var btnLogout: MaterialButton
    private lateinit var btnDatePicker: MaterialButton
    private lateinit var txtviewTitle: MaterialTextView
    private lateinit var dataBiding: ActivityMainBinding


    private lateinit var database: DatabaseReference

    // declare the GoogleSignInClient
    lateinit var mGoogleSignInClient: GoogleSignInClient

    // val auth is initialized by lazy
    private val auth by lazy {
        FirebaseAuth.getInstance()
    }

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        dataBiding = DataBindingUtil.setContentView(this, R.layout.activity_main)

        btnInsertData = findViewById(R.id.btnInsertData)
        btnFetchData = findViewById(R.id.btnFetchData)
        btnLogout = findViewById(R.id.btnLogout)
        btnDatePicker = findViewById(R.id.btnDatePicker)
        txtviewTitle = findViewById(R.id.txtviewTitle)

        val c = Calendar.getInstance()
        val year = c.get(Calendar.YEAR)
        val month = c.get(Calendar.MONTH)
        val day = c.get(Calendar.DAY_OF_MONTH)


        btnDatePicker.setOnClickListener {
            val dpd = DatePickerDialog(this,
                DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->

                    // Display Selected date in textbox
                    txtviewTitle.setText("" + dayOfMonth + " " + monthOfYear + ", " + year)
                },
                year, month, day)
            dpd.show()
        }


        dataBiding.btnInsertData.setOnClickListener {
            val intent = Intent(this, InsertionActivity::class.java)
            startActivity(intent)
        }

        dataBiding.btnFetchData.setOnClickListener {
            val intent = Intent(this, FetchingActivity::class.java)
            startActivity(intent)
        }

        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso)
// pass the same server client ID used while implementing the LogIn feature earlier.

        dataBiding.btnLogout.setOnClickListener {
            mGoogleSignInClient.signOut().addOnCompleteListener {
                val intent = Intent(this, LoginActivity::class.java)
                startActivity(intent)
                finish()
            }
        }
    }
}

// sha1 BF:F4:FF:FC:26:4D:D5:A7:AE:66:12:A4:97:83:D5:1B:53:8F:E1:13

// web API key  AIzaSyB1tQ6FbyhiVlVyiLJiwtsAO0XJLXuqLX4

// project id fir-detailsapp

// App id 1:59985793078:android:6b7fab7a36973e85c7c897

// Client id 59985793078-4t5k3upgul33sfoulahmtlmdhgtmumt3.apps.googleusercontent.com

//Client Secret  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

// {"web":{"client_id":"59985793078-4t5k3upgul33sfoulahmtlmdhgtmumt3.apps.googleusercontent.com","project_id":"fir-detailsapp","auth_uri":"https://accounts.google.com/o/oauth2/auth","token_uri":"https://oauth2.googleapis.com/token","auth_provider_x509_cert_url":"https://www.googleapis.com/oauth2/v1/certs","client_secret":"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"}}





