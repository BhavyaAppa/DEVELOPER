package com.example.firebasedetailsapp

import android.widget.RatingBar

data class HeroModel(
    val id: String,
    val name: String,
    val ratingBar: Int
)
