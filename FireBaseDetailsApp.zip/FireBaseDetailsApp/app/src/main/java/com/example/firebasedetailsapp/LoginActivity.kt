package com.example.firebasedetailsapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.facebook.CallbackManager
import com.facebook.FacebookCallback
import com.facebook.FacebookException
import com.facebook.GraphRequest
import com.facebook.login.LoginResult
import com.facebook.login.widget.LoginButton
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import com.google.android.material.button.MaterialButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import org.json.JSONObject

class LoginActivity : AppCompatActivity() {

    private lateinit var btnGoogleSignIn: MaterialButton
    private lateinit var btnFacebookSignIn: LoginButton
    private lateinit var callBackManager: CallbackManager


    // Google Sign in
    lateinit var mGoogleSignInClient: GoogleSignInClient
    val Req_Code: Int = 123
    val firebaseAuth = FirebaseAuth.getInstance()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        btnGoogleSignIn = findViewById(R.id.btnGoogleSignIn)
        btnFacebookSignIn = findViewById(R.id.btnFacebookSignIn)


        // Google SignIn and Singout Code Start Here
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()
        // getting the value of gso inside the GoogleSigninClient
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso)

        btnGoogleSignIn.setOnClickListener {
            callGoogleSignIn()
        }
        // Google SignIn and Singout Code End Here


        // Facebook SignIn and Singout Code Start Here

        //Now initialize the callbackmanager

        callBackManager = CallbackManager.Factory.create()

        //set the login button with permissions to read and add to a list all user data
        btnFacebookSignIn.setReadPermissions(
            listOf(
                "email",
                "public_profile",
                "user_gender",
                "user_birthday"
            )
        )

        //A callback is registered when the login button is clicked.
//The callback can return an error or success message. It can also be canceled

        btnFacebookSignIn.registerCallback(
            callBackManager,
            object : FacebookCallback<LoginResult> {
                override fun onCancel() { // this method is invoked when the request is cancelled
                    Toast.makeText(
                        this@LoginActivity,
                        "Cancelled",
                        Toast.LENGTH_SHORT
                    ).show()
                }

                override fun onError(error: FacebookException) {
                    Toast.makeText(this@LoginActivity, "$error", Toast.LENGTH_SHORT).show()
                }

                override fun onSuccess(result: LoginResult) {
                    val graphRequest =
                        GraphRequest.newMeRequest(result?.accessToken) { `object`, response ->
                            getFacebookData(`object`)
                        }
                    val parameters = Bundle()
                    parameters.putString("fields", "id,email,birthday,gender,name")
                    graphRequest.parameters = parameters
                    graphRequest.executeAsync()
                }

            })
        // Facebook SignIn and SignOut Code End Here
    }

    //This function gets the users' Facebook data.
//This includes the username, email, birthday, gender, and profile picture.
//As they appear on Facebook

    private fun getFacebookData(jsonObject: JSONObject?) {
        val profilePic = "https://graph.facebook.com/${
            jsonObject
                ?.getString("id")
        }/picture?width=500&height=500"


        val name = jsonObject?.getString("name")
        val birthday = jsonObject?.getString("birthday")
        val gender = jsonObject?.getString("gender")
        val email = jsonObject?.getString("email")

        Log.d("FacebookName ",name!!)
        Log.d("FacebookEmail ",email!!)
        Log.d("FacebookBirthday ",birthday!!)
        Log.d("FacebookGender ",gender!!)
        Log.d("FacebookProfilePic ",profilePic)
    }


    private fun callGoogleSignIn() {
        val signInIntent: Intent = mGoogleSignInClient.signInIntent
        startActivityForResult(signInIntent, Req_Code)


    }

    // onActivityResult() function : this is where we provide the task and data for the Google Account
    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, data)
        // Facebook Result Code
        callBackManager.onActivityResult(requestCode, resultCode, data)
    if (requestCode == Req_Code) {
            val task: Task<GoogleSignInAccount> =
                GoogleSignIn.getSignedInAccountFromIntent(data)
            handleResult(task)
        }
    }

    // handleResult() function -  this is where we update the UI after Google signin takes place
    private fun handleResult(completedTask: Task<GoogleSignInAccount>) {
        try {
            val account: GoogleSignInAccount? =
                completedTask.getResult(ApiException::class.java)
            if (account != null) {
                UpdateUI(account)
            }
        } catch (e: ApiException) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show()
        }
    }

    // UpdateUI() function - this is where we specify what UI updation are needed after google signin has taken place.
    private fun UpdateUI(account: GoogleSignInAccount) {
        val credential = GoogleAuthProvider.getCredential(account.idToken, null)
        firebaseAuth.signInWithCredential(credential).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                Log.d("Email", "${account.email}")
                Log.d("Username", "${account.givenName}")
                SavedPreference.setEmail(this, account.email.toString())
                SavedPreference.setUsername(this, account.displayName.toString())
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (GoogleSignIn.getLastSignedInAccount(this) != null) {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}